$root = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($root)) { throw "ROOT_NOT_RESOLVED in CREATE_SHORTCUT.ps1" }

$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "SITE AUDIT.lnk"

$wsh = New-Object -ComObject WScript.Shell
$shortcut = $wsh.CreateShortcut($shortcutPath)

$shortcut.TargetPath = "powershell.exe"
$shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$root\run.ps1`""
$shortcut.WorkingDirectory = $root
$shortcut.IconLocation = "$env:SystemRoot\System32\shell32.dll,70"

$shortcut.Save()

Write-Host "Shortcut created."
