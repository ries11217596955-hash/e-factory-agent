function Invoke-SiteAudit {

    $ErrorActionPreference = "Stop"

    $root = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($root)) {
        throw "ROOT_NOT_RESOLVED: PSScriptRoot is empty in agent.ps1"
    }

    $configPath = Join-Path $root 'config\agent.config.json'
    $tokenPath  = Join-Path $root '.state\github_token.txt'
    $workspace  = Join-Path $root 'workspace'
    $outbox     = Join-Path $root 'outbox'

    if (-not (Test-Path -LiteralPath $configPath)) { throw "CONFIG_NOT_FOUND: $configPath" }
    if (-not (Test-Path -LiteralPath $tokenPath))  { throw "TOKEN_NOT_FOUND: $tokenPath" }

    if (-not (Test-Path -LiteralPath $workspace)) { New-Item -ItemType Directory -Path $workspace -Force | Out-Null }
    if (-not (Test-Path -LiteralPath $outbox))    { New-Item -ItemType Directory -Path $outbox -Force | Out-Null }

    $config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
    $token  = (Get-Content -LiteralPath $tokenPath -Raw).Trim()

    if ([string]::IsNullOrWhiteSpace($token) -or $token -eq 'ghp_PASTE_YOUR_TOKEN_HERE') {
        throw "TOKEN_EMPTY_OR_TEMPLATE: put real GitHub token into .state\github_token.txt"
    }

    . (Join-Path $root 'modules\github_client.ps1')
    . (Join-Path $root 'modules\inventory.ps1')
    . (Join-Path $root 'modules\semantic_audit.ps1')
    . (Join-Path $root 'modules\report_builder.ps1')

    if (Test-Path -LiteralPath $workspace) {
        Get-ChildItem -LiteralPath $workspace -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    }

    Write-Host "Fetching repository..."

    $snapshot = Get-GitHubRepoSnapshot `
        -Owner $config.repo_owner `
        -Repo $config.repo_name `
        -Branch $config.branch `
        -Token $token `
        -Destination $workspace

    Write-Host "Building inventory..."
    $inventory = Build-SiteInventory -Path $snapshot

    Write-Host "Running semantic audit..."
    $semantic = Run-SemanticAudit -Inventory $inventory

    Write-Host "Building report..."
    $zip = Build-AuditReport `
        -Inventory $inventory `
        -Semantic $semantic `
        -Outbox $outbox

    Write-Host ""
    Write-Host "AUDIT COMPLETE"
    Write-Host $zip

    Start-Process explorer.exe $outbox
}
