SITE_AUDITOR_AGENT FIXED PACKAGE

1 Put GitHub token into:
.state/github_token.txt

2 Edit config:
config/agent.config.json

3 Run:
CREATE_SHORTCUT.ps1

4 Click:
SITE AUDIT (Desktop)

Result:
outbox/SITE_AUDIT_PACK_*.zip
