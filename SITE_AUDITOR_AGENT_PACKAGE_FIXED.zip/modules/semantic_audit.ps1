function Run-SemanticAudit {

param($Inventory)

$issues = @()

foreach($file in $Inventory.files){

    if($file -match "\.md$"){

        $content = Get-Content -LiteralPath $file -Raw

        if($content -notmatch "(?im)^\s*title\s*:"){
            $issues += @{
                class="TITLE_MISSING"
                file=$file
                severity="P1"
            }
        }

        if($content -notmatch "(?im)^\s*description\s*:"){
            $issues += @{
                class="META_DESC_MISSING"
                file=$file
                severity="P2"
            }
        }
    }
}

return $issues
}
