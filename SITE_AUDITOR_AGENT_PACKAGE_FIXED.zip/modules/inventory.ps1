function Build-SiteInventory {

param([string]$Path)

$files = Get-ChildItem -LiteralPath $Path -Recurse -File

$pages = $files | Where-Object {
    $_.Extension -in ".md",".html",".njk"
}

return @{
    total_files = $files.Count
    pages = $pages.Count
    files = $files.FullName
}
}
