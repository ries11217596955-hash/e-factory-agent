function Get-GitHubRepoSnapshot {

param(
[string]$Owner,
[string]$Repo,
[string]$Branch,
[string]$Token,
[string]$Destination
)

$headers = @{
Authorization = "token $Token"
User-Agent = "SITE_AUDITOR_AGENT"
}

$url = "https://api.github.com/repos/$Owner/$Repo/zipball/$Branch"
$zip = Join-Path $Destination "repo.zip"

Invoke-WebRequest -Uri $url -Headers $headers -OutFile $zip -UseBasicParsing

Expand-Archive -LiteralPath $zip -DestinationPath $Destination -Force

Remove-Item -LiteralPath $zip -Force

$folder = Get-ChildItem -LiteralPath $Destination -Directory | Select-Object -First 1

if (-not $folder) {
    throw "SNAPSHOT_EXTRACT_FAILED: no extracted folder found"
}

return $folder.FullName
}
