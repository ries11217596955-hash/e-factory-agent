function Build-AuditReport {

param(
$Inventory,
$Semantic,
[string]$Outbox
)

$time = Get-Date -Format "yyyyMMdd_HHmm"

$report = Join-Path $Outbox "SITE_AUDIT_REPORT_$time.md"
$defects = Join-Path $Outbox "SITE_DEFECTS_$time.json"

@"
# SITE AUDIT REPORT

Files scanned: $($Inventory.total_files)
Pages detected: $($Inventory.pages)

Semantic issues: $($Semantic.Count)
"@ | Out-File -LiteralPath $report -Encoding utf8

$Semantic | ConvertTo-Json -Depth 5 | Out-File -LiteralPath $defects -Encoding utf8

$zip = Join-Path $Outbox "SITE_AUDIT_PACK_$time.zip"

Compress-Archive `
-Path $report,$defects `
-DestinationPath $zip `
-Force

Remove-Item -LiteralPath $report -Force
Remove-Item -LiteralPath $defects -Force

return $zip
}
