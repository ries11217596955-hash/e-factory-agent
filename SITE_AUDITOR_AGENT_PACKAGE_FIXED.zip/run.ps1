$ErrorActionPreference = "Stop"

$root = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($root)) {
    throw "ROOT_NOT_RESOLVED: PSScriptRoot is empty"
}

Set-Location -LiteralPath $root

. (Join-Path $root 'agent.ps1')

Invoke-SiteAudit
