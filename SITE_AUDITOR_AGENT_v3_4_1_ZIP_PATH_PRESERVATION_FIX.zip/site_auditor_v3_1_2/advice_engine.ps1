function Invoke-AdviceEngine {
    param(
        [string]$ReportDir,
        [string]$TargetConfigPath
    )

    function Load-JsonSafe {
        param([string]$Path)
        if ([string]::IsNullOrWhiteSpace($Path)) { return $null }
        if (!(Test-Path -LiteralPath $Path)) { return $null }
        try {
            return (Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json)
        }
        catch {
            return $null
        }
    }

    function Add-Item {
        param(
            [System.Collections.ArrayList]$Bucket,
            [object]$Item
        )
        $null = $Bucket.Add($Item)
    }

    function Test-IgnoredRoute {
        param([string]$Route, [object]$InventoryItem)

        if ([string]::IsNullOrWhiteSpace($Route)) { return $true }
        if ($Route -eq "/404/") { return $true }
        if ($Route -eq "/search/") { return $true }
        if ($Route -like "/search/*") { return $true }
        if ($Route -eq "/tags/") { return $true }
        if ($Route -like "/tags/*") { return $true }
        if ($Route -like "/*archive*/") { return $true }

        if ($null -ne $InventoryItem) {
            $isPublishable = $null
            $contentRole = $null
            try { $isPublishable = $InventoryItem.is_publishable } catch {}
            try { $contentRole = $InventoryItem.content_role } catch {}

            if ($isPublishable -eq $false) { return $true }
            if ($contentRole -eq "service_or_debug") { return $true }
        }

        return $false
    }

    function New-GroupedIssue {
        param(
            [string]$Type,
            [string]$Severity,
            [string]$Scope,
            [string]$LikelyFix,
            [string]$Action,
            [string]$ActionTarget,
            [string]$ActionInstruction,
            [int]$AffectedCount,
            [object[]]$AffectedItems,
            [hashtable]$Extra
        )

        $obj = [ordered]@{
            type = $Type
            severity = $Severity
            scope = $Scope
            likely_fix = $LikelyFix
            affected_count = $AffectedCount
            action = [ordered]@{
                type = $Action
                target = $ActionTarget
                instruction = $ActionInstruction
            }
            affected_items = $AffectedItems
        }

        if ($null -ne $Extra) {
            foreach ($k in $Extra.Keys) {
                if (-not $obj.Contains($k)) {
                    $obj[$k] = $Extra[$k]
                }
            }
        }

        return [PSCustomObject]$obj
    }

    function Get-RouteSegments {
        param([string]$Route)
        if ([string]::IsNullOrWhiteSpace($Route)) { return @() }
        $trimmed = $Route.Trim("/")
        if ([string]::IsNullOrWhiteSpace($trimmed)) { return @() }
        return @($trimmed.Split("/") | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    }

    function Normalize-Token {
        param([string]$Value, [string]$Fallback)
        if ([string]::IsNullOrWhiteSpace($Value)) { return $Fallback }
        $v = $Value.ToLowerInvariant()
        $chars = $v.ToCharArray() | Where-Object { ($_ -match '[a-z0-9\-]') }
        $clean = -join $chars
        if ([string]::IsNullOrWhiteSpace($clean)) { return $Fallback }
        if ($clean.Length -lt 2) { return $Fallback }
        return $clean
    }

    function Get-OrphanGroupMeta {
        param([string]$Route, [object]$InventoryItem)

        $segments = Get-RouteSegments -Route $Route
        $family = if ($segments.Count -gt 0) { Normalize-Token -Value $segments[0] -Fallback "root" } else { "root" }
        $subfamily = if ($segments.Count -gt 1) { Normalize-Token -Value $segments[1] -Fallback "misc" } else { "misc" }

        $clusterId = $null
        $pageType = $null
        try { $clusterId = $InventoryItem.cluster_id } catch {}
        try { $pageType = $InventoryItem.page_type } catch {}

        $clusterNorm = Normalize-Token -Value $clusterId -Fallback ""

        if ($pageType -eq "hub") {
            return [PSCustomObject]@{
                group_key = "hub:" + $family
                scope = "hub:" + $family
                severity = "P1"
                family = "hub"
                chunk_size = 10
                instruction = "Restore navigation links to the affected hub routes from main navigation or section index pages"
            }
        }

        # Stabilize common families first, even if cluster_id is noisy.
        if ($family -eq "posts") {
            if ($subfamily -ne "misc") {
                return [PSCustomObject]@{
                    group_key = "posts-subfamily:" + $subfamily
                    scope = "posts/" + $subfamily
                    severity = "P2"
                    family = "posts"
                    chunk_size = 15
                    instruction = "Add internal links from posts indexes, related-post widgets, or topic pages to this posts subfamily"
                }
            }
            return [PSCustomObject]@{
                group_key = "posts-root"
                scope = "posts/root"
                severity = "P2"
                family = "posts"
                chunk_size = 15
                instruction = "Add internal links from the posts index or nearby navigation blocks to the affected post routes"
            }
        }

        if ($family -eq "tools") {
            return [PSCustomObject]@{
                group_key = "tools"
                scope = "tools"
                severity = "P2"
                family = "tools"
                chunk_size = 12
                instruction = "Add internal links from the tools hub, tools index, or related-tools blocks to the affected routes"
            }
        }

        if ($family -eq "news") {
            return [PSCustomObject]@{
                group_key = "news"
                scope = "news"
                severity = "P2"
                family = "news"
                chunk_size = 12
                instruction = "Add internal links from the news hub, news index, or related-news blocks to the affected routes"
            }
        }

        if ($family -eq "hubs") {
            return [PSCustomObject]@{
                group_key = "hubs"
                scope = "hubs"
                severity = "P1"
                family = "hubs"
                chunk_size = 10
                instruction = "Restore navigation links to the affected hub routes from section indexes or main navigation"
            }
        }

        if (-not [string]::IsNullOrWhiteSpace($clusterNorm) -and $clusterNorm -notin @("posts","tools","news","hubs","misc","root")) {
            return [PSCustomObject]@{
                group_key = "cluster:" + $clusterNorm
                scope = "cluster:" + $clusterNorm
                severity = "P1"
                family = "cluster"
                chunk_size = 20
                instruction = "Add internal links from the matching cluster hub or cluster entry pages to the affected routes"
            }
        }

        return [PSCustomObject]@{
            group_key = "general:" + $family
            scope = $family
            severity = "P2"
            family = $family
            chunk_size = 12
            instruction = "Add internal links from a relevant navigation block or parent page to the affected routes"
        }
    }

    function Split-ItemsIntoChunks {
        param(
            [object[]]$Items,
            [int]$ChunkSize
        )

        $result = New-Object System.Collections.ArrayList
        if ($ChunkSize -lt 1) { $ChunkSize = 20 }
        if ($Items.Count -le $ChunkSize) {
            $null = $result.Add(@($Items))
            return @($result)
        }

        for ($i = 0; $i -lt $Items.Count; $i += $ChunkSize) {
            $upper = [Math]::Min($i + $ChunkSize - 1, $Items.Count - 1)
            $chunk = @()
            for ($j = $i; $j -le $upper; $j++) {
                $chunk += $Items[$j]
            }
            $null = $result.Add($chunk)
        }

        return @($result)
    }

    if (!(Test-Path -LiteralPath $ReportDir)) {
        New-Item -ItemType Directory -Path $ReportDir -Force | Out-Null
    }

    $inventory = Load-JsonSafe -Path (Join-Path $ReportDir "01_INVENTORY.json")
    $brokenLinks = Load-JsonSafe -Path (Join-Path $ReportDir "03_BROKEN_LINKS.json")
    $orphans = Load-JsonSafe -Path (Join-Path $ReportDir "04_ORPHAN_PAGES.json")
    $renderAudit = Load-JsonSafe -Path (Join-Path $ReportDir "06_RENDER_AUDIT.json")
    $targetAlignment = Load-JsonSafe -Path (Join-Path $ReportDir "08_TARGET_ALIGNMENT.json")
    $stageAssessment = Load-JsonSafe -Path (Join-Path $ReportDir "09_STAGE_ASSESSMENT.json")

    $inventoryMap = @{}
    foreach ($item in @($inventory)) {
        $route = $null
        try { $route = $item.route } catch {}
        if (-not [string]::IsNullOrWhiteSpace($route)) {
            $inventoryMap[$route] = $item
        }
    }

    $issues = New-Object System.Collections.ArrayList
    $suppressed = New-Object System.Collections.ArrayList
    $executionOrder = New-Object System.Collections.ArrayList

    foreach ($route in @($targetAlignment.missing_required_routes)) {
        $issue = New-GroupedIssue `
            -Type "missing_required_route" `
            -Severity "P0" `
            -Scope $route `
            -LikelyFix "Create the required route and ensure it is included in the build output" `
            -Action "create_page" `
            -ActionTarget $route `
            -ActionInstruction "Create or restore this required route and make sure it is published in the generated site" `
            -AffectedCount 1 `
            -AffectedItems @([PSCustomObject]@{ route = $route }) `
            -Extra @{}
        Add-Item -Bucket $issues -Item $issue
    }

    foreach ($cluster in @($targetAlignment.required_clusters)) {
        if ($cluster.actual_pages -lt $cluster.min_pages) {
            $cid = Normalize-Token -Value $cluster.cluster_id -Fallback "cluster"
            $issue = New-GroupedIssue `
                -Type "cluster_underfilled" `
                -Severity "P1" `
                -Scope $cid `
                -LikelyFix "Add more publishable pages to this cluster until the minimum page target is reached" `
                -Action "expand_cluster" `
                -ActionTarget $cid `
                -ActionInstruction "Publish additional pages in this cluster until it reaches the target minimum" `
                -AffectedCount 1 `
                -AffectedItems @([PSCustomObject]@{
                    cluster_id = $cid
                    actual_pages = $cluster.actual_pages
                    min_pages = $cluster.min_pages
                }) `
                -Extra @{ cluster_id = $cid; actual_pages = $cluster.actual_pages; min_pages = $cluster.min_pages }
            Add-Item -Bucket $issues -Item $issue
        }

        if (-not $cluster.hub_present) {
            $cid = Normalize-Token -Value $cluster.cluster_id -Fallback "cluster"
            $hubRoute = "/$cid/"
            $issue = New-GroupedIssue `
                -Type "cluster_hub_missing" `
                -Severity "P1" `
                -Scope $cid `
                -LikelyFix "Create or restore the hub route for this cluster and link cluster pages to it" `
                -Action "create_cluster_hub" `
                -ActionTarget $hubRoute `
                -ActionInstruction "Create the hub route for this cluster and connect member pages to it" `
                -AffectedCount 1 `
                -AffectedItems @([PSCustomObject]@{ cluster_id = $cid; expected_hub = $hubRoute }) `
                -Extra @{ cluster_id = $cid; expected_hub = $hubRoute }
            Add-Item -Bucket $issues -Item $issue
        }
    }

    $orphanGroups = @{}
    foreach ($item in @($orphans)) {
        $route = $null
        try { $route = $item.route } catch {}
        if ([string]::IsNullOrWhiteSpace($route)) { continue }

        $inventoryItem = $null
        if ($inventoryMap.ContainsKey($route)) { $inventoryItem = $inventoryMap[$route] }

        if (Test-IgnoredRoute -Route $route -InventoryItem $inventoryItem) {
            Add-Item -Bucket $suppressed -Item ([PSCustomObject]@{
                type = "orphan_page"
                route = $route
                reason = "ignored_route_or_non_publishable"
            })
            continue
        }

        $meta = Get-OrphanGroupMeta -Route $route -InventoryItem $inventoryItem
        if (-not $orphanGroups.ContainsKey($meta.group_key)) {
            $orphanGroups[$meta.group_key] = [ordered]@{
                severity = $meta.severity
                scope = $meta.scope
                family = $meta.family
                chunk_size = $meta.chunk_size
                instruction = $meta.instruction
                items = New-Object System.Collections.ArrayList
            }
        }

        Add-Item -Bucket $orphanGroups[$meta.group_key].items -Item ([PSCustomObject]@{
            route = $route
            file = $item.file
            cluster_id = $(try { $inventoryItem.cluster_id } catch { $null })
            page_type = $(try { $inventoryItem.page_type } catch { $null })
        })
    }

    foreach ($groupKey in $orphanGroups.Keys) {
        $group = $orphanGroups[$groupKey]
        $items = @($group.items | Sort-Object route)
        $chunks = Split-ItemsIntoChunks -Items $items -ChunkSize $group.chunk_size
        $chunkIndex = 1

        foreach ($chunk in @($chunks)) {
            $scope = $group.scope
            if (@($chunks).Count -gt 1) {
                $scope = $scope + "#batch-" + $chunkIndex
            }

            $issue = New-GroupedIssue `
                -Type "orphan_group" `
                -Severity $group.severity `
                -Scope $scope `
                -LikelyFix "Connect the affected routes through internal navigation in operational batches instead of fixing them one by one" `
                -Action "add_internal_links_batch" `
                -ActionTarget $scope `
                -ActionInstruction $group.instruction `
                -AffectedCount @($chunk).Count `
                -AffectedItems @($chunk) `
                -Extra @{
                    family = $group.family
                    batch_index = $chunkIndex
                    batch_total = @($chunks).Count
                }

            Add-Item -Bucket $issues -Item $issue
            $chunkIndex++
        }
    }

    $brokenBySource = @{}
    foreach ($item in @($brokenLinks)) {
        $sourceRoute = $null
        $targetRoute = $null
        $badLink = $null
        $issueType = $null

        try { $sourceRoute = $item.source_route } catch {}
        try { $targetRoute = $item.target_route } catch {}
        try { $badLink = $item.bad_link } catch {}
        try { $issueType = $item.issue_type } catch {}

        if ($issueType -eq "TEMPLATE_EXPRESSION_NOT_RENDERED") {
            Add-Item -Bucket $suppressed -Item ([PSCustomObject]@{
                type = "broken_link"
                route = $sourceRoute
                reason = "template_expression"
            })
            continue
        }

        if (-not [string]::IsNullOrWhiteSpace($badLink) -and ($badLink -match "^\{\{.*\}\}$")) {
            Add-Item -Bucket $suppressed -Item ([PSCustomObject]@{
                type = "broken_link"
                route = $sourceRoute
                reason = "template_expression"
            })
            continue
        }

        $sourceItem = $null
        if ($inventoryMap.ContainsKey($sourceRoute)) { $sourceItem = $inventoryMap[$sourceRoute] }

        if (Test-IgnoredRoute -Route $sourceRoute -InventoryItem $sourceItem) {
            Add-Item -Bucket $suppressed -Item ([PSCustomObject]@{
                type = "broken_link"
                route = $sourceRoute
                reason = "ignored_source_route"
            })
            continue
        }

        $classification = "internal"
        $severity = "P1"
        if (-not [string]::IsNullOrWhiteSpace($badLink) -and ($badLink -match '^(http|https)://')) {
            $classification = "external"
            $severity = "P2"
        }
        elseif ([string]::IsNullOrWhiteSpace($targetRoute)) {
            $classification = "unresolved"
            $severity = "P2"
        }

        if ([string]::IsNullOrWhiteSpace($sourceRoute)) {
            $sourceRoute = "unknown_source"
        }

        if (-not $brokenBySource.ContainsKey($sourceRoute)) {
            $brokenBySource[$sourceRoute] = [ordered]@{
                severity = $severity
                classification = $classification
                items = New-Object System.Collections.ArrayList
            }
        }

        if ($severity -eq "P1") { $brokenBySource[$sourceRoute].severity = "P1" }
        if ($classification -eq "internal") { $brokenBySource[$sourceRoute].classification = "internal" }

        Add-Item -Bucket $brokenBySource[$sourceRoute].items -Item ([PSCustomObject]@{
            source_route = $sourceRoute
            target_route = $targetRoute
            bad_link = $badLink
            issue_type = $issueType
            classification = $classification
        })
    }

    foreach ($sourceRoute in $brokenBySource.Keys) {
        $group = $brokenBySource[$sourceRoute]
        $instruction = "Edit this source page and replace or remove the broken links listed below"
        if ($group.classification -eq "internal") {
            $instruction = "Edit this source page and point the broken internal links to valid routes or create the missing targets"
        }

        $issue = New-GroupedIssue `
            -Type "broken_link_group" `
            -Severity $group.severity `
            -Scope $sourceRoute `
            -LikelyFix "Fix the source page once and resolve all broken links on that page in one edit pass" `
            -Action "edit_source_page_links" `
            -ActionTarget $sourceRoute `
            -ActionInstruction $instruction `
            -AffectedCount @($group.items).Count `
            -AffectedItems @($group.items) `
            -Extra @{ classification = $group.classification }
        Add-Item -Bucket $issues -Item $issue
    }

    foreach ($item in @($renderAudit)) {
        $status = $null
        $route = $null
        try { $status = $item.status } catch {}
        try { $route = $item.route } catch {}

        $inventoryItem = $null
        if ($inventoryMap.ContainsKey($route)) { $inventoryItem = $inventoryMap[$route] }

        if (Test-IgnoredRoute -Route $route -InventoryItem $inventoryItem) { continue }
        if ($status -eq "OK") { continue }

        $issue = New-GroupedIssue `
            -Type "render_failure" `
            -Severity "P1" `
            -Scope $route `
            -LikelyFix "Inspect the route rendering chain and fix the template, layout, or generated HTML error" `
            -Action "fix_render_chain" `
            -ActionTarget $route `
            -ActionInstruction "Open the failing route, inspect the template and generated HTML, then fix the render error before other content cleanup" `
            -AffectedCount 1 `
            -AffectedItems @([PSCustomObject]@{
                route = $route
                status = $item.status
                reason = $item.reason
                status_code = $item.status_code
            }) `
            -Extra @{}
        Add-Item -Bucket $issues -Item $issue
    }

    $ordered = @(
        @($issues | Where-Object { $_.severity -eq "P0" }),
        @($issues | Where-Object { $_.severity -eq "P1" }),
        @($issues | Where-Object { $_.severity -eq "P2" }),
        @($issues | Where-Object { $_.severity -notin @("P0","P1","P2") })
    ) | ForEach-Object { $_ }

    $index = 1
    foreach ($issue in @($ordered)) {
        Add-Item -Bucket $executionOrder -Item ([PSCustomObject]@{
            priority = $index
            type = $issue.type
            scope = $issue.scope
            action = $issue.action.type
            target = $issue.action.target
        })
        $index++
    }

    $summary = [ordered]@{
        generated_at = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        total = @($ordered).Count
        by_severity = [ordered]@{
            P0 = @($ordered | Where-Object { $_.severity -eq "P0" }).Count
            P1 = @($ordered | Where-Object { $_.severity -eq "P1" }).Count
            P2 = @($ordered | Where-Object { $_.severity -eq "P2" }).Count
        }
        build_stage = $null
        suppressed_count = @($suppressed).Count
        execution_order = $executionOrder
        suppressed = $suppressed
        issues = $ordered
    }

    if ($stageAssessment) {
        try { $summary.build_stage = $stageAssessment.build_stage } catch {}
    }

    $outPath = Join-Path $ReportDir "11_HOW_TO_FIX.json"
    ([PSCustomObject]$summary | ConvertTo-Json -Depth 12) | Out-File -LiteralPath $outPath -Encoding utf8
}
