function Resolve-InventoryLinkRoute {
    param(
        [string]$Link,
        [string]$CurrentRoute
    )

    if ([string]::IsNullOrWhiteSpace($Link)) { return $null }
    if ($Link -match '^(http|https|mailto|tel):') { return $null }
    if ($Link.StartsWith('#')) { return $CurrentRoute }

    $linkOnly = $Link.Split('#')[0].Split('?')[0]
    if ([string]::IsNullOrWhiteSpace($linkOnly)) { return $CurrentRoute }

    if ($linkOnly.StartsWith('/')) {
        $route = $linkOnly
    }
    else {
        $base = $CurrentRoute
        if (-not $base.EndsWith('/')) { $base = $base + '/' }
        $route = $base + $linkOnly
    }

    $route = $route -replace '/+','/'
    $parts = New-Object System.Collections.Generic.List[string]
    foreach ($part in ($route -split '/')) {
        if ($part -eq '' -or $part -eq '.') { continue }
        if ($part -eq '..') {
            if ($parts.Count -gt 0) { $parts.RemoveAt($parts.Count - 1) }
            continue
        }
        $parts.Add($part)
    }

    $normalized = '/' + (($parts -join '/').Trim('/'))
    if ([string]::IsNullOrWhiteSpace($normalized) -or $normalized -eq '/') { return '/' }
    return $normalized + '/'
}

function Invoke-LinksAudit {
    param($Inventory)

    $pages = @($Inventory | Where-Object { $_.is_publishable })
    $routeMap = @{}
    foreach ($item in $pages) {
        $routeMap[$item.route] = $item
    }

    $incoming = @{}
    $navEdges = @()
    foreach ($item in $pages) {
        $incoming[$item.route] = 0
    }

    $broken = @()

    foreach ($item in $pages) {
        foreach ($lnk in @($item.links)) {
            $targetRoute = Resolve-InventoryLinkRoute -Link $lnk -CurrentRoute $item.route
            if (-not $targetRoute) { continue }

            if ($routeMap.ContainsKey($targetRoute)) {
                $incoming[$targetRoute] = [int]$incoming[$targetRoute] + 1
                $navEdges += [PSCustomObject]@{
                    source_route = $item.route
                    target_route = $targetRoute
                }
            }
            else {
                $broken += [PSCustomObject]@{
                    source_file  = $item.file
                    source_route = $item.route
                    bad_link     = $lnk
                    target_route = $targetRoute
                    severity     = 'P1'
                }
            }
        }
    }

    $orphans = @()
    foreach ($item in $pages) {
        if ($item.route -eq '/') { continue }
        if ([int]$incoming[$item.route] -eq 0) {
            $orphans += [PSCustomObject]@{
                file     = $item.file
                route    = $item.route
                severity = 'P2'
            }
        }
    }

    $navGraph = foreach ($item in $pages) {
        $outgoing = @($navEdges | Where-Object { $_.source_route -eq $item.route }).Count
        [PSCustomObject]@{
            route          = $item.route
            page_type      = $item.page_type
            cluster_id     = $item.cluster_id
            incoming_count = [int]$incoming[$item.route]
            outgoing_count = $outgoing
        }
    }

    return [PSCustomObject]@{
        BrokenLinks = $broken
        Orphans     = $orphans
        NavGraph    = $navGraph
    }
}
