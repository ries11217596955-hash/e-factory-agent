function Normalize-FrontMatterValue {
    param([string]$Value)

    if ($null -eq $Value) { return $null }

    $clean = $Value.Trim()
    $chars = [char[]]@("'", '"', ' ', "`t")
    $clean = $clean.Trim($chars)
    if ([string]::IsNullOrWhiteSpace($clean)) { return $null }
    return $clean
}

function Get-RelativeRepoPath {
    param(
        [string]$RepoPath,
        [string]$FilePath
    )

    return $FilePath.Substring($RepoPath.Length).TrimStart("\", "/") -replace '\\','/'
}

function Convert-RepoPathToRoute {
    param(
        [string]$RepoPath,
        [string]$FilePath,
        [string]$BaseUrl
    )

    $relative = Get-RelativeRepoPath -RepoPath $RepoPath -FilePath $FilePath
    $normalized = $relative

    if ($normalized -match '^src/') {
        $normalized = $normalized.Substring(4)
    }

    $route = $normalized
    $route = $route -replace '/index\.(md|html|njk)$','/'
    $route = $route -replace '\.(md|html|njk)$','/'
    $route = $route -replace '/+','/'
    if (-not $route.StartsWith('/')) { $route = '/' + $route }
    if ($route -ne '/' -and -not $route.EndsWith('/')) { $route = $route + '/' }

    $fullUrl = $BaseUrl.TrimEnd('/') + $route

    return [PSCustomObject]@{
        relative_path = $normalized
        route         = $route
        full_url      = $fullUrl
    }
}

function Get-ClusterIdFromPath {
    param([string]$RelativePath)

    $norm = $RelativePath.ToLowerInvariant()
    if ($norm -match '^src/posts/') { return 'posts' }
    if ($norm -match '^src/tools/') { return 'tools' }
    if ($norm -match '^src/hubs/news/' -or $norm -match '^src/news/') { return 'news' }
    return $null
}

function Get-PageType {
    param(
        [string]$Route,
        [string]$RelativePath
    )

    $norm = $RelativePath.ToLowerInvariant()
    if ($Route -eq '/') { return 'home' }
    if ($norm -match '^src/(posts|tools|news)/index\.' -or $norm -match '^src/hubs/.+/index\.') { return 'hub' }
    if ($Route -match '^/(about|contact|privacy|terms)/$') { return 'legal_or_core' }
    return 'article'
}

function Test-IsPublishableCandidate {
    param(
        [string]$RelativePath,
        [object]$Config
    )

    $norm = "/" + $RelativePath.ToLowerInvariant()
    if (-not $norm.StartsWith("/src/")) { return $false }

    foreach ($pattern in @($Config.exclude_path_contains)) {
        if (-not [string]::IsNullOrWhiteSpace($pattern)) {
            $p = $pattern.ToLowerInvariant()
            if ($norm.Contains($p)) { return $false }
        }
    }

    if ($norm -match '/(_includes|layouts|partials|snippets|macros|shortcodes)/') { return $false }
    if ($norm -match '/(_data|data)/') { return $false }
    if ($norm -match '/(assets|images|img|css|js|fonts)/') { return $false }

    return $true
}

function Get-ContentRole {
    param(
        [string]$RelativePath,
        [bool]$IsPublishable
    )

    $norm = "/" + $RelativePath.ToLowerInvariant()

    if ($IsPublishable) { return 'publishable_page' }
    if ($norm -match '/(_includes|layouts|partials|snippets|macros|shortcodes)/') { return 'layout_or_template' }
    if ($norm -match '/(_data|data)/') { return 'data_or_support' }
    if ($norm -match '/(governance|memory|docs)/') { return 'governance_or_memory' }
    return 'service_or_debug'
}

function Build-SiteInventory {
    param(
        [string]$RepoPath,
        [string]$BaseUrl,
        [object]$Config
    )

    $files = Get-ChildItem -LiteralPath $RepoPath -Recurse -File | Where-Object {
        $_.Extension -in '.md','.html','.njk'
    }

    $inventory = @()

    foreach ($f in $files) {
        $content = Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8
        $relative = Get-RelativeRepoPath -RepoPath $RepoPath -FilePath $f.FullName
        $routeInfo = Convert-RepoPathToRoute -RepoPath $RepoPath -FilePath $f.FullName -BaseUrl $BaseUrl
        $isPublishable = Test-IsPublishableCandidate -RelativePath $relative -Config $Config
        $contentRole = Get-ContentRole -RelativePath $relative -IsPublishable $isPublishable
        $clusterId = Get-ClusterIdFromPath -RelativePath $relative
        $pageType = Get-PageType -Route $routeInfo.route -RelativePath $relative

        $title = $null
        $description = $null
        $permalink = $null
        $links = @()

        if ($content -match '(?im)^title\s*:\s*(.+)$') {
            $title = Normalize-FrontMatterValue -Value $Matches[1]
        }
        if ($content -match '(?im)^description\s*:\s*(.+)$') {
            $description = Normalize-FrontMatterValue -Value $Matches[1]
        }
        if ($content -match '(?im)^permalink\s*:\s*(.+)$') {
            $permalink = Normalize-FrontMatterValue -Value $Matches[1]
        }

        $route = $routeInfo.route
        $fullUrl = $routeInfo.full_url
        if ($permalink) {
            $route = if ($permalink.StartsWith('/')) { $permalink } else { '/' + $permalink }
            if ($route -ne '/' -and -not $route.EndsWith('/')) { $route = $route + '/' }
            $fullUrl = $BaseUrl.TrimEnd('/') + $route
        }

        $regexes = @(
            'href\s*=\s*"([^"]+)"',
            "href\s*=\s*'([^']+)'",
            '\[[^\]]+\]\(([^\)]+)\)'
        )
        foreach ($pattern in $regexes) {
            foreach ($m in [regex]::Matches($content, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
                if ($m.Groups.Count -gt 1) {
                    $val = $m.Groups[1].Value.Trim()
                    if ($val) { $links += $val }
                }
            }
        }
        $links = $links | Select-Object -Unique

        $inventory += [PSCustomObject]@{
            file            = $routeInfo.relative_path
            source_path     = $f.FullName
            title           = $title
            description     = $description
            permalink       = $permalink
            route           = $route
            full_url        = $fullUrl
            links           = @($links)
            is_publishable  = [bool]$isPublishable
            content_role    = $contentRole
            cluster_id      = $clusterId
            page_type       = $pageType
        }
    }

    return $inventory
}
