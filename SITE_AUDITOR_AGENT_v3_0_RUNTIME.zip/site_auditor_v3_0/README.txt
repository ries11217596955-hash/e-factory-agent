SITE_AUDITOR_AGENT v3.0

Runtime profile:
- one run -> one ZIP report
- GitHub API ZIP fetch (git not required)
- target-aware audit baseline
- desktop shortcut included

See README_RUN.txt for install/start steps.
