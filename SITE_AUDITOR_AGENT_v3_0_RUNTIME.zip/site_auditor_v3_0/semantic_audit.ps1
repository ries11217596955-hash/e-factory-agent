function Invoke-SemanticAudit {
    param($Inventory)

    $issues = @()
    $pages = @($Inventory | Where-Object { $_.is_publishable })

    foreach ($p in $pages) {
        if (-not $p.title) {
            $issues += [PSCustomObject]@{
                type = 'TITLE_MISSING'
                severity = 'P1'
                file = $p.file
                route = $p.route
            }
        }
        elseif ($p.title.Length -lt 20) {
            $issues += [PSCustomObject]@{
                type = 'TITLE_TOO_SHORT'
                severity = 'P3'
                file = $p.file
                route = $p.route
                value = $p.title
            }
        }
        elseif ($p.title.Length -gt 65) {
            $issues += [PSCustomObject]@{
                type = 'TITLE_TOO_LONG'
                severity = 'P3'
                file = $p.file
                route = $p.route
                value = $p.title
            }
        }

        if (-not $p.description) {
            $issues += [PSCustomObject]@{
                type = 'META_DESC_MISSING'
                severity = 'P2'
                file = $p.file
                route = $p.route
            }
        }
        elseif ($p.description.Length -lt 70) {
            $issues += [PSCustomObject]@{
                type = 'META_DESC_TOO_SHORT'
                severity = 'P3'
                file = $p.file
                route = $p.route
                value = $p.description
            }
        }
        elseif ($p.description.Length -gt 180) {
            $issues += [PSCustomObject]@{
                type = 'META_DESC_TOO_LONG'
                severity = 'P3'
                file = $p.file
                route = $p.route
                value = $p.description
            }
        }

        if (-not $p.permalink) {
            $issues += [PSCustomObject]@{
                type = 'PERMALINK_MISSING'
                severity = 'P3'
                file = $p.file
                route = $p.route
            }
        }
    }

    $dupeGroups = $pages | Where-Object { -not [string]::IsNullOrWhiteSpace($_.title) } | Group-Object -Property title | Where-Object { $_.Count -gt 1 }
    foreach ($grp in $dupeGroups) {
        foreach ($item in $grp.Group) {
            $issues += [PSCustomObject]@{
                type = 'TITLE_DUPLICATE'
                severity = 'P2'
                file = $item.file
                route = $item.route
                value = $grp.Name
            }
        }
    }

    return $issues
}
