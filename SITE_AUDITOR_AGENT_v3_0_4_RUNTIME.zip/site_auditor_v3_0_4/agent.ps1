function Get-AgentRoot {
    $root = $PSScriptRoot
    if (-not $root) { $root = Split-Path -Parent $MyInvocation.MyCommand.Path }
    return $root
}

function Get-AgentConfig {
    param([string]$ConfigPath)

    if (!(Test-Path -LiteralPath $ConfigPath)) { throw "CONFIG_NOT_FOUND: $ConfigPath" }
    $raw = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8
    if ([string]::IsNullOrWhiteSpace($raw)) { throw "CONFIG_EMPTY: $ConfigPath" }

    try { return ($raw | ConvertFrom-Json) }
    catch { throw "CONFIG_JSON_INVALID: $ConfigPath" }
}

function Get-GitHubToken {
    param([string]$TokenPath)

    if (!(Test-Path -LiteralPath $TokenPath)) { throw "TOKEN_FILE_NOT_FOUND: $TokenPath" }
    $token = (Get-Content -LiteralPath $TokenPath -Raw -Encoding UTF8).Trim()
    if ([string]::IsNullOrWhiteSpace($token)) { throw "TOKEN_EMPTY" }
    return $token
}

function Remove-DirectorySafe {
    param([string]$Path)

    if (Test-Path -LiteralPath $Path) {
        try {
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
        }
        catch {
            Write-Host "[WARN] REMOVE_PATH_FAILED: $Path :: $($_.Exception.Message)"
        }
    }
}

function Expand-RepoZipToTarget {
    param(
        [string]$ZipPath,
        [string]$ExtractRoot,
        [string]$TargetPath
    )

    Add-Type -AssemblyName System.IO.Compression.FileSystem

    Remove-DirectorySafe -Path $ExtractRoot
    Remove-DirectorySafe -Path $TargetPath

    New-Item -ItemType Directory -Force -Path $ExtractRoot | Out-Null
    New-Item -ItemType Directory -Force -Path $TargetPath | Out-Null

    $zip = $null
    try {
        $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
        foreach ($entry in $zip.Entries) {
            if ([string]::IsNullOrWhiteSpace($entry.FullName)) { continue }

            $entryName = $entry.FullName -replace '/', [IO.Path]::DirectorySeparatorChar
            $entryName = $entryName.TrimStart('\','/')
            if ([string]::IsNullOrWhiteSpace($entryName)) { continue }

            $dest = Join-Path $ExtractRoot $entryName

            if ($entry.FullName.EndsWith('/')) {
                New-Item -ItemType Directory -Force -Path $dest | Out-Null
                continue
            }

            $parent = Split-Path -Parent $dest
            if (-not [string]::IsNullOrWhiteSpace($parent) -and !(Test-Path -LiteralPath $parent)) {
                New-Item -ItemType Directory -Force -Path $parent | Out-Null
            }

            try {
                [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $dest, $true)
            }
            catch {
                throw "ZIP_ENTRY_EXTRACT_FAILED: $($entry.FullName) => $dest :: $($_.Exception.Message)"
            }
        }
    }
    finally {
        if ($zip) { $zip.Dispose() }
    }

    $topDir = Get-ChildItem -LiteralPath $ExtractRoot -Directory | Select-Object -First 1
    if (-not $topDir) { throw "ZIP_TOP_DIR_NOT_FOUND" }

    Get-ChildItem -LiteralPath $topDir.FullName -Force | ForEach-Object {
        Move-Item -LiteralPath $_.FullName -Destination $TargetPath -Force
    }
}

function Download-RepoZipViaApi {
    param(
        [string]$RepoOwner,
        [string]$RepoName,
        [string]$Branch,
        [string]$Token,
        [string]$WorkPath,
        [string]$TargetPath
    )

    $zipUrl = "https://api.github.com/repos/$RepoOwner/$RepoName/zipball/$Branch"
    $zipPath = Join-Path $WorkPath "repo.zip"
    $extractPath = Join-Path $WorkPath "x"

    if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }

    $headers = @{
        Authorization = "Bearer $Token"
        Accept        = "application/vnd.github+json"
        "User-Agent"  = "SITE_AUDITOR_AGENT"
    }

    try {
        Invoke-WebRequest -Uri $zipUrl -Headers $headers -OutFile $zipPath -UseBasicParsing
    }
    catch {
        throw "GITHUB_ZIP_DOWNLOAD_FAILED: $zipUrl :: $($_.Exception.Message)"
    }

    if (!(Test-Path -LiteralPath $zipPath)) { throw "ZIP_NOT_DOWNLOADED" }

    Expand-RepoZipToTarget -ZipPath $zipPath -ExtractRoot $extractPath -TargetPath $TargetPath
}

function Write-TextSummary {
    param(
        [string]$ReportDir,
        [object]$Inventory,
        [object]$SemanticIssues,
        [object]$LinkIssues,
        [object]$Orphans,
        [object]$RenderAudit,
        [object]$Screenshots,
        [object]$TargetAlignment,
        [object]$StageAssessment
    )

    $publishableCount = @($Inventory | Where-Object { $_.is_publishable }).Count
    $missingRoutes = @($TargetAlignment.missing_required_routes)
    $renderFails = @($RenderAudit | Where-Object { $_.status -ne 'OK' }).Count

    $summaryObj = [PSCustomObject]@{
        publishable_pages = $publishableCount
        inventory_count = @($Inventory).Count
        semantic_issues = @($SemanticIssues).Count
        broken_links = @($LinkIssues).Count
        orphan_pages = @($Orphans).Count
        render_failures = $renderFails
        screenshots = @($Screenshots | Where-Object { $_.status -eq 'OK' }).Count
        build_stage = $StageAssessment.build_stage
        target_coverage_percent = $TargetAlignment.required_route_coverage_percent
        missing_required_routes = $missingRoutes
        critical_blockers = @($StageAssessment.critical_blockers).Count
        generated_at = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    }

    $summaryObj | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $ReportDir "00_SUMMARY.json") -Encoding utf8

    $lines = @()
    $lines += "SITE AUDIT SUMMARY"
    $lines += ""
    $lines += "Build Stage           : $($StageAssessment.build_stage)"
    $lines += "Target Coverage       : $($TargetAlignment.required_route_coverage_percent)%"
    $lines += "Publishable Pages     : $publishableCount"
    $lines += "Inventory Count       : $(@($Inventory).Count)"
    $lines += "Semantic Issues       : $(@($SemanticIssues).Count)"
    $lines += "Broken Links          : $(@($LinkIssues).Count)"
    $lines += "Orphan Pages          : $(@($Orphans).Count)"
    $lines += "Render Failures       : $renderFails"
    $lines += "Screenshots OK        : $(@($Screenshots | Where-Object { $_.status -eq 'OK' }).Count)"
    $lines += "Critical Blockers     : $(@($StageAssessment.critical_blockers).Count)"
    $lines += ""
    $lines += "Missing Required Routes:"
    if (@($missingRoutes).Count -eq 0) {
        $lines += "- none"
    } else {
        foreach ($r in $missingRoutes) { $lines += "- $r" }
    }

    $lines += ""
    $lines += "Top Critical Blockers:"
    if (@($StageAssessment.critical_blockers).Count -eq 0) {
        $lines += "- none"
    } else {
        foreach ($b in @($StageAssessment.critical_blockers | Select-Object -First 15)) {
            $routeValue = $null
            try { $routeValue = $b.route } catch {}
            $routeText = if ($routeValue) { " :: $routeValue" } else { "" }
            $lines += "- $($b.type)$routeText"
        }
    }

    $lines | Out-File -LiteralPath (Join-Path $ReportDir "00_SUMMARY.txt") -Encoding utf8
}

function Invoke-SiteAudit {
    $AgentRoot = Get-AgentRoot
    $ConfigPath = Join-Path $AgentRoot "agent.config.json"
    $TargetPath = Join-Path $AgentRoot "site.target.json"
    $TokenPath  = Join-Path $AgentRoot ".state\github_token.txt"
    $WorkPath   = Join-Path $AgentRoot "work"
    $OutboxPath = Join-Path $AgentRoot "outbox"

    New-Item -ItemType Directory -Force -Path $WorkPath | Out-Null
    New-Item -ItemType Directory -Force -Path $OutboxPath | Out-Null

    Write-Host "[PHASE] Loading config"
    $cfg = Get-AgentConfig -ConfigPath $ConfigPath

    Write-Host "[PHASE] Loading target model"
    . "$AgentRoot\target_stage.ps1"
    $target = Get-TargetModel -TargetPath $TargetPath

    Write-Host "[PHASE] Resolving token"
    $token = Get-GitHubToken -TokenPath $TokenPath

    Write-Host "[PHASE] Loading modules"
    . "$AgentRoot\inventory.ps1"
    . "$AgentRoot\semantic_audit.ps1"
    . "$AgentRoot\links_audit.ps1"
    . "$AgentRoot\render_audit.ps1"
    . "$AgentRoot\screenshot.ps1"

    $repoOwner = $cfg.repo_owner
    $repoName  = $cfg.repo_name
    $branch    = $cfg.branch
    if ([string]::IsNullOrWhiteSpace($branch)) { $branch = "main" }

    $baseUrl = $cfg.base_url
    if ([string]::IsNullOrWhiteSpace($baseUrl)) { $baseUrl = "https://automation-kb.pages.dev" }

    Write-Host "[PHASE] Fetching repository"
    $RepoPath = Join-Path $WorkPath "repo"
    Download-RepoZipViaApi -RepoOwner $repoOwner -RepoName $repoName -Branch $branch -Token $token -WorkPath $WorkPath -TargetPath $RepoPath

    Write-Host "[PHASE] Building inventory"
    $Inventory = Build-SiteInventory -RepoPath $RepoPath -BaseUrl $baseUrl -Config $cfg

    Write-Host "[PHASE] Semantic audit"
    $SemanticIssues = Invoke-SemanticAudit -Inventory $Inventory

    Write-Host "[PHASE] Links audit"
    $LinkAudit = Invoke-LinksAudit -Inventory $Inventory
    $LinkIssues = $LinkAudit.BrokenLinks
    $Orphans = $LinkAudit.Orphans
    $NavGraph = $LinkAudit.NavGraph

    Write-Host "[PHASE] Render audit"
    $RenderAudit = Invoke-RenderAudit -Inventory $Inventory -Config $cfg

    Write-Host "[PHASE] Stage assessment"
    $TargetStage = Invoke-TargetStageAudit -Inventory $Inventory -SemanticIssues $SemanticIssues -LinkIssues $LinkIssues -RenderAudit $RenderAudit -Target $target
    $TargetAlignment = $TargetStage.TargetAlignment
    $StageAssessment = $TargetStage.StageAssessment

    Write-Host "[PHASE] Screenshots"
    $Screenshots = Invoke-ScreenshotCapture -Inventory $Inventory -RenderAudit $RenderAudit -WorkPath $WorkPath -MaxScreenshots $cfg.max_screenshots

    Write-Host "[PHASE] Packaging report"
    $ts = Get-Date -Format "yyyyMMdd_HHmmss"
    $reportDir = Join-Path $WorkPath "report_$ts"
    Remove-DirectorySafe -Path $reportDir
    New-Item -ItemType Directory -Path $reportDir -Force | Out-Null

    $Inventory | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "01_INVENTORY.json") -Encoding utf8
    $SemanticIssues | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "02_SEMANTIC_ISSUES.json") -Encoding utf8
    $LinkIssues | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "03_BROKEN_LINKS.json") -Encoding utf8
    $Orphans | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "04_ORPHAN_PAGES.json") -Encoding utf8
    $NavGraph | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "05_NAV_GRAPH.json") -Encoding utf8
    $RenderAudit | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "06_RENDER_AUDIT.json") -Encoding utf8
    $Screenshots | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "07_SCREENSHOTS.json") -Encoding utf8
    $TargetAlignment | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "08_TARGET_ALIGNMENT.json") -Encoding utf8
    $StageAssessment | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "09_STAGE_ASSESSMENT.json") -Encoding utf8

    $metrics = [PSCustomObject]@{
        inventory_total = @($Inventory).Count
        publishable_pages = @($Inventory | Where-Object { $_.is_publishable }).Count
        semantic_issues = @($SemanticIssues).Count
        broken_links = @($LinkIssues).Count
        orphan_pages = @($Orphans).Count
        render_failures = @($RenderAudit | Where-Object { $_.status -ne 'OK' }).Count
        screenshot_ok = @($Screenshots | Where-Object { $_.status -eq 'OK' }).Count
    }
    $metrics | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "10_METRICS.json") -Encoding utf8

    if (@($Screenshots).Count -gt 0) {
        $shotsDir = Join-Path $reportDir "screens"
        New-Item -ItemType Directory -Path $shotsDir -Force | Out-Null
        foreach ($shot in $Screenshots) {
            if ($shot.local_path -and (Test-Path -LiteralPath $shot.local_path)) {
                Copy-Item -LiteralPath $shot.local_path -Destination (Join-Path $shotsDir ([IO.Path]::GetFileName($shot.local_path))) -Force
            }
        }
    }

    Write-TextSummary -ReportDir $reportDir -Inventory $Inventory -SemanticIssues $SemanticIssues -LinkIssues $LinkIssues -Orphans $Orphans -RenderAudit $RenderAudit -Screenshots $Screenshots -TargetAlignment $TargetAlignment -StageAssessment $StageAssessment

    $zip = Join-Path $OutboxPath "SITE_AUDIT_PACK_$ts.zip"
    if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
    Compress-Archive -Path (Join-Path $reportDir "*") -DestinationPath $zip -Force

    Write-Host ""
    Write-Host "REPORT:"
    Write-Host $zip
}
