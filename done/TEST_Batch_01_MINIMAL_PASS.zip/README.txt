TEST: MINIMAL PASS
EXPECTED: ADD 1 file
TARGET: src/test_batch_01/index.md
