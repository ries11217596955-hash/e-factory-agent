---
title: Test Batch 01
layout: base.njk
---

# Test Batch 01

This is a minimal test page for GH_BATCH.
