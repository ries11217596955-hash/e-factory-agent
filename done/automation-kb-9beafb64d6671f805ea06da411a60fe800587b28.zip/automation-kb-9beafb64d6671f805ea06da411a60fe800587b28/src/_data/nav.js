module.exports = [
  { label: "Start", href: "/" },
  { label: "Posts", href: "/posts/" },
  { label: "News", href: "/news/" },
  { label: "Tools", href: "/tools/" },
  { label: "Hubs", href: "/hubs/" }
];
