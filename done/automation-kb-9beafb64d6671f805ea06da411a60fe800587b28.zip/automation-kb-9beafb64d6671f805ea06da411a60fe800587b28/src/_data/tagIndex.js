module.exports = function(data){
  const tagMap = (data && data.tagMap) ? data.tagMap : {};
  const aliases = (tagMap && tagMap.aliases) ? tagMap.aliases : {};
  const blocked = new Set([...(Array.isArray(tagMap.blocked) ? tagMap.blocked : []), "posts","news","tools","all"].map((x)=>String(x).toLowerCase()));

  const canon = (raw) => {
    if (raw === null || raw === undefined) return "";
    let t = String(raw).trim().toLowerCase();
    if (!t) return "";
    if (t.startsWith("_")) return "";
    t = t.replace(/[_\s]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
    const mapped = Object.prototype.hasOwnProperty.call(aliases, t) ? String(aliases[t] || "") : "";
    const out = (mapped ? mapped : t).trim().toLowerCase();
    if (!out) return "";
    if (blocked.has(out)) return "";
    return out;
  };

  const uniqSorted = (arr) => Array.from(new Set(arr)).sort((a,b)=> String(a).localeCompare(String(b)));

  const tagsFrom = (items, reservedBase) => {
    const res = [];
    const base = String(reservedBase || "").toLowerCase();
    (items || []).forEach((it) => {
      const tags = (it && it.data && Array.isArray(it.data.tags)) ? it.data.tags : [];
      tags.forEach((t) => {
        const c = canon(t);
        if (!c) return;
        if (base && c === base) return;
        res.push(c);
      });
    });
    return uniqSorted(res);
  };

  const cols = (data && data.collections) ? data.collections : {};
  return {
    posts: tagsFrom(cols.posts, "posts"),
    news: tagsFrom(cols.news, "news"),
    tools: tagsFrom(cols.tools, "tools"),
  };
};
