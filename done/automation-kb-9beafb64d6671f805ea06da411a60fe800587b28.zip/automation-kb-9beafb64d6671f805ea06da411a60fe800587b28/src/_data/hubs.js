module.exports = [
  {
    key: "ai-for-sales",
    title: "AI for Sales",
    description: "Using AI to automate lead generation, outreach, and sales workflows."
  },
  {
    key: "amazon-ai",
    title: "Amazon AI",
    description: "AI tools and workflows for Amazon listing optimization, pricing, and review monitoring."
  },
  {
    key: "shopify-ai",
    title: "Shopify AI",
    description: "Automation and AI workflows for Shopify stores and ecommerce operations."
  },
  {
    key: "workflow",
    title: "Workflow Systems",
    description: "Designing scalable AI agent workflows, orchestration, and automation pipelines."
  },
  {
    key: "operations",
    title: "Operations",
    description: "Deployment, monitoring, and operational practices for running AI systems."
  },
  {
    key: "integrations",
    title: "Integrations",
    description: "Connecting AI tools with APIs, webhooks, and external platforms."
  }
];
