/* automation-kb:shortcuts.js:v1
   Keyboard shortcuts:
   - "/" focuses the header search input (like many docs sites).
   - On /search/ page, focuses the query input.
*/
(function(){
  const ready = (fn) => (document.readyState === "loading")
    ? document.addEventListener("DOMContentLoaded", fn)
    : fn();

  const isTypingContext = (el) => {
    if(!el) return false;
    const tag = (el.tagName || "").toLowerCase();
    if(tag === "input" || tag === "textarea" || tag === "select") return true;
    if(el.isContentEditable) return true;
    return false;
  };

  ready(() => {
    // Focus search box on the search page
    if(location.pathname.startsWith("/search/")){
      const q = document.getElementById("q");
      if(q) q.focus();
    }

    document.addEventListener("keydown", (e) => {
      if(e.defaultPrevented) return;
      if(e.key !== "/") return;
      if(e.ctrlKey || e.metaKey || e.altKey) return;
      if(isTypingContext(document.activeElement)) return;

      const input = document.querySelector(".search-mini__input");
      if(input){
        e.preventDefault();
        input.focus();
        input.select?.();
      }else{
        // fallback: go to search page
        e.preventDefault();
        location.href = "/search/";
      }
    });
  });
})();