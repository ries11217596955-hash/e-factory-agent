/* automation-kb:search.js:v1
   No dependencies. Loads /search.json and filters client-side.
*/
(function(){
  const $ = (s) => document.querySelector(s);
  const qInput = $("#q");
  const clearBtn = $("#clear");
  const results = $("#results");
  const count = $("#count");

  if(!qInput || !results) return;

  const params = new URLSearchParams(location.search || "");
  const initial = (params.get("q") || "").trim();
  qInput.value = initial;

  const esc = (s) => String(s || "").replace(/[&<>"]/g, (c) => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"
  }[c]));

  const mk = (it) => {
    const tags = Array.isArray(it.tags) ? it.tags.slice(0,6).map(esc) : [];
    const tagHtml = tags.length ? `<div class="search-item__tags">${tags.map(t=>`<span class="tag">${t}</span>`).join("")}</div>` : "";
    const dt = it.date ? `<span class="search-item__date">${esc(it.date)}</span>` : "";
    return `
      <article class="search-item">
        <h3 class="search-item__title"><a href="${esc(it.url)}">${esc(it.title)}</a></h3>
        <div class="search-item__meta">
          <span class="search-item__section">${esc(it.section || "")}</span>
          ${dt}
        </div>
        ${it.summary ? `<p class="search-item__summary">${esc(it.summary)}</p>` : ""}
        ${tagHtml}
      </article>
    `;
  };

  let DATA = null;

  const fetchData = async () => {
    const res = await fetch("/search.json", { cache: "no-store" });
    if(!res.ok) throw new Error("search.json fetch failed");
    const json = await res.json();
    return Array.isArray(json) ? json : [];
  };

  const score = (it, q) => {
    const t = (it.title || "").toLowerCase();
    const s = (it.summary || "").toLowerCase();
    const tags = (Array.isArray(it.tags) ? it.tags.join(" ") : "").toLowerCase();
    let sc = 0;
    if(t.includes(q)) sc += 5;
    if(tags.includes(q)) sc += 3;
    if(s.includes(q)) sc += 1;
    return sc;
  };

  const render = (list) => {
    count.textContent = String(list.length);
    if(!list.length){
      results.innerHTML = `<div class="empty">No results. Try a shorter query.</div>`;
      return;
    }
    results.innerHTML = list.map(mk).join("");
  };

  const run = (raw) => {
    const q = String(raw || "").trim().toLowerCase();
    if(!q){
      render([]);
      return;
    }
    const out = (DATA || [])
      .map(it => ({ it, sc: score(it, q) }))
      .filter(x => x.sc > 0)
      .sort((a,b) => (b.sc - a.sc) || (String(b.it.date||"").localeCompare(String(a.it.date||""))))
      .slice(0, 50)
      .map(x => x.it);

    render(out);
  };

  const wire = () => {
    qInput.addEventListener("input", () => {
      const v = qInput.value || "";
      const u = new URL(location.href);
      if(v.trim()) u.searchParams.set("q", v.trim());
      else u.searchParams.delete("q");
      history.replaceState(null, "", u.toString());
      run(v);
    });
    if(clearBtn){
      clearBtn.addEventListener("click", () => {
        qInput.value = "";
        const u = new URL(location.href);
        u.searchParams.delete("q");
        history.replaceState(null, "", u.toString());
        run("");
        qInput.focus();
      });
    }
  };

  (async () => {
    try{
      DATA = await fetchData();
      wire();
      run(initial);
    }catch(e){
      results.innerHTML = `<div class="empty">Search failed to load.</div>`;
      console.error(e);
    }
  })();
})();
