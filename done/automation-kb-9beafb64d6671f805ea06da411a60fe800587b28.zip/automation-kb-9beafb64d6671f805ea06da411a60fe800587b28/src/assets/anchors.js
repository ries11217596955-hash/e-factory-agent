/* automation-kb:anchors.js:v1
   Adds small anchor links to headings in article content.
   - No deps
   - Safe fallback if Clipboard API not available
*/
(function(){
  function slugify(s){
    return String(s || "")
      .trim()
      .toLowerCase()
      .replace(/['"]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "");
  }

  function ensureId(el, used){
    var id = el.getAttribute("id");
    if(id && id.trim()) { used[id] = true; return id; }

    var base = slugify(el.textContent);
    if(!base) base = "section";
    var candidate = base;
    var i = 2;
    while(used[candidate]){ candidate = base + "-" + i; i++; }
    el.setAttribute("id", candidate);
    used[candidate] = true;
    return candidate;
  }

  function copyText(text){
    if(navigator && navigator.clipboard && navigator.clipboard.writeText){
      return navigator.clipboard.writeText(text);
    }
    // fallback
    return new Promise(function(resolve, reject){
      try{
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.setAttribute("readonly", "");
        ta.style.position = "fixed";
        ta.style.left = "-9999px";
        document.body.appendChild(ta);
        ta.select();
        var ok = document.execCommand("copy");
        document.body.removeChild(ta);
        ok ? resolve() : reject(new Error("copy failed"));
      } catch(e){ reject(e); }
    });
  }

  function init(){
    var main = document.getElementById("main");
    if(!main) return;

    // Limit to prose blocks if present; otherwise within main
    var scope = main.querySelector(".prose") || main;
    var headings = scope.querySelectorAll("h2, h3, h4");
    if(!headings.length) return;

    var used = {};
    // collect existing ids
    scope.querySelectorAll("[id]").forEach(function(n){ used[n.id] = true; });

    headings.forEach(function(h){
      // avoid adding anchors inside nav/sidebars
      if(h.closest("nav")) return;

      var id = ensureId(h, used);

      // if anchor already exists, skip
      if(h.querySelector(".h-anchor")) return;

      var a = document.createElement("a");
      a.className = "h-anchor";
      a.href = "#" + id;
      a.setAttribute("aria-label", "Copy link to this section");
      a.textContent = "§";

      a.addEventListener("click", function(ev){
        // allow normal jump, but also copy full URL
        var url = window.location.origin + window.location.pathname + "#" + id;
        copyText(url).then(function(){
          a.classList.add("is-copied");
          var prev = a.textContent;
          a.textContent = "Copied";
          window.setTimeout(function(){
            a.classList.remove("is-copied");
            a.textContent = prev;
          }, 900);
        }).catch(function(){ /* ignore */ });
      });

      h.appendChild(a);
    });
  }

  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
