/* automation-kb:codecopy.js:v1
   Adds a "Copy" button to each <pre><code> block. No deps.
*/
(function(){
  const ready = (fn) => (document.readyState === "loading")
    ? document.addEventListener("DOMContentLoaded", fn)
    : fn();

  const canClipboard = () => !!(navigator.clipboard && navigator.clipboard.writeText);

  const fallbackCopy = (text) => {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.top = "-1000px";
    ta.style.left = "-1000px";
    document.body.appendChild(ta);
    ta.select();
    try{ document.execCommand("copy"); }catch(e){}
    document.body.removeChild(ta);
  };

  const setState = (btn, label) => {
    btn.textContent = label;
    btn.setAttribute("data-state", label);
  };

  ready(() => {
    const blocks = Array.from(document.querySelectorAll("pre > code"));
    if(!blocks.length) return;

    blocks.forEach((code) => {
      const pre = code.parentElement;
      if(!pre || pre.querySelector(".codecopy-btn")) return;

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "codecopy-btn";
      btn.setAttribute("aria-label", "Copy code");
      setState(btn, "Copy");

      if(!canClipboard()){
        btn.classList.add("is-fallback");
      }

      btn.addEventListener("click", async () => {
        const text = code.innerText || code.textContent || "";
        try{
          if(canClipboard()) await navigator.clipboard.writeText(text);
          else fallbackCopy(text);
          setState(btn, "Copied");
          btn.classList.add("is-copied");
          window.setTimeout(() => {
            setState(btn, "Copy");
            btn.classList.remove("is-copied");
          }, 1200);
        }catch(e){
          setState(btn, "Error");
          window.setTimeout(() => setState(btn, "Copy"), 1200);
        }
      });

      pre.appendChild(btn);
    });
  });
})();