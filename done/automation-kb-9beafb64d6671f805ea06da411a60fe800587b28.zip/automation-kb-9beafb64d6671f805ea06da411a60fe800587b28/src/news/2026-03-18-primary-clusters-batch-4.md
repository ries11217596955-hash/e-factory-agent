---
title: "Primary clusters batch 4 is live"
description: "New operating articles added for sales queue design, Shopify data hygiene, Amazon monitoring, and ecommerce returns."
layout: "post"
date: 2026-03-18
tags:
  - updates
summary: "Batch 4 expands the primary sales and ecommerce clusters with more operations-focused articles."
---

This batch adds another set of practical pages for the primary clusters.

Included topics:

- sales follow-up queue design
- sales discovery notes standard
- Shopify product data hygiene
- ecommerce return reason loop
- Amazon suppression watch
- Amazon catalog change control
