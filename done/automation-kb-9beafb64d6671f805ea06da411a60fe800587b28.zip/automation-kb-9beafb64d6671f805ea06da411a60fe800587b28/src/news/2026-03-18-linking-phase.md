---
title: "Internal linking phase is now active"
description: "The site has moved from build recovery into navigation and internal linking improvement work."
layout: "page.njk"
permalink: "/news/internal-linking-phase/"
date: 2026-03-18
tags:
  - news
  - links
  - navigation
---

## What changed

The build layer is stable enough to continue with internal linking and orphan reduction.

## Why it matters

Better linking improves crawl paths, user navigation, and page discovery across clusters.

## Priority areas

- hub to post linking
- post to hub linking
- news cluster strengthening
