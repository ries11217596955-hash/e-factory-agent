---
title: "Hub-first navigation reinforced"
description: "The site continues to push readers toward hubs first, with posts acting as the deeper archive layer."
layout: "post"
date: 2026-03-18
tags:
  - news
  - hubs
  - navigation
summary: "Readers are now pushed more clearly toward hubs first and the archive second."
---

The site navigation is being reinforced around a simple rule: start with hubs, then go deeper into posts and tools.

## Main entry points

- Home: [/](/)
- Hubs: [/hubs/](/hubs/)
- Posts: [/posts/](/posts/)
- Tools: [/tools/](/tools/)
- Updates: [/news/](/news/)
