---
title: "Site structure repair shipped"
description: "The site shipped a structural repair pass focused on restoring readable content, stable routing, and cleaner entry pages."
layout: "post"
date: 2026-03-18
tags:
  - news
  - release
  - site-structure
summary: "Readable content, cleaner entry pages, and a repair pass on broken structure are now live."
---

This update marks a repair pass on the public site structure.

## What changed

- repaired content pages that were rendering incorrectly
- restored readable page bodies for affected routes
- tightened the main entry surfaces around hubs, posts, tools, and updates

## Where to go next

- Browse all hubs: [/hubs/](/hubs/)
- Open the posts archive: [/posts/](/posts/)
- Open the tools catalog: [/tools/](/tools/)
