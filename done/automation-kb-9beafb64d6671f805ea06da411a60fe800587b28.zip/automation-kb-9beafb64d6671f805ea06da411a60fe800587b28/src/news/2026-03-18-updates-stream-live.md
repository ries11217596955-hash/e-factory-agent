---
title: "Updates stream is now live"
description: "The site now has a clearer updates stream for launches, structural changes, and important live fixes."
layout: "post"
date: 2026-03-18
tags:
  - news
  - navigation
  - release
summary: "A dedicated updates stream is live for structural changes and launches."
---

A dedicated updates stream is now live.

Use it for:
- launches and new clusters
- important structural changes
- repair milestones that change how readers should navigate the site

Open the stream here: [/news/](/news/)
