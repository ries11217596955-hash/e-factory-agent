---
title: "Creators cluster expanded"
description: "The creators section now has clearer TikTok entry points for growth, workflow, editing, and monetization."
layout: "post"
date: 2026-03-18
tags:
  - news
  - creators
  - tiktok
summary: "The creators area is now easier to navigate with clearer TikTok paths."
---

The creators section has been tightened so readers can move faster from the main creators page into the right TikTok path.

## Live paths

- Creators hub: [/ai-creators/](/ai-creators/)
- TikTok hub: [/ai-creators/tiktok/](/ai-creators/tiktok/)
- Growth: [/ai-creators/tiktok/growth/](/ai-creators/tiktok/growth/)
- Workflow: [/ai-creators/tiktok/workflow/](/ai-creators/tiktok/workflow/)
- Editing: [/ai-creators/tiktok/editing/](/ai-creators/tiktok/editing/)
- Monetization: [/ai-creators/tiktok/monetization/](/ai-creators/tiktok/monetization/)
