---
title: "Content cleanup batch started"
description: "A cleanup pass is replacing encoded pages with readable source content and restoring normal page rendering."
layout: "page.njk"
permalink: "/news/content-cleanup/"
date: 2026-03-18
tags:
  - news
  - content
  - cleanup
---

## What changed

A cleanup batch is replacing broken encoded source pages with readable markdown and template files.

## Why it matters

This improves page quality, snippet quality, search previews, and overall trust in the site.

## Focus

Priority goes to core routes, hub pages, news pages, and pages that surface in navigation.
