---
title: "Primary clusters batch 2 published"
description: "A second focused batch added new pages for AI for Sales and Ecommerce Automation without touching config or layouts."
layout: "page.njk"
permalink: "/news/primary-clusters-batch-2/"
date: 2026-03-18
tags:
  - news
  - content
  - clusters
---

## What changed

A new content batch expanded the two primary clusters:
- AI for Sales
- Ecommerce Automation

## Why it matters

The site is moving by controlled content batches instead of broad repo replacement. This reduces break risk and improves tracking.

## Next

Continue with small post batches, then strengthen internal links and cluster coverage.
