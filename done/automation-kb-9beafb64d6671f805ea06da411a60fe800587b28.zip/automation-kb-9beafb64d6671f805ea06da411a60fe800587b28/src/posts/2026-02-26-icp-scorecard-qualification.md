---
title: 2026-02-26-icp-scorecard-qualification
description: "A simple scorecard to decide: pursue, nurture, or skip - based on signals you can verify."
date: 2026-02-26
tags: [ai-for-sales, workflow, qualification]
primaryTag: workflow
summary: "Short: ICP scorecard qualification"
---

## ICP scorecard: qualify leads fast (no CRM chaos)

The goal is not "more leads". It's **more qualified conversations**.

### Scorecard (0-10)
Give 0/1/2 points per category.

1) **Fit to your offer**
- 2 = clear workflow match
- 1 = adjacent
- 0 = mismatch

2) **Urgency signals (verifiable)**
- 2 = hiring/ops change/new initiative
- 1 = mild signal
- 0 = none

3) **Ability to buy**
- 2 = clear decision maker / budget owner
- 1 = influencer
- 0 = unknown

4) **Access**
- 2 = warm path / mutuals / active on LinkedIn
- 1 = reachable but cold
- 0 = hard to reach

5) **Downside risk**
- 2 = low risk (simple implementation)
- 1 = moderate
- 0 = high (complex, long cycles)

**Decision**
- 8-10: pursue now (outreach + follow-up plan)
- 5-7: nurture (content + light touches)
- 0-4: skip

### AI prompt (for consistent scoring)
Provide:
- company, website, persona, offer category, any signals you found

Ask AI to return:
- score per category + 1 evidence line per score
- top 1 hypothesis + top 1 question to confirm
- recommended next action (pursue/nurture/skip)

### Guardrail
If AI can't cite evidence for a score → score that category as **0**.

### Link it
Use this scorecard after you run the "prospect research workflow".
