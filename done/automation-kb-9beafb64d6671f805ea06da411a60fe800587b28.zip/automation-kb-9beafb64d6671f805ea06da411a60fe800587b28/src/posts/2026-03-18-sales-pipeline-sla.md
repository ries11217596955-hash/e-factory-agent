---
title: "Sales pipeline SLA"
description: "Define response times, ownership, and follow-up limits across the sales pipeline."
layout: "post"
date: 2026-03-18
tags:
  - ai-for-sales
  - sales
  - workflow
primaryTag: sales
summary: "A simple service-level model for lead handling, follow-up, and stage transitions."
---

## Purpose

A pipeline SLA prevents silent lead decay. Every stage should have a target response time and a named owner.

## Minimum SLA model

- inbound lead review: same day
- qualified lead follow-up: within one business day
- proposal response: within two business days
- stalled deal review: weekly
- closed-lost reason logging: mandatory

## Guardrails

- no stage without owner
- no lead without next action
- no stale opportunity beyond SLA window
- no manual exceptions without note

## Outcome

The goal is not bureaucracy. The goal is faster movement and fewer dropped opportunities.
