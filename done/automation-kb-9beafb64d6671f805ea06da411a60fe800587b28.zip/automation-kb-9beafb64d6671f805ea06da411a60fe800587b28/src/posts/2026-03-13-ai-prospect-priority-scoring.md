---
title: "AI prospect priority scoring"
description: "Ranking prospects using signal analysis."
layout: "post"
tags:
- ai-for-sales
- scoring
---

## Workflow
1. collect signals
2. detect engagement
3. score value
4. rank pipeline
