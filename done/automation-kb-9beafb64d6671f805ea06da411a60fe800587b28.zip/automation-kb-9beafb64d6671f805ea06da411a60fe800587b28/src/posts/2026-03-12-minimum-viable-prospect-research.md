---
title: "Minimum viable prospect research"
description: "Research just enough to decide whether a lead is worth your time, without building a slow fake-personalization machine."
layout: "post"
tags:
  - "ai-for-sales"
  - "lead-generation"
  - "prospecting"
---

## The mistake

Teams often collect too much before they contact anyone.

The result:
- slow throughput
- weak prioritization
- fake "personalization"
- too much time per lead

## The better model

Prospect research should answer four questions:

1. who is this
2. why might they fit
3. can we reach them
4. what is the next best action

If the answer to one of these is missing, collect that fact.  
If not, move on.

## Minimum research packet

For each prospect, keep:

- company name
- role
- one visible signal of relevance
- one probable problem area
- one reachable channel
- confidence level

That is enough to route the lead.

## Where AI helps

AI is useful for:
- compressing public facts
- turning rough notes into a short summary
- grouping similar prospects
- spotting obvious mismatch faster

AI is not useful for:
- pretending to know internal priorities
- guessing purchase intent
- inventing personalized compliments

## Timing rule

Use a hard ceiling:
- 3 to 7 minutes per lead for normal outreach
- more only for high-value accounts

This protects throughput.

## Output format

A good research line looks like this:

- Company: mid-market B2B SaaS
- Role: Head of Revenue Operations
- Relevance: hiring SDRs + open revops tooling stack
- Channel: email + LinkedIn
- Next step: send outreach with angle on follow-up leakage

Short beats impressive.

## When to stop researching

Stop when you can choose:
- pursue
- nurture
- skip

Research that does not help this decision is waste.

## Related paths

- [Build an AI sales system from zero](/posts/2026-03-12-build-ai-sales-system-from-zero/)
- [Lead generation](/hubs/ai-for-sales/lead-generation/)
- [Qualification](/hubs/ai-for-sales/qualification/)
