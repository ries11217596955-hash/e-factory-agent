---
title: tagging-strategy
description: ""
date: 2026-02-24
tags: []
primaryTag: workflow
summary: "Short: tagging-strategy"
---


**Base tags** decide the content type:


- `posts` → /posts/


- `news` → /news/


- `tools` → /tools/





**Facet tags** add meaning without mixing types:


- workflows, integrations, operations, cloudflare, qa, etc.





This keeps navigation and collections stable while enabling tag pages.





