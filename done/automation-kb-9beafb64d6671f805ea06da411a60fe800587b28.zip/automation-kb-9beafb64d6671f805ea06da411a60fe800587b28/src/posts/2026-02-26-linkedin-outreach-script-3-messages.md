---
title: 2026-02-26-linkedin-outreach-script-3-messages
description: "A minimal 3-message sequence you can personalize with one verifiable signal and one workflow hypothesis."
date: 2026-02-26
tags: [ai-for-sales, workflow, outreach]
primaryTag: workflow
summary: "Short: LinkedIn outreach 3-message script"
---

## LinkedIn outreach: 3-message script that doesn't feel robotic

LinkedIn works when you keep it simple and specific.

### Message 1 (connect note)
- "Hi <Name> - noticed <verifiable signal>. I'm working on <workflow outcome> for <persona>. Open to connect?"

### Message 2 (after accept)
- "Thanks! Quick question: how are you handling <pain area> today - manual, internal tool, or agency?"

### Message 3 (if no reply)
- "If it helps, I can share a 1‑page checklist for <workflow>. Want it?"

### Personalization checklist
Each message should include:
- 1 signal (job post, launch, policy, tooling post)
- 1 workflow hypothesis
- 1 question

AI can draft variants, but you must keep the signal real.
