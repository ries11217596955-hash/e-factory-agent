---
title: 2026-02-18-how-to-propose-changes
description: ""
date: 2026-02-18
tags: []
primaryTag: workflow
summary: "Short: 2026-02-18-how-to-propose-changes"
---


## Issue report: minimum





Include:





- URL


- Expected vs actual


- Steps to reproduce (if relevant)





## Requests





Propose changes with:





- The problem you're solving


- The desired outcome


- Constraints (what must not break)





This keeps batches coherent and reviewable.





