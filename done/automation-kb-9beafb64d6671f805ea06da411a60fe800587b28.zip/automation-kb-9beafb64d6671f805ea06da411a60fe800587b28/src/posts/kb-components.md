---
title: kb-components
description: ""
date: 2026-02-24
tags: []
primaryTag: workflow
summary: "Short: kb-components"
---


## Callouts





Use a callout when you want to highlight a note, a tip, or a warning.





{% callout "note", "Note" %}


This is a note callout. Use it for context, assumptions, or constraints.


{% endcallout %}





{% callout "tip", "Tip" %}


This is a tip callout. Use it for best practices and shortcuts.


{% endcallout %}





{% callout "warn", "Warning" %}


This is a warning callout. Use it for risks and side-effects.


{% endcallout %}





{% callout "danger", "Danger" %}


This is a danger callout. Use it for "do not do this" situations.


{% endcallout %}





## KB cards





Use a card when you want a self-contained block (mini-section) inside the article.





{% kbcard "Checklist" %}


- Item 1  


- Item 2  


- Item 3  


{% endkbcard %}





{% kbcard "Example" %}


Here you can put a short example, code, or a decision note.


{% endkbcard %}





