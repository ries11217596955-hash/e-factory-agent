---
title: search-usage
description: ""
date: 2026-02-24
tags: []
primaryTag: workflow
summary: "Short: search-usage"
---


Search works best when titles and summaries are consistent.





## Make titles "actionable"


Good:


- "Deploy verification checklist"


- "Content seeding plan"





Not great:


- "Notes"


- "Update"





## Use tags as facets


Add 1-3 facet tags, e.g.:


- `["tools","cloudflare","deploy"]`


- `["posts","contract","metadata"]`





## Keep summaries short


Aim for one sentence. Lists prefer `summary`, then fall back to `description`.





## Verify indexing


Open:


- `/search/` for UI


- `/search/index.json` for the raw index (debug)





