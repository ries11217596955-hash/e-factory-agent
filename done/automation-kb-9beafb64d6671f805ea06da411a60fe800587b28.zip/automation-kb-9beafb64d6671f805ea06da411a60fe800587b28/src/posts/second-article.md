---
title: second-article
description: ""
date: 2026-02-24
tags: []
primaryTag: workflow
summary: "Short: second-article"
---


This is a second example post.





Use it as a template:


- keep the title short


- add a one-line description (shows in lists)


- write the practical content in the body





