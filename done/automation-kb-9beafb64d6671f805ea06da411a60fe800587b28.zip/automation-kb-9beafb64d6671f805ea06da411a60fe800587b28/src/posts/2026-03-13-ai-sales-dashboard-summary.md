---
title: "AI sales dashboard summary"
description: "Generating daily summaries of metrics."
layout: "post"
tags: [ai-for-sales, analytics]
---

## Workflow
1. collect metrics
2. detect anomalies
3. summarize trends
4. distribute report
