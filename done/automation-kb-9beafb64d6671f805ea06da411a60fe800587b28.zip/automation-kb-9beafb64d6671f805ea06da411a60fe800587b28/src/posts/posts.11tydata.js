module.exports = {
  // IMPORTANT: use the site wrapper (base.njk) via layouts/post.njk
  // so /posts/<slug>/ is styled the same as the rest of the site.
  layout: "layouts/post.njk",
  tags: ["posts"]
};
