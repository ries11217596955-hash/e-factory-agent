---
title: "Sales playbook: lead qualification"
description: "Qualification workflow for inbound and outbound leads."
layout: "post"
tags: [sales, qualification]
---

## Workflow
1. collect company info
2. detect need
3. evaluate fit
4. move to pipeline
