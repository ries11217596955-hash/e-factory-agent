---
title: "AI LinkedIn prospecting system: daily routine + message set"
description: "A simple daily LinkedIn routine that produces replies, with a reusable message set and a no-spam posture."
date: 2026-02-27
primaryTag: ai-for-sales
tags: ["ai", "linkedin", "prospecting", "sales-ops", "workflow"]
summary: "A simple daily LinkedIn routine that produces replies, with a reusable message set and a no-spam posture."
---
# AI LinkedIn prospecting system: daily routine + message set

LinkedIn works when you behave like a person. Automation is for **selection + consistency**, not for blasting.

## Daily routine (30-45 min)
1) **Find 20 profiles** using ICP filters  
2) **Qualify 10** with signals (1 sentence each)  
3) **Send 5 connection requests** (short + specific)  
4) **Follow up 5** existing connections  
5) **Log outcomes** (reply / no reply / not fit)

## Message set
- Connection request: 250 chars, one signal, no pitch
- Follow-up #1: one small useful artifact
- Follow-up #2: ask a single question
- Exit: "no worries - I'll close the loop"

## Related
- Hub: [/hubs/ai-for-sales/](/hubs/ai-for-sales/)
