---
title: 2026-02-18-search-tags-nav
description: ""
date: 2026-02-18
tags: []
primaryTag: workflow
summary: "Short: 2026-02-18-search-tags-nav"
---


## Navigation rules





- Add new top-level nav items rarely.


- Prefer adding content under hubs and tags first.


- Keep URLs stable.





## Tags rules





- Use a small set of "anchor tags" per theme.


- Avoid one-off tags unless they help discovery.


- If a tag becomes important, promote it into a hub.





