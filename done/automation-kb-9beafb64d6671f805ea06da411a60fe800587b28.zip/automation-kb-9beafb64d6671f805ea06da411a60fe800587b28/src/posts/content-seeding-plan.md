---
title: content-seeding-plan
description: ""
date: 2026-02-24
tags: []
primaryTag: workflow
summary: "Short: content-seeding-plan"
---


This site becomes useful when each hub has **(1) a few tools**, **(2) a few posts that explain them**, and **(3) short news notes** that record changes.





## Target for the first week (20 items)


1. **Tools (8)** - reusable checklists/snippets.


2. **Posts (8)** - explain one tool or one workflow each.


3. **News (4)** - release notes ("what changed").





## Rules to keep it clean


- Tools live in `/tools/` and must include `tags: ["tools", ...]`.


- Posts live in `/posts/` and must include `tags: ["posts", ...]`.


- News lives in `/news/` and must include `tags: ["news", ...]`.


- Lists show **summary first**; avoid long paragraphs in summaries.





## Suggested topic buckets


- Workflows: intake → plan → execute → verify → publish


- Integrations: GitHub, Cloudflare Pages, forms, email, automation triggers


- Operations: QA gates, batch discipline, hygiene, verification, rollback





