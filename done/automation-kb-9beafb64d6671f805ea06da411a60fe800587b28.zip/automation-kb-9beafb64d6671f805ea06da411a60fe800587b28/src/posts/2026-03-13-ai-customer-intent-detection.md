---
title: "AI customer intent detection"
description: "Detecting customer intent from messages."
layout: "post"
tags: [ai, automation]
---

## Workflow
1. collect message text
2. classify intent
3. assign category
4. trigger workflow
