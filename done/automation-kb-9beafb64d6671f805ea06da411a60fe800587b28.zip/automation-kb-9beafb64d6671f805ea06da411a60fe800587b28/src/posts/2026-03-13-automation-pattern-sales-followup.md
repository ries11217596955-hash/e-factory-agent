---
title: "Automation pattern: sales follow up"
description: "Automating follow up communication."
layout: "post"
tags: [automation, sales]
---

## Workflow

1. detect inactivity
2. generate follow up message
3. schedule outreach
4. log activity
