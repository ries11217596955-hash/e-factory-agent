---
title: 2026-02-18-agent-runbook-minimum
description: ""
date: 2026-02-18
tags: []
primaryTag: workflow
summary: "Short: 2026-02-18-agent-runbook-minimum"
---


## Minimum log fields


- run id, start/end time


- input (order/job id)


- effective config (paths, endpoints, versions)


- actions taken (what changed)


- outputs (where delivered)


- result (PASS/FAIL + reason)





## Why it matters


If you can't replay the run, you can't trust the automation.





## Operator rule


One failure = one reason code. Don't overwrite it with guesses.





