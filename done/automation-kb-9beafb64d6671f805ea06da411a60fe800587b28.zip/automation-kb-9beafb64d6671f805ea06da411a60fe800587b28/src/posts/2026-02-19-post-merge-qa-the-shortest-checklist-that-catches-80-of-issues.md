---
title: "Post-merge QA: the shortest checklist that catches 80% of issues"
description: "Compatibility route for older post-merge QA links."
layout: "page"
permalink: "/posts/2026-02-19-post-merge-qa-the-shortest-checklist-that-catches-80-of-issues/"
eleventyExcludeFromCollections: true
---

## Post-merge QA

This compatibility page maps an older long-form route to the active checklist page.

- [Open the active post-merge QA short checklist](/posts/2026-02-19-post-merge-qa-short-checklist/)
