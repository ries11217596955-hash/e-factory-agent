---
title: "Inbox New Queue Test 001"
date: 2026-04-01
tags: ["automation", "gh-batch", "queue"]
---

# Inbox New Queue Test 001

This is a clean test post for the new `inbox/new` queue model.

- tests auto-trigger from `inbox/new/*.zip`
- tests queue pickup
- tests done/failed routing
