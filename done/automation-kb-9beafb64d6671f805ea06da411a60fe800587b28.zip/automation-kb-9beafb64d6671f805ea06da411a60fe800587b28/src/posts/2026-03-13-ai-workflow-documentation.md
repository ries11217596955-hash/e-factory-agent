---
title: "AI workflow documentation automation"
description: "Generating workflow documentation automatically."
layout: "post"
tags:
- automation
- workflow
---

## Workflow
1. gather notes
2. structure steps
3. generate doc draft
4. review and publish
