---
title: "Outreach angle before personalization"
description: "Why a clear message angle matters more than decorative personalization in AI-assisted outreach."
layout: "post"
tags:
  - "ai-for-sales"
  - "outreach"
  - "cold-email"
  - "linkedin"
---

## The core rule

A weak message with personalization is still weak.

Most bad outreach fails because the team starts here:
- "How do we personalize this?"
instead of:
- "What is the real angle?"

## What an angle is

An angle is the business reason the message deserves attention.

Examples:
- follow-up leakage is costing meetings
- CRM notes are too messy for routing
- qualification is too slow and subjective
- listing QA is manual and inconsistent

## What personalization is

Personalization is only the evidence that this angle is relevant here.

Good personalization:
- one relevant signal
- one concrete fit clue
- one reason this message is timely

Bad personalization:
- generic flattery
- copied public biography
- invented familiarity

## Practical formula

Use this sequence:

1. choose angle
2. add one relevance signal
3. make one useful promise
4. keep CTA small

Example structure:
- I noticed X
- teams like yours often struggle with Y
- here is the practical improvement
- open to a quick look?

## Where AI helps

AI can:
- draft variants of the same angle
- compress research into one useful line
- propose CTA alternatives
- clean tone and length

AI should not:
- generate fake context
- overstate urgency
- produce "hyper-personalized" nonsense

## A quality check

Before sending, ask:
- if I remove the personalization, is the angle still valid?
- if no, the message is weak

That one check removes a lot of noise.

## Related paths

- [Outreach](/hubs/ai-for-sales/outreach/)
- [Minimum viable prospect research](/posts/2026-03-12-minimum-viable-prospect-research/)
- [Follow-up](/hubs/ai-for-sales/follow-up/)
