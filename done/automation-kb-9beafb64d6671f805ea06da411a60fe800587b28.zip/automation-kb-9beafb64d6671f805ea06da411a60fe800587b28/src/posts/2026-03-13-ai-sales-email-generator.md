---
title: "AI sales email generator workflow"
description: "Using AI to generate first draft sales emails."
layout: "post"
tags: [ai-for-sales, tools]
---

## Workflow
1. collect prospect context
2. generate email draft
3. review personalization
4. send outreach
