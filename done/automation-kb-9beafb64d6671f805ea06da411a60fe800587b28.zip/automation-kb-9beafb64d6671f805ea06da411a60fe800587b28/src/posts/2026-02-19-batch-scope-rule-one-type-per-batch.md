---
title: 2026-02-19-batch-scope-rule-one-type-per-batch
description: ""
date: 2026-02-19
tags: []
primaryTag: workflow
summary: "Short: 2026-02-19-batch-scope-rule-one-type-per-batch"
---


# Batch scope rule: one type per batch to avoid chaos





## Types


- TYPE-CONTENT: add/update posts only


- TYPE-STRUCTURE: nav, taxonomy, routes


- TYPE-DESIGN: layout, styling


- TYPE-OPTIMIZE: performance/build/SEO tuning





## Why


Small, clear batches are faster to trust.





