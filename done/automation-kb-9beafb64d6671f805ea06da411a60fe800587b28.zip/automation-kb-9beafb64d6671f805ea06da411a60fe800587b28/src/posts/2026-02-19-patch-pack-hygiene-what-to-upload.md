---
title: 2026-02-19-patch-pack-hygiene-what-to-upload
description: ""
date: 2026-02-19
tags: []
primaryTag: workflow
summary: "Short: 2026-02-19-patch-pack-hygiene-what-to-upload"
---


# Patch-pack hygiene: what to upload and what to ignore

## Upload
- Files that map to repo paths (usually under `src/`)

## Ignore
- Artifact-level README/SHA that would land in repo root unless you explicitly want them there.

## Why
Keep the repo clean and the site source obvious.



