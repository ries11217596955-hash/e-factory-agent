---
title: 2026-02-18-qa-routine-after-merge
description: ""
date: 2026-02-18
tags: []
primaryTag: workflow
summary: "Short: 2026-02-18-qa-routine-after-merge"
---


## Minimum checks





After merging a PR to `main`, verify:





1) Cloudflare Pages build status is **Success**


2) Open the changed URL(s)


3) Check CSS is loaded (if not, suspect asset path or cache)


4) Confirm **Posts** list includes new items


5) Confirm **RSS** includes new items (when applicable)





## When to stop and fix





Stop adding new content if:





- Build fails


- A core page returns 404


- The Posts list or RSS is empty unexpectedly





