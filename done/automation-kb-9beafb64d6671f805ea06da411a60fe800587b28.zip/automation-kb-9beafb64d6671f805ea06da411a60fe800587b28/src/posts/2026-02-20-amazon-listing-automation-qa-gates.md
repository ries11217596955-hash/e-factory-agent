---
title: 2026-02-20-amazon-listing-automation-qa-gates
description: ""
date: 2026-02-20
tags: []
primaryTag: workflow
summary: "Short: 2026-02-20-amazon-listing-automation-qa-gates"
---


# Amazon listing QA gates





Block the run if:


- required fields missing


- forbidden placeholders remain


- images not generated





Prefer fail-fast with a clear reason.





