---
title: "Sales playbook: product demo process"
description: "Running effective product demos."
layout: "post"
tags: [sales, demo]
---

## Workflow
1. prepare demo scenario
2. present key features
3. capture questions
4. schedule next step
