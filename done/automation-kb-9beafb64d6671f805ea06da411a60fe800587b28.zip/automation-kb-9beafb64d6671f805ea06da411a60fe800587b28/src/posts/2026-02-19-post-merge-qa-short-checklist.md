---
title: 2026-02-19-post-merge-qa-short-checklist
description: ""
date: 2026-02-19
tags: []
primaryTag: workflow
summary: "Short: 2026-02-19-post-merge-qa-short-checklist"
---


# Post-merge QA: the shortest checklist that catches 80% of issues

## 2-minute routine
- Home loads
- Posts index loads
- Hubs index loads (or 1 hub page)
- One new post loads
- Search works (if present)

If any step fails, revert the commit and fix in a new batch.



