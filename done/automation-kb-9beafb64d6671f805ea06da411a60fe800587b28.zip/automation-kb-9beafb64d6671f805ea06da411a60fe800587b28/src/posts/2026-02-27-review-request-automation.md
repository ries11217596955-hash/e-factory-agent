---
title: "Review Request Automation (Increase Social Proof)"
date: "2026-02-27"
primaryTag: "ecommerce-automation"
summary: "A review request workflow that increases reviews without annoying customers: timing, segmentation, and suppression rules."
tags: ["ecommerce", "reviews", "automation", "retention", "workflow"]
---

# Objective
Get more reviews and reduce refunds.

Hub: [Ecommerce Automation](/hubs/ecommerce-automation/)

## Workflow
1. Detect delivered order
2. Wait 7-14 days (depends on product)
3. Send review request:
   - simple CTA
   - one question prompt
4. Suppression:
   - do not send if return requested
   - do not send if support ticket open
5. Escalation:
   - if negative feedback, route to support

## Output
- Review volume increases
- Support catches problems earlier

Related:
- [Abandoned Cart Email Automation](/posts/2026-02-27-abandoned-cart-email-automation/)
- [Ecommerce Analytics KPI Workflow](/posts/2026-02-27-ecommerce-analytics-kpi-workflow/)
