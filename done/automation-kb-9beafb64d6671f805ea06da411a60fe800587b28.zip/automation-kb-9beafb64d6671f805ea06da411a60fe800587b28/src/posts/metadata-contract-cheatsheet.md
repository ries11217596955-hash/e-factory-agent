---
title: metadata-contract-cheatsheet
description: ""
date: 2026-02-24
tags: []
primaryTag: workflow
summary: "Short: metadata-contract-cheatsheet"
---


## Required (recommended)


- `title`: human-readable title


- `summary`: one-line value for cards and lists


- `tags`: must include base tag (`posts` / `news` / `tools`)





## Dates


- `updated`: use when the item is edited later (preferred for entryDate)


- `date`: initial publish date (fallback)





The site uses: **entryDate = updated || date**.





## Optional


- `description`: longer text (used only if summary is missing)


- `eleventyExcludeFromCollections`: for pages that should not show up in lists





## Examples


See templates:


- `/tools/content-template-post/`


- `/tools/content-template-news/`


- `/tools/content-template-tool/`





