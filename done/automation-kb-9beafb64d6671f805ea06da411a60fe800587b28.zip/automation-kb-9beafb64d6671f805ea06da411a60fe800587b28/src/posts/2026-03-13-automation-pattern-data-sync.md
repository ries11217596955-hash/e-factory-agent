---
title: "Automation pattern: data synchronization"
description: "Synchronizing records across systems."
layout: "post"
tags: [automation, data]
---

## Workflow

1. detect data change
2. transform format
3. update destination
4. confirm sync
