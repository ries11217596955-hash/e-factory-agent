---
title: "AI incident summary workflow"
description: "Summarizing operational incidents."
layout: "post"
tags:
- automation
- operations
---

## Workflow
1. collect timeline
2. summarize cause
3. extract lessons
4. produce report
