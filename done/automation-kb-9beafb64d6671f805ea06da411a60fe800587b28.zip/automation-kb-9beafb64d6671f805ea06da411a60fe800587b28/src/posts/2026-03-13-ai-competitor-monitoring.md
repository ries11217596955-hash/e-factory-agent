---
title: "AI competitor monitoring workflow"
description: "Monitoring competitor activity using AI summaries."
layout: "post"
tags:
- research
- automation
---

## Workflow
1. gather updates
2. summarize changes
3. detect strategy signals
4. distribute summary
