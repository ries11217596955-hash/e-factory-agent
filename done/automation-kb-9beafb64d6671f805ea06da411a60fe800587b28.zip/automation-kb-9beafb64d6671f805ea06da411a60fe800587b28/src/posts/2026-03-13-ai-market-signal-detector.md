---
title: "AI market signal detector"
description: "Detecting signals like hiring or launches."
layout: "post"
tags: [research, automation]
---

## Workflow
1. gather signals
2. analyze updates
3. detect events
4. notify team
