---
title: 2026-02-26-follow-up-automation-framework
description: "A 7-touch follow-up plan that stays human, uses evidence, and doesn't burn your domain."
date: 2026-02-26
tags: [ai-for-sales, workflow, outreach]
primaryTag: workflow
summary: "Short: Follow-up automation framework"
---

## Follow-up automation framework (without spam)

Most deals die because follow‑up is inconsistent.

### 7 touches (14 days)
1) Day 0: short opener + question
2) Day 2: add **one** evidence line (signal you saw)
3) Day 4: share a tiny asset (checklist / 1‑pager)
4) Day 6: ask for the "right owner" (routing)
5) Day 9: mini case (2 lines: problem → result)
6) Day 12: "close the loop" polite exit
7) Day 14: optional LinkedIn touch (not copy/paste)

### Automation rule
Automate *scheduling* and *drafting*, not "sending blindly".
- AI drafts message variants.
- You approve the final send.

### Personalization rule (cheap but effective)
Each message must include exactly one of:
- a verifiable signal
- a specific workflow you improve
- a question that matches their persona

### Stop conditions
- Hard bounce → stop
- "Not interested" → stop
- "Later" → set next action date, stop for 30 days

Pair this with the "minimum enrichment fields" post.
