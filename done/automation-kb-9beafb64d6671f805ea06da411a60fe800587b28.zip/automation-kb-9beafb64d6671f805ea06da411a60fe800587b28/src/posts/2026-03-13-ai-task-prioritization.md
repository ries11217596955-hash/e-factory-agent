---
title: "AI task prioritization workflow"
description: "Prioritizing tasks from operational backlogs."
layout: "post"
tags:
- automation
- productivity
---

## Workflow
1. collect task list
2. detect dependencies
3. estimate impact
4. rank tasks
