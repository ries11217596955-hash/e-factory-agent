---
title: "AI support response drafting"
description: "Generating first drafts for support replies."
layout: "post"
tags:
- support
- automation
---

## Workflow
1. detect issue category
2. generate draft response
3. review accuracy
4. send reply
