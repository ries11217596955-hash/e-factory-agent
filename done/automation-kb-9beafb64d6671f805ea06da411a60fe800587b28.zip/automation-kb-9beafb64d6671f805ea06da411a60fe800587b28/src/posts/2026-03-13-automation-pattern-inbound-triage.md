---
title: "Automation pattern: inbound request triage"
description: "Routing inbound requests using automated classification."
layout: "post"
tags: [automation, patterns]
---

## Pattern

Large volumes of inbound requests require structured triage.

## Workflow

1. capture inbound request
2. classify request type
3. assign processing queue
4. notify responsible team
