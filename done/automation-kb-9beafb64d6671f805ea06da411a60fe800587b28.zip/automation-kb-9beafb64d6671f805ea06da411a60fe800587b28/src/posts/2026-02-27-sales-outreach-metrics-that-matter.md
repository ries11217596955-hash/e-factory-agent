---
title: "Sales outreach metrics that matter (and what to ignore)"
description: "A small metrics set to steer outreach: reply rate, qualified rate, and time-to-next-step."
date: 2026-02-27
primaryTag: operations
tags: ["sales-ops", "metrics", "operations", "workflow"]
summary: "A small metrics set to steer outreach: reply rate, qualified rate, and time-to-next-step."
---
# Sales outreach metrics that matter (and what to ignore)

If metrics don't change decisions, they're noise.

## Keep only what drives action
- reply rate (by channel)
- qualified rate (by ICP segment)
- time-to-next-step
- pipeline stage conversion

## Ignore (for now)
- vanity impressions
- too many micro-metrics

## Related
- Hub: [/hubs/operations/](/hubs/operations/)
