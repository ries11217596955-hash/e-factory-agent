---
title: "Automation pattern: feedback loop"
description: "Using feedback signals to improve workflows."
layout: "post"
tags: [automation, optimization]
---

## Workflow

1. collect feedback
2. analyze results
3. detect improvement signals
4. update process
