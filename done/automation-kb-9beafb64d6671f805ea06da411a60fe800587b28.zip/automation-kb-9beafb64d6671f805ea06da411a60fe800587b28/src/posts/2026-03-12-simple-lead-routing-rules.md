---
title: "Simple lead routing rules"
description: "A small routing model for deciding whether a lead should be pursued, nurtured, or skipped without wasting review time."
layout: "post"
tags:
  - "ai-for-sales"
  - "qualification"
  - "lead-routing"
  - "crm"
---

## Why routing matters

If every lead goes into the same pile, the team loses speed.

Routing exists to protect attention.

## The minimum routing model

Use three outputs:

- pursue
- nurture
- skip

That is enough for most small teams.

## Decision inputs

Use only a few fields:

- ICP fit
- problem relevance
- contact path quality
- urgency signal
- confidence level

## Fast routing rules

### Pursue
Use when:
- ICP fit is clear
- problem relevance is visible
- there is a reachable path
- next action is obvious

### Nurture
Use when:
- fit seems possible
- timing is weak
- data is incomplete
- message should wait for a later trigger

### Skip
Use when:
- fit is poor
- no real problem signal exists
- channel is weak
- effort would exceed probable value

## The trap to avoid

Do not create 9 stages before the team is ready.

Too many stages:
- slow triage
- create fake certainty
- fill CRM with noise

## Weekly review

Check:
- how many went to pursue
- how many became meetings
- how many nurture leads should be reactivated
- how many skip decisions were wrong

That is enough to improve routing over time.

## Related paths

- [Qualification](/hubs/ai-for-sales/qualification/)
- [Build an AI sales system from zero](/posts/2026-03-12-build-ai-sales-system-from-zero/)
- [Follow-up](/hubs/ai-for-sales/follow-up/)
