---
title: "Sales playbook: referral requests"
description: "Generating referrals from satisfied clients."
layout: "post"
tags: [sales, referrals]
---

## Workflow
1. identify happy customers
2. request referral
3. capture contact
4. start outreach
