---
title: "Sales playbook: re‑engagement"
description: "Reactivating dormant prospects."
layout: "post"
tags: [sales, outreach]
---

## Workflow
1. detect inactive leads
2. craft re‑engagement message
3. send sequence
4. track results
