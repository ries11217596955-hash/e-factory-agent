---
title: "AI proposal draft generator"
description: "Generating proposal drafts automatically."
layout: "post"
tags: [ai-for-sales, documents]
---

## Workflow
1. collect deal data
2. generate proposal
3. edit sections
4. export document
