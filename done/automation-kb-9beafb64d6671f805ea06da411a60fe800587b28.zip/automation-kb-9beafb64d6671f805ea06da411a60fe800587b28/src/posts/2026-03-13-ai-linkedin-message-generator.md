---
title: "AI LinkedIn message generator"
description: "Generating LinkedIn outreach drafts."
layout: "post"
tags: [ai-for-sales, outreach]
---

## Workflow
1. capture profile
2. detect context
3. generate message
4. edit and send
