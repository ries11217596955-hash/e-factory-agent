---
title: "Follow-up sequence automation framework (without annoying people)"
description: "A follow-up framework that balances persistence with respect: timing rules, message variants, and stop conditions."
date: 2026-02-27
primaryTag: ai-for-sales
tags: ["follow-up", "automation", "sales-ops", "email", "linkedin"]
summary: "A follow-up framework that balances persistence with respect: timing rules, message variants, and stop conditions."
---
# Follow-up sequence automation framework (without annoying people)

Most follow-ups fail because they repeat the same message. Each follow-up should add something.

## Timing (starter)
- Day 0: initial
- Day 2: follow-up #1 (value)
- Day 5: follow-up #2 (question)
- Day 10: close the loop

## Stop conditions
- explicit "no"
- no fit
- no valid channel
- bounced email

## Related
- Hub: [/hubs/ai-for-sales/](/hubs/ai-for-sales/)
