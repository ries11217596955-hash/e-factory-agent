---
title: 2026-02-18-batch-workflow
description: ""
date: 2026-02-18
tags: []
primaryTag: workflow
summary: "Short: 2026-02-18-batch-workflow"
---


## The contract

We ship changes in **batches**:

- One batch = one coherent module (content or structure).
- Delivered as a **ZIP patch-pack** that mirrors repo paths (no extra wrapper folders).
- Applied in GitHub via: branch → single commit → PR → merge → Pages build check.

## What each batch includes

- Changed/new files only
- `README.txt` with goals and success criteria
- `SHA256SUMS.txt` for integrity

## Why this is the default

It keeps changes reviewable, reversible, and easy to apply without local tooling.



