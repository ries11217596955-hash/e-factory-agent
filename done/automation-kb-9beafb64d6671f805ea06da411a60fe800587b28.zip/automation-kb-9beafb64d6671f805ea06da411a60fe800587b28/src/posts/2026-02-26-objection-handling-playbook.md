---
title: 2026-02-26-objection-handling-playbook
description: "Common objections (budget, timing, trust, complexity) and short responses that keep the conversation moving."
date: 2026-02-26
tags: [ai-for-sales, workflow, sales]
primaryTag: workflow
summary: "Short: Objection handling playbook"
---

## Objection handling playbook for AI/automation offers

Use objections to identify the real constraint.

### 1) "We don't have budget"
Response:
- "Understood. If we could save <time/cost> in <workflow> within 30 days, would that justify it?"
Next:
- Offer a smaller pilot or a diagnostic.

### 2) "We tried automation/AI before"
Response:
- "What failed: data, adoption, or maintenance?"
Next:
- Propose a workflow with a measurable outcome and a rollback plan.

### 3) "We're too busy"
Response:
- "Then we should reduce scope. What's the single most painful manual step right now?"
Next:
- A 1‑week quick win.

### 4) "Security / trust concerns"
Response:
- "We can run this with minimal data: only public signals + synthetic examples until approved."
Next:
- Agree on data boundaries.

### 5) "Send info"
Response:
- "Sure - do you care more about speed, quality, or cost?"
Next:
- Send a 1‑pager aligned to that axis.

Keep responses short. Always end with a question.
