---
title: 2026-02-26-lead-enrichment-minimum-fields
description: "A minimal lead record schema you can enrich quickly and reuse across outreach, follow-ups, and reporting."
date: 2026-02-26
tags: [ai-for-sales, workflow, data]
primaryTag: workflow
summary: "Short: Lead enrichment minimum fields"
---

## Lead enrichment: the minimum fields that actually matter

Over‑enrichment kills speed. Under‑enrichment kills follow‑up.

### Minimum lead record (copy/paste)
- **Company:** …
- **Domain:** …
- **Persona/Role:** …
- **Primary pain hypothesis:** …
- **Signal evidence:** (URL or short note)
- **Offer fit workflow:** (one workflow you improve)
- **Channel:** (email / LinkedIn / referral)
- **Next action date:** …
- **Status:** new / contacted / replied / meeting / closed

### Enrichment order (fast)
1) Domain + product category (from website)
2) Persona validation (role match)
3) One signal (job post, launch, policy, pricing change)
4) One workflow target (inventory, support, attribution, reporting)
5) Next action date (so you don't lose the lead)

### AI usage (safe)
AI is best for:
- turning evidence → hypothesis
- turning hypothesis → a good question
AI is **not** trustworthy for:
- revenue, traffic, employee count, "they use tool X" unless verified

### Output you want
A record you can feed into:
- outreach message generator
- follow‑up scheduler
- pipeline dashboard

Keep it minimal and consistent.
