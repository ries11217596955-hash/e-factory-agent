---
title: "Automation pattern: research aggregation"
description: "Collecting and summarizing research signals."
layout: "post"
tags: [automation, research]
---

## Workflow

1. collect research inputs
2. normalize sources
3. summarize insights
4. distribute summary
