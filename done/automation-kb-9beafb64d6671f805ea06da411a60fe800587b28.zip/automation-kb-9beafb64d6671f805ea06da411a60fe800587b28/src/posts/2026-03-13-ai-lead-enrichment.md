---
title: "AI lead enrichment workflow"
description: "Enhancing lead profiles using AI."
layout: "post"
tags: [ai-for-sales, enrichment]
---

## Workflow
1. collect lead data
2. enrich company profile
3. detect signals
4. update CRM
