---
title: 2026-02-18-kb-structure
description: ""
date: 2026-02-18
tags: []
primaryTag: workflow
summary: "Short: 2026-02-18-kb-structure"
---


## The site model

This knowledge base is intentionally simple:

- **Hubs** are topic entry pages (curated links).
- **Posts** are the actual content items.
- **Tags** help discovery across hubs.
- A small set of "must work" pages acts as a safety net: Home, Hubs, Posts, Tags, Search, Support.

## Why this matters

When you add content, always ensure:

1) The hub links to it (if it belongs to that hub).
2) The post has correct front matter (date, tags, permalink).
3) It shows up in lists (Posts page and RSS).

If any of those breaks, treat it as a structural defect and fix before adding more content.



