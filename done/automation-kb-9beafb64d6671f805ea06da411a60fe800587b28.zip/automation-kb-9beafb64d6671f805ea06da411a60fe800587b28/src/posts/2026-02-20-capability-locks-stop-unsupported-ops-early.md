---
title: 2026-02-20-capability-locks-stop-unsupported-ops-early
description: ""
date: 2026-02-20
tags: []
primaryTag: workflow
summary: "Short: 2026-02-20-capability-locks-stop-unsupported-ops-early"
---


# Capability locks (fail-fast)





When your pipeline is spec-driven, the worst failure mode is **silent no-op**.





## The pattern


- Declare `required_ops` in the spec.


- Tool prints `supported_ops`.


- Workflow compares them before running.





## Result


You never hit `Unsupported op.type` in the middle of a run.





