---
title: 2026-02-20-order-lifecycle-proof-inbox-work-done
description: ""
date: 2026-02-20
tags: []
primaryTag: workflow
summary: "Short: 2026-02-20-order-lifecycle-proof-inbox-work-done"
---


# Order lifecycle proof





Track each order through directories:


- `inbox/` → `_work/` → `done/` or `failed/`





Write a `REPORT.json` with deterministic fields.





This gives you auditability without heavy tooling.





