---
title: "AI sales note summarizer"
description: "Summarizing CRM notes using AI."
layout: "post"
tags: [ai-for-sales, productivity]
---

## Workflow
1. collect notes
2. summarize interaction
3. extract next steps
4. update CRM
