---
title: "Automation pattern: process checkpoints"
description: "Adding validation checkpoints to workflows."
layout: "post"
tags: [automation, operations]
---

## Workflow

1. execute step
2. validate output
3. approve checkpoint
4. continue workflow
