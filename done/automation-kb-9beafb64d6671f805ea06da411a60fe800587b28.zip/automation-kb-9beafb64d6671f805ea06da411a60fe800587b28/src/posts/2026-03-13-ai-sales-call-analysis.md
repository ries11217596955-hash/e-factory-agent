---
title: "AI sales call analysis workflow"
description: "Analyzing sales calls using AI to extract insights."
layout: "post"
tags:
- ai-for-sales
- workflow
---

## Workflow
1. transcribe call
2. summarize key points
3. extract objections
4. highlight improvement areas
