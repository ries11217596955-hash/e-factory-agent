---
title: "Sales playbook: outbound outreach"
description: "Structured outbound sales workflow."
layout: "post"
tags: [sales, outreach]
---

## Workflow
1. research prospect
2. craft outreach message
3. send sequence
4. track responses
