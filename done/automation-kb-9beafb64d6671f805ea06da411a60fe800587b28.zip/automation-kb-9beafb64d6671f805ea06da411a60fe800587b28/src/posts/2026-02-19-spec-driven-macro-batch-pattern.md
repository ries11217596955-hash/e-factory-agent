---
title: 2026-02-19-spec-driven-macro-batch-pattern
description: ""
date: 2026-02-19
tags: []
primaryTag: workflow
summary: "Short: 2026-02-19-spec-driven-macro-batch-pattern"
---


# Spec-driven changes: a repeatable macro-batch pattern





## Why this pattern works


- Deterministic input (spec)


- Reviewable output (patch-pack)


- Atomic merge (one commit)





## The loop


1) Write spec


2) Run workflow


3) Download patch-pack


4) Commit via GitHub UI


5) Cloudflare deploy





## Rule


One batch = one type = one meaning.





