---
title: "Sales follow-up queue design"
description: "A simple operating model for follow-up queues, priorities, and recovery rules in small sales teams."
layout: "post"
date: 2026-03-18
tags:
  - ai-for-sales
  - workflow
  - operations
summary: "How to structure a follow-up queue so leads do not stall or disappear between touches."
---

## Why this matters

Most small sales teams do not lose leads because of strategy. They lose them because follow-up lives in scattered notes, inboxes, and memory.

## Minimum queue model

Use one working queue with four states:

1. new lead
2. waiting for response
3. follow-up due
4. stalled / recycle

## Core rules

- every lead must have a next action date
- no lead stays without owner
- stalled leads move to recycle instead of disappearing
- overdue follow-ups should be visible in one filtered view

## Where AI helps

AI can draft follow-up text, summarize prior touchpoints, and surface leads that are overdue or at risk of being forgotten.
