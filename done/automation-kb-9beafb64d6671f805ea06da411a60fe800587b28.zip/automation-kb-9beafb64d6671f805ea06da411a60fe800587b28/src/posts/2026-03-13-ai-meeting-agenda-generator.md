---
title: "AI meeting agenda generator"
description: "Creating meeting agendas automatically."
layout: "post"
tags: [productivity, automation]
---

## Workflow
1. collect goals
2. generate agenda
3. assign topics
4. distribute
