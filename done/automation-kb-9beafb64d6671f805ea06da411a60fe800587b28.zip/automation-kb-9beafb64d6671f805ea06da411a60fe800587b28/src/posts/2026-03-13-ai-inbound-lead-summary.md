---
title: "AI inbound lead summary workflow"
description: "Summarizing inbound lead information."
layout: "post"
tags:
- ai-for-sales
- workflow
---

## Workflow
1. capture form data
2. summarize company
3. detect intent
4. produce short lead brief
