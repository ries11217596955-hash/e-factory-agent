---
title: 2026-02-18-agent-failure-taxonomy
description: ""
date: 2026-02-18
tags: []
primaryTag: workflow
summary: "Short: 2026-02-18-agent-failure-taxonomy"
---


## Taxonomy (starter)


- CONFIG: wrong paths, missing secrets, wrong env


- INPUT: malformed order, missing required fields


- TOOL: external dependency down, API changes


- LOGIC: bug in workflow, wrong branching


- DELIVER: output missing, wrong target dir


- QUALITY: output exists but fails acceptance checks





## How to use it


1) Every FAIL gets exactly one primary class.


2) Record evidence (log line, file path, URL).


3) Fixes must include a guard so it doesn't recur.





