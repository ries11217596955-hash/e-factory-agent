---
title: 2026-02-20-idempotent-navigation-updates-without-duplicates
description: ""
date: 2026-02-20
tags: []
primaryTag: workflow
summary: "Short: 2026-02-20-idempotent-navigation-updates-without-duplicates"
---


# Idempotent nav updates





Goal: reruns must not duplicate menu items.





Approach:


- Patch using stable markers (unique token).


- Or enforce a structured update (JSON-aware op).





Fail-fast is better than drift.





