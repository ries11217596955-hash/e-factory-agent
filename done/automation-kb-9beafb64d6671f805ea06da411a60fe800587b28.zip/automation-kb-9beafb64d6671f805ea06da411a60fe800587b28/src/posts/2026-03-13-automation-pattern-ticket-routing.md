---
title: "Automation pattern: ticket routing"
description: "Routing support tickets automatically."
layout: "post"
tags: [automation, support]
---

## Workflow

1. capture ticket
2. classify issue
3. assign support queue
4. notify agent
