---
title: "Sales playbook: inbound lead handling"
description: "Operational playbook for handling inbound leads."
layout: "post"
tags: [sales, playbook]
---

## Steps
1. capture inbound request
2. qualify lead
3. schedule call
4. follow up
