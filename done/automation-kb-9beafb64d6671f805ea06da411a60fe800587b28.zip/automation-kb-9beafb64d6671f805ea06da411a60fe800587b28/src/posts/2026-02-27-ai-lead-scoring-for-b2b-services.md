---
title: "AI lead scoring for B2B ecommerce services"
description: "A scoring model you can implement fast: signals, weights, and how to avoid overfitting to vanity metrics."
date: 2026-02-27
primaryTag: ai-for-sales
tags: ["ai", "lead-scoring", "b2b", "ecommerce", "sales-ops"]
summary: "A scoring model you can implement fast: signals, weights, and how to avoid overfitting to vanity metrics."
---
# AI lead scoring for B2B ecommerce services

Lead scoring is a decision aid. It should explain *why* a lead is hot, not just output a number.

## Signals (examples)
- Fit: niche match, region, size
- Need: symptoms on the site/store, reviews, product complexity
- Timing: recent hires, recent platform change, new product launch
- Access: reachable contact channel

## Weights (starter)
- Fit 40%
- Need 30%
- Timing 20%
- Access 10%

## Rule: score must be debuggable
Store the top 3 reasons that produced the score.

## Related
- Hub: [/hubs/ai-for-sales/](/hubs/ai-for-sales/)
