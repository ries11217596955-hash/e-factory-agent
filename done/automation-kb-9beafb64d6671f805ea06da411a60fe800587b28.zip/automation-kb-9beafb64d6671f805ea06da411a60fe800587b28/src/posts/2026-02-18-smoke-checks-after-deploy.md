---
title: 2026-02-18-smoke-checks-after-deploy
description: ""
date: 2026-02-18
tags: []
primaryTag: workflow
summary: "Short: 2026-02-18-smoke-checks-after-deploy"
---


## Why
After a successful deployment, changes can still look "missing" due to caching or asset routing issues.

## Minimal checks
1) Open the changed pages (no 404).  
2) Open `/assets/site.css`: HTTP 200 and the response is CSS (not HTML/redirect).  
3) Confirm the CSS marker string is present (example: `automation-kb`).  
4) Open `/feeds/posts.xml`: HTTP 200 and new items are included.

## Notes
If the site looks unstyled but pages load, CSS delivery is the first suspect.



