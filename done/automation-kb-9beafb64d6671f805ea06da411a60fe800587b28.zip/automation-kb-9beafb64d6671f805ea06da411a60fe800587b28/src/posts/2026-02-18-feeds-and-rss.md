---
title: 2026-02-18-feeds-and-rss
description: ""
date: 2026-02-18
tags: []
primaryTag: workflow
summary: "Short: 2026-02-18-feeds-and-rss"
---


## What to verify





- Feed URL returns **200**


- The output is XML (not HTML)


- New posts appear as new items





## Common causes of feed issues





- Posts missing required front matter (date/tags/permalink)


- Collections configuration drifting


- A template error prevents Eleventy from writing output





If feed breaks, fix it before publishing more content.





