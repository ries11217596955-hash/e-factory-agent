---
title: "Sales playbook: proposal stage"
description: "Managing proposal and negotiation stage."
layout: "post"
tags: [sales, proposal]
---

## Workflow
1. prepare proposal
2. review requirements
3. send document
4. follow negotiation
