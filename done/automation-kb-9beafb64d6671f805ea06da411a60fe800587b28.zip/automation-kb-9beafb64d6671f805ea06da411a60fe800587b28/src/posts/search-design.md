---
title: search-design
description: ""
date: 2026-02-24
tags: []
primaryTag: workflow
summary: "Short: search-design"
---


For a small KB, client-side search is often enough.





### Approach


- Generate `/search/index.json` from `collections.posts/news/tools`


- Search across `title`, `summary`, `description`, `tags`


- Render results as the same cards used in list pages





