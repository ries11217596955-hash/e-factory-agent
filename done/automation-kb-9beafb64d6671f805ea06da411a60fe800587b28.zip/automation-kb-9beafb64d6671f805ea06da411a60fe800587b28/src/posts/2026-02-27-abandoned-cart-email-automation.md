---
title: "Abandoned Cart Email Automation (3-Step Sequence)"
date: "2026-02-27"
primaryTag: "ecommerce-automation"
summary: "A simple abandoned cart sequence that boosts revenue: 3 emails with timing rules, safe personalization tokens, and fail-safes."
tags: ["ecommerce", "email", "retention", "automation", "conversion"]
---

# Objective
Recover revenue without spamming customers.

Hub: [Ecommerce Automation](/hubs/ecommerce-automation/)

## Inputs
- Cart created
- Email captured
- Items (SKU, title, price)

## Sequence
1. **Email 1: Reminder**
   - Send after 1 hour
   - Message: "You left items in your cart"
2. **Email 2: Social proof**
   - Send after 24 hours
   - Add: reviews or short FAQ
3. **Email 3: Offer (optional)**
   - Send after 48-72 hours
   - Add: small discount or free shipping

## Safe personalization
Use plain tokens:
- FIRST_NAME
- PRODUCT_TITLE
- CART_VALUE

Avoid any bracket template syntax in site content.

## Suppression rules
- Stop sequence if order is paid
- Stop after 3 emails
- Do not send if user opted out

Related:
- [Review Request Automation](/posts/2026-02-27-review-request-automation/)
- [Ecommerce Analytics KPI Workflow](/posts/2026-02-27-ecommerce-analytics-kpi-workflow/)
