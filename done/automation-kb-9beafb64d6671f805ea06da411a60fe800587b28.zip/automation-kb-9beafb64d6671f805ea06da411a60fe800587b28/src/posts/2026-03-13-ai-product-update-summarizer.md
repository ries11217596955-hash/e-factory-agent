---
title: "AI product update summarizer"
description: "Summarizing product release notes."
layout: "post"
tags: [automation, research]
---

## Workflow
1. collect release notes
2. summarize changes
3. extract highlights
4. distribute summary
