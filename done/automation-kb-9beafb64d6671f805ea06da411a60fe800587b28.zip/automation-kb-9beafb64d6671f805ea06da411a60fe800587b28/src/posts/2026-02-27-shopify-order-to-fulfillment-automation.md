---
title: "Shopify Order → Fulfillment Automation (Exceptions Included)"
date: "2026-02-27"
primaryTag: "ecommerce-automation"
summary: "A workflow to move an order from paid to delivered with exception handling: stockouts, address issues, delays, and failed deliveries."
tags: ["ecommerce", "shopify", "fulfillment", "workflow", "operations"]
---

# Why this matters
Most stores "automate the happy path" and drown in exceptions. This workflow makes exceptions the default.

Hub: [Ecommerce Automation](/hubs/ecommerce-automation/)

## Inputs
- Order event (paid)
- Fulfillment provider (3PL or in-house)
- Tracking provider / carrier events

## Workflow
1. **Order created**
   - Validate address format (basic rules)
   - Validate stock availability (SKU-level)
2. **Decide fulfillment route**
   - In-stock → send to fulfillment
   - Low stock → hold and notify
3. **Fulfillment created**
   - Generate pick list (if in-house)
   - Create shipment label (if applicable)
4. **Tracking**
   - Capture tracking number
   - Send customer notification
5. **Delivery monitoring**
   - Track status changes
   - Alert on delays

## Exception table
- Stockout → auto-email + offer alternatives
- Address invalid → request confirmation + hold
- Carrier delay → proactive update after N days
- Delivery failed → open ticket + resend/return

## Outputs
- Status updates
- Ops alerts
- Support tickets only when needed

Related:
- [Inventory Sync & Alerts](/posts/2026-02-27-inventory-sync-and-alerts/)
- [Returns (RMA) Automation](/posts/2026-02-27-returns-and-rma-automation/)
