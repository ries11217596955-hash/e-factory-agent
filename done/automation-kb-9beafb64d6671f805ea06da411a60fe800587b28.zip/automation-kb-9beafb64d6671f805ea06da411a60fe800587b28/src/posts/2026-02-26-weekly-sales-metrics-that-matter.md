---
title: 2026-02-26-weekly-sales-metrics-that-matter
description: "A minimal weekly dashboard: volume is useless without reply quality and meeting conversion."
date: 2026-02-26
tags: [ai-for-sales, workflow, metrics]
primaryTag: workflow
summary: "Short: Weekly sales metrics"
---

## Weekly sales metrics that matter (small team)

Track metrics that force action.

### Weekly dashboard (minimal)
- New leads added
- Touches sent
- Replies (positive / neutral / negative)
- Meetings booked
- Deals moved (proposal/won/lost)

### Two ratios to watch
- **Reply rate** = replies / touches
- **Meeting conversion** = meetings / positive replies

### Quality notes (1 line each)
- Top message variant this week
- Top signal type (what personalization worked)
- Top objection

If metrics don't change your decisions, delete them.
