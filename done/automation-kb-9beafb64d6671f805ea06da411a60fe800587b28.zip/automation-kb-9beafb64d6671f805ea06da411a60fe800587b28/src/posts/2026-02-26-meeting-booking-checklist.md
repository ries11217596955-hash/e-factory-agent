---
title: 2026-02-26-meeting-booking-checklist
description: "A short checklist to avoid wasted meetings: define the goal, the workflow, data boundaries, and success metric."
date: 2026-02-26
tags: [ai-for-sales, workflow, sales]
primaryTag: workflow
summary: "Short: Meeting booking checklist"
---

## Meeting booking checklist: what to confirm before you accept

Wasted meetings are expensive. Qualify fast.

### Before you accept a meeting
1) **Who is joining?** (decision maker vs evaluator)
2) **Which workflow?** (pick one: support, inventory, reporting, attribution, content ops)
3) **Success metric?** (time saved / errors reduced / speed increased)
4) **Constraints?** (security, tools, timeline)
5) **Next step if it fits?** (pilot, diagnostic, proposal)

### Simple agenda (15-20 min)
- 5 min: current process
- 5 min: pain + constraints
- 5 min: pilot outline + metric
- 5 min: next steps

Use this after your ICP scorecard.
