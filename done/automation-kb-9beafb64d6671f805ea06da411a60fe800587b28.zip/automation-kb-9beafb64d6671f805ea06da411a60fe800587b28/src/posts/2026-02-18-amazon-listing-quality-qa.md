---
title: 2026-02-18-amazon-listing-quality-qa
description: ""
date: 2026-02-18
tags: []
primaryTag: workflow
summary: "Short: 2026-02-18-amazon-listing-quality-qa"
---


## Checklist (fast)


1) Title: key tokens present, no forbidden formatting.


2) Bullets: clear claims, no duplicate lines, no empty bullets.


3) Images: correct order, no missing primary, consistent background where required.


4) Variations: child ASINs aligned (sizes/colors), no broken mapping.


5) Backend keywords: not stuffed, no banned terms.


6) Policy: no restricted claims.





## Automation pattern


- Generate a **diff report** (before/after fields).


- Block deploy if any required field becomes empty.


- Sample-check 5 listings manually after each batch.





