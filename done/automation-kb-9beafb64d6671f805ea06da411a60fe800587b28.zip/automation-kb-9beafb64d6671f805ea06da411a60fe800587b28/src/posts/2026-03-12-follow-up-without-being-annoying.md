---
title: "Follow-up without being annoying"
description: "How to keep follow-up disciplined, useful, and human instead of repetitive or spammy."
layout: "post"
tags:
  - "ai-for-sales"
  - "follow-up"
  - "sales-hygiene"
---

## The real problem

Most follow-up fails for one of two reasons:

- it stops too early
- it becomes repetitive noise

A good follow-up system avoids both.

## What good follow-up does

Each follow-up should do at least one of these:
- add clarity
- reduce friction
- change the angle
- close the loop

If it does none of them, it is probably unnecessary.

## A simple sequence

### Follow-up 1
Restate the core angle briefly.

### Follow-up 2
Add one practical example or clarification.

### Follow-up 3
Change the frame:
- cost of delay
- common failure mode
- easier next step

### Final follow-up
Close respectfully and make future re-entry easy.

## What to avoid

Do not send:
- "just checking in"
- "bumping this"
- long AI-generated paragraphs
- guilt-based nudges

These damage trust fast.

## CRM hygiene rule

Every follow-up should leave:
- last action
- next action
- next date
- short note

That is enough to keep discipline.

## When to stop

Stop when:
- the lead says no
- timing is clearly wrong
- the sequence reached its limit
- there is no new value to add

Stopping well is part of good process.

## Related paths

- [Follow-up](/hubs/ai-for-sales/follow-up/)
- [Outreach angle before personalization](/posts/2026-03-12-outreach-angle-before-personalization/)
- [Simple lead routing rules](/posts/2026-03-12-simple-lead-routing-rules/)
