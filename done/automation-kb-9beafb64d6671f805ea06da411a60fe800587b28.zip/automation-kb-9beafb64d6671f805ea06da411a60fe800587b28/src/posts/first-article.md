---
title: first-article
description: ""
date: 2026-02-24
tags: []
primaryTag: workflow
summary: "Short: first-article"
---


This is a test article page. If you can read this, `article.njk` works.





