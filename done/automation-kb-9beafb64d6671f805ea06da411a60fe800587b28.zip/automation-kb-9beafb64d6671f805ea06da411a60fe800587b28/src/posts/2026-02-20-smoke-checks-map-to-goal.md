---
title: 2026-02-20-smoke-checks-map-to-goal
description: ""
date: 2026-02-20
tags: []
primaryTag: workflow
summary: "Short: 2026-02-20-smoke-checks-map-to-goal"
---


# Smoke checks





A good smoke test is short and tied to the goal.





Example for hubs:


1) `/hubs/` lists hubs


2) hub page exists


3) latest posts renders


4) nav contains Hubs


5) build is green





