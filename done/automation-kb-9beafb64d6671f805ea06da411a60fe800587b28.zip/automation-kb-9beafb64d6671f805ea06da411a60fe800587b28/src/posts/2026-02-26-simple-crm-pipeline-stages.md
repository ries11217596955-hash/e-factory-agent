---
title: 2026-02-26-simple-crm-pipeline-stages
description: "A small set of stages you can run in any spreadsheet/CRM without losing leads or overcomplicating."
date: 2026-02-26
tags: [ai-for-sales, workflow, ops]
primaryTag: workflow
summary: "Short: Simple CRM pipeline stages"
---

## Simple CRM pipeline stages (for solo operators)

A pipeline is just a queue with rules.

### Stages
- **New** (enriched, not contacted)
- **Contacted** (touch 1 sent)
- **In conversation** (reply received)
- **Meeting** (scheduled)
- **Proposal** (sent)
- **Won / Lost**
- **Nurture** (next action date set)

### Required fields per stage
- New: enrichment minimum fields
- Contacted: channel + message variant + next action date
- In conversation: objection / question to answer
- Meeting: agenda + success metric
- Proposal: scope + timeline + metric

### Weekly ritual
- Move everything forward or move it to nurture/close.
No "stuck" stage allowed.
