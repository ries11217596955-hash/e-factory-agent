---
title: GitHub Actions as a Stateless Batch Runner for Site Updates
description: How to use GitHub Actions as a safe stateless runner for one-shot patch batches, duplicate guards, and repo-based queue flow.
date: 2026-04-01
tags: [workflow, operations, github-actions, batch-processing]
primaryTag: workflow
summary: "Use GitHub Actions as a one-shot batch runner: inbox → run → done, with duplicate protection and commit proof."
---

GitHub Actions works well for **one-shot automation** when you do not need a long-running local agent.

The key idea is simple:

- a batch is uploaded to a repo-controlled inbox
- the workflow starts manually (or later by trigger)
- one runner processes one batch
- the result is committed back to the repo
- the batch leaves the inbox and moves to done/history

That is not a "memory agent." It is a **stateless runner**.

## What stateless means in practice

Each run starts in a clean environment.

The workflow **does remember the code**, because the logic lives in the repository.
But it does **not remember runtime state** unless you store that state outside the runner.

That means:

- it knows *how* to process a batch
- it does **not** automatically know which batches were already processed
- duplicate protection must come from repo history, queue rules, or explicit state files

## When this model is a good fit

Use a stateless runner when the task is:

1. **one-shot**
2. **bounded in time**
3. **safe to verify from artifacts and commit history**
4. **easy to rerun or skip**

Examples:

- patch batch apply
- site audit run
- content generation batch
- post-build QA routine

## The minimal safe pattern

The smallest safe pattern is:

```text
inbox → run → done
```

With three extra guards:

1. **duplicate check** before execution  
2. **single-batch processing** per run  
3. **commit proof** after execution  

That gives you a clean operational model without needing a local always-on PC.

## A practical duplicate guard

A simple way to stop duplicate execution is to record a marker in commit history.

Example:

```text
GH_BATCH:batch-002
```

Before processing, the workflow checks whether that marker already exists.
If yes, it exits as **SKIP_DUPLICATE** instead of producing another commit.

## Why this is useful for site updates

For a content or patch site workflow, this model gives you:

- no dependency on one specific PC
- a visible execution log inside GitHub Actions
- a clear trail in commits
- artifacts for evidence and troubleshooting

You trade away long-running memory, but for **batch shipping** that is usually the right trade.

## Where this model breaks down

A stateless runner is the wrong tool when you need:

- a persistent loop
- local GUI tools that must stay open
- long multi-stage jobs with human interaction in the middle
- complex runtime memory that cannot be reconstructed from repo state

That kind of work still belongs to a local runtime or a different cloud architecture.

## Recommended operating mode

For early-stage site operations, keep it simple:

1. upload one batch to inbox  
2. run one workflow  
3. verify one result  
4. move batch to done  
5. only then queue the next batch  

This reduces ambiguity and makes RCA much easier when something fails.

## Internal links

- [Batch workflow](/posts/2026-02-18-batch-workflow/)
- [Safe iteration loops: plan → apply → verify](/posts/2026-02-20-safe-iteration-loops-plan-apply-verify/)
- [Post-merge QA: the shortest checklist that catches 80% of issues](/posts/2026-02-19-post-merge-qa-the-shortest-checklist-that-catches-80-of-issues/)
- [Operations hub](/hubs/operations/)
- [Workflow hub](/hubs/workflow/)

## Bottom line

If the job is **batch-shaped**, GitHub Actions can act as a reliable cloud runner.

Not as a brain.
Not as a memory system.
But as a clean execution layer with visible proof.
