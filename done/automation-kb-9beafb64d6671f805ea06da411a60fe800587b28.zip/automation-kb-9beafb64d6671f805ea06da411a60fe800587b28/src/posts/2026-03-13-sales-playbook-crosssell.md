---
title: "Sales playbook: cross sell"
description: "Expanding deals with existing clients."
layout: "post"
tags: [sales, expansion]
---

## Workflow
1. analyze account usage
2. detect opportunity
3. propose add‑on
4. close expansion
