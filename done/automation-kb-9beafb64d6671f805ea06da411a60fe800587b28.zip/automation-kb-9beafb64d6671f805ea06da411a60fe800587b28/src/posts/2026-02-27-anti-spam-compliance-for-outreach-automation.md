---
title: "Anti-spam and compliance basics for outreach automation"
description: "Core rules that keep your outreach sustainable: consent, unsubscribe, frequency caps, and claims discipline."
date: 2026-02-27
primaryTag: automation-safety
tags: ["compliance", "anti-spam", "automation", "email", "risk"]
summary: "Core rules that keep your outreach sustainable: consent, unsubscribe, frequency caps, and claims discipline."
---
# Anti-spam and compliance basics for outreach automation

This is not legal advice. It's an operational checklist to reduce obvious risk.

## Minimum rules
- clear identity
- clear opt-out
- frequency caps
- no deceptive claims
- respect "no"

## Why this matters
Deliverability and reputation are fragile. One bad week can break your channel.

## Related
- Hub: [/hubs/automation-safety/](/hubs/automation-safety/)
