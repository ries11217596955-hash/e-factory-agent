---
title: "Automation pattern: event monitoring"
description: "Detecting operational events and triggering workflows."
layout: "post"
tags: [automation, monitoring]
---

## Workflow

1. monitor data sources
2. detect trigger events
3. start workflow
4. log outcome
