---
title: "Sales playbook: deal review"
description: "Reviewing active deals."
layout: "post"
tags: [sales, pipeline]
---

## Workflow
1. review pipeline
2. identify blockers
3. plan next actions
4. update CRM
