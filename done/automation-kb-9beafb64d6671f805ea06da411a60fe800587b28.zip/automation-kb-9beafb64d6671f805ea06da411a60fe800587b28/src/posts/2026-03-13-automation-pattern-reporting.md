---
title: "Automation pattern: reporting pipeline"
description: "Automating report generation."
layout: "post"
tags: [automation, analytics]
---

## Workflow

1. collect metrics
2. aggregate data
3. generate report
4. distribute report
