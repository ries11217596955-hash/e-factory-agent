---
title: 2026-02-26-ai-prospect-research-workflow
description: "A repeatable workflow to research a prospect in minutes using public info, while avoiding hallucinated facts and keeping notes reusable."
date: 2026-02-26
tags: [ai-for-sales, workflow, lead-generation]
primaryTag: workflow
summary: "Short: AI prospect research workflow"
---

## AI prospect research workflow (fast + safe)

This workflow turns a raw lead (company + role) into **usable sales notes**: what they do, what changed recently, what pain is likely, and what to say first.

### Inputs
- Company name + website
- Target persona (e.g., "Head of Ops", "Founder")
- Your offer category (e.g., "automation for ops")

### Output (copy-paste block)
- **What they sell:** …
- **Signals (last 90 days):** …
- **Likely pain:** …
- **Hypothesis:** If <signal> then <pain> → propose <next step>
- **One-line opener:** …
- **Question to confirm:** …

### Steps (10-15 minutes)
1) **Grounding pass (2 min):** open website → products, pricing, "about", "careers".
2) **Signal pass (3-5 min):** search press/news + changelog + job posts. Capture *only* verifiable facts.
3) **Pain mapping (2-3 min):** map signals → operational constraints (support load, inventory, attribution, etc.).
4) **Offer fit (2-3 min):** select ONE workflow you can improve (don't pitch a platform).
5) **Message draft (2 min):** one-line opener + one question.

### Safety rules (to prevent fake facts)
- If a claim can't be verified quickly → mark as **ASSUMPTION** in your notes.
- Prefer "I noticed X" (verifiable) over "You must be…" (speculative).
- No numbers unless sourced (traffic, revenue, headcount).

### Template: first message (short)
> Hi <Name> - noticed <verifiable signal>.  
> Curious: how are you handling <pain area> today?  
> If useful, I can share a 1‑page workflow for <outcome>.

### Next: connect to the rest of the cluster
- Build your ICP scorecard → then qualify leads consistently.
- Add enrichment rules → then automate follow‑ups safely.
