---
title: "Sales playbook: customer onboarding"
description: "Hand‑off from sales to onboarding."
layout: "post"
tags: [sales, onboarding]
---

## Workflow
1. confirm deal
2. introduce onboarding team
3. schedule kickoff
4. transfer context
