---
title: "Automation pattern: task trigger"
description: "Triggering tasks automatically based on events."
layout: "post"
tags: [automation, productivity]
---

## Workflow

1. detect event
2. create task
3. assign owner
4. track completion
