---
title: "AI objection detection workflow"
description: "Detecting objections from sales conversations."
layout: "post"
tags:
- ai-for-sales
- workflow
---

## Workflow
1. collect call notes
2. detect objection signals
3. classify objection
4. suggest response pattern
