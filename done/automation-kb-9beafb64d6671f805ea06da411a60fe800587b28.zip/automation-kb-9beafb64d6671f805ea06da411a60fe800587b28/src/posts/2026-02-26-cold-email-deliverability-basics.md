---
title: 2026-02-26-cold-email-deliverability-basics
description: "Practical deliverability basics so your outreach lands: volume, warming, copy rules, and stop conditions."
date: 2026-02-26
tags: [ai-for-sales, workflow, outreach]
primaryTag: workflow
summary: "Short: Cold email deliverability basics"
---

## Cold email deliverability basics (for small operators)

If deliverability is broken, better copy won't help.

### The minimum setup (conceptual)
- Use a dedicated sending identity (don't risk your main inbox).
- Start low volume, ramp slowly.
- Keep messages short; avoid heavy links and attachments.

### Copy rules that reduce spam signals
- One clear question.
- No hype words ("guarantee", "free", "urgent").
- Avoid large blocks, emojis, and multiple links.

### Volume rule
If you can't handle replies, you're sending too much.
Keep the system human‑scale.

### Stop conditions
- Bounce spike
- Spam complaints
- Reply quality collapses

### Automation rule
Automate drafts, not blasting.
Connect this with: Follow‑up automation framework.
