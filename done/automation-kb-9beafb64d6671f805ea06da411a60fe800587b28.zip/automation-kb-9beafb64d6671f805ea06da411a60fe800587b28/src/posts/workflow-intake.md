---
title: workflow-intake
description: ""
date: 2026-02-24
tags: []
primaryTag: workflow
summary: "Short: workflow-intake"
---


This article explains a practical intake pipeline for new workflows in **automation-kb**.





## Why intake matters


- prevents tag/route drift


- keeps lists and sorting consistent


- makes changes reviewable in batches





## Intake checklist (short)


1. Create a draft markdown page with `tags: ["posts", ...]`


2. Add `summary` (preferred for lists)


3. If you edit later, set `updated:` (entryDate uses updated||date)


4. Verify the page renders in the article layout





## Output


A publish-ready post that shows up on Home, /posts/, and the relevant hub/tag pages.





