---
title: 2026-02-18-batch-3-min-content
description: ""
date: 2026-02-18
tags: []
primaryTag: workflow
summary: "Short: 2026-02-18-batch-3-min-content"
---


## Goal
Verify the "content loop" works end-to-end:
- posts render correctly,
- appear in lists and RSS feeds,
- are reachable from a hub.

## What this batch adds
- Two posts (this one + smoke checks).
- Links from the Operations hub to those posts.

## Success criteria
- Both URLs open without 404.
- They show up in the Posts list page (if enabled) and in `/feeds/posts.xml`.



