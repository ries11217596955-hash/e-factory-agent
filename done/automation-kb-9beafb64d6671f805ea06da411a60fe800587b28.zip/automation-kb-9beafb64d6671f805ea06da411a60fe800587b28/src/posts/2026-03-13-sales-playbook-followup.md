---
title: "Sales playbook: follow up strategy"
description: "Systematic follow up after outreach."
layout: "post"
tags: [sales, follow-up]
---

## Workflow
1. detect no response
2. schedule follow up
3. send reminder
4. update CRM
