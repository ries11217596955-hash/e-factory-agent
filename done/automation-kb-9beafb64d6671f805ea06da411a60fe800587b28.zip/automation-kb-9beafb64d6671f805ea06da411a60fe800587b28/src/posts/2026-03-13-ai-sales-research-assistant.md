---
title: "AI sales research assistant"
description: "Automating prospect research."
layout: "post"
tags: [ai-for-sales, research]
---

## Workflow
1. collect prospect url
2. analyze company
3. summarize positioning
4. produce research brief
