---
title: "AI lead routing automation"
description: "Using AI to route inbound leads to the right sales queue."
layout: "post"
tags:
- ai-for-sales
- workflow
- routing
---

## Problem
Inbound leads often sit unassigned.

## Workflow
1. capture lead source
2. analyze company profile
3. detect territory or segment
4. assign queue automatically
