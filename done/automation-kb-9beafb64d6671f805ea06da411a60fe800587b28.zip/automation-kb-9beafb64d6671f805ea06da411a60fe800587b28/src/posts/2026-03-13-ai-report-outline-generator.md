---
title: "AI report outline generator"
description: "Generating report structures."
layout: "post"
tags: [automation, documents]
---

## Workflow
1. collect topic
2. generate outline
3. refine sections
4. write report
