---
title: "AI support ticket summary"
description: "Summarizing customer support tickets."
layout: "post"
tags: [support, automation]
---

## Workflow
1. capture ticket
2. summarize issue
3. detect urgency
4. route ticket
