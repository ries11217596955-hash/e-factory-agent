---
title: "AI knowledge gap detection"
description: "Detecting missing documentation topics."
layout: "post"
tags:
- automation
- knowledge
---

## Workflow
1. analyze search queries
2. detect unanswered questions
3. generate topic list
4. prioritize documentation
