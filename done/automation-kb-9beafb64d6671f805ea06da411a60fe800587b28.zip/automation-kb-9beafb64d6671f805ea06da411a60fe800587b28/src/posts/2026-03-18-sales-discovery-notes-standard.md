---
title: "Sales discovery notes standard"
description: "A lightweight note standard for discovery calls that makes follow-up, qualification, and handoff easier."
layout: "post"
date: 2026-03-18
tags:
  - ai-for-sales
  - documentation
  - workflow
summary: "A small standard for discovery notes that turns messy call notes into usable sales data."
---

## Goal

Discovery notes should be reusable by the same rep, by a manager, and by the next person in the process.

## Minimum sections

- company and contact
- pain or trigger
- current process
- urgency or timeline
- next step
- blockers or unknowns

## Common failure

Teams write long narrative notes but miss the two fields that matter most: next step and timing.

## AI support

AI can convert raw call notes into a standard structure, highlight missing fields, and propose a concise summary for CRM entry.
