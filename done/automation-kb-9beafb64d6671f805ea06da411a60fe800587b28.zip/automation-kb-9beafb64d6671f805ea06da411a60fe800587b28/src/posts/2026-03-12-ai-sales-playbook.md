---
title: "AI sales playbook"
description: "A practical end‑to‑end playbook for using AI across prospecting, outreach, qualification, follow‑up, and CRM hygiene."
layout: "post"
tags:
  - "ai-for-sales"
  - "sales-system"
  - "playbook"
---

## Why a playbook matters

Most teams experiment with AI in isolated tasks.

A playbook connects tasks into a repeatable flow.

Typical fragmentation:

- research done in one tool
- outreach drafted somewhere else
- CRM updated inconsistently
- follow‑ups forgotten

A playbook solves coordination.

## Core pipeline

The minimum AI‑assisted pipeline:

1. lead discovery
2. prospect research
3. qualification
4. outreach
5. follow‑up
6. CRM hygiene

Each stage has a clear output.

## Lead discovery

Goal: find companies matching ICP.

Common signals:

- hiring patterns
- product launches
- funding events
- tech stack changes

AI helps summarise signals quickly.

## Prospect research

Focus only on:

- company context
- role relevance
- probable pain point
- reachable channel

See also:

- /posts/2026-03-12-minimum-viable-prospect-research/

## Qualification

Use a small scoring model:

- ICP fit
- pain relevance
- contact quality
- urgency signals

Routing decisions:

- pursue
- nurture
- skip

## Outreach

Angle before personalization.

Reference:

- /posts/2026-03-12-outreach-angle-before-personalization/

## Follow‑up

Most deals die here.

Reference:

- /posts/2026-03-12-follow-up-without-being-annoying/

## CRM hygiene

Capture only operational facts:

- last action
- next action
- stage
- note

This keeps the system usable.

## Related

- /posts/2026-03-12-build-ai-sales-system-from-zero/
- /hubs/ai-for-sales/
