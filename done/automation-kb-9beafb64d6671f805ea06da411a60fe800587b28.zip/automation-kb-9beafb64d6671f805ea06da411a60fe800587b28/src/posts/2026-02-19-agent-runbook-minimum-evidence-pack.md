---
title: 2026-02-19-agent-runbook-minimum-evidence-pack
description: ""
date: 2026-02-19
tags: []
primaryTag: workflow
summary: "Short: 2026-02-19-agent-runbook-minimum-evidence-pack"
---


# Agent runbook: minimum evidence pack for every run





## Always record


1) Inputs (spec path + hash)


2) Planned operations


3) Outputs (file list)


4) Integrity (SHA256)


5) Post-merge smoke checks





This keeps automation honest.





