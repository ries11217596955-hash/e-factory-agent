---
title: "Automation pattern: alerting systems"
description: "Triggering alerts when conditions change."
layout: "post"
tags: [automation, monitoring]
---

## Workflow

1. monitor metric
2. detect threshold breach
3. trigger alert
4. record event
