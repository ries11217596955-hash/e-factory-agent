---
title: "AI customer feedback clustering"
description: "Grouping feedback messages to detect patterns."
layout: "post"
tags:
- automation
- workflow
---

## Workflow
1. collect feedback
2. normalize text
3. cluster themes
4. summarize insights
