---
title: 2026-02-20-tagging-strategy-hubs-one-slug-one-tag
description: ""
date: 2026-02-20
tags: []
primaryTag: workflow
summary: "Short: 2026-02-20-tagging-strategy-hubs-one-slug-one-tag"
---


# Tagging strategy





Rule: **hub slug = tag**.





Example:


- hub: `automation-safety`


- posts: `tags: ["automation-safety"]`





This makes filtering deterministic.





