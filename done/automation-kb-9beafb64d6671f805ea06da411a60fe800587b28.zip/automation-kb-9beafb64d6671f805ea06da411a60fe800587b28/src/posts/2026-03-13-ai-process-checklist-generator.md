---
title: "AI process checklist generator"
description: "Generating operational checklists."
layout: "post"
tags: [operations, automation]
---

## Workflow
1. collect workflow description
2. generate checklist
3. validate steps
4. distribute checklist
