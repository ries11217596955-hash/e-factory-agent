---
title: "Automation pattern: lead qualification"
description: "Using automated rules to qualify leads."
layout: "post"
tags: [automation, sales]
---

## Workflow

1. capture lead data
2. detect company attributes
3. score qualification
4. route to sales
