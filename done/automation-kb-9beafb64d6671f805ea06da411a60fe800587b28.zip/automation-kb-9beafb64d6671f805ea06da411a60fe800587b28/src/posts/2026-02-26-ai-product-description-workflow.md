---
title: "AI product description workflow"
description: "Compatibility route for older links to the product description workflow topic."
layout: "page"
permalink: "/posts/2026-02-26-ai-product-description-workflow/"
eleventyExcludeFromCollections: true
---

## AI product description workflow

This compatibility page keeps older links alive.

### Use these active pages
- [AI product description generator comparison](/posts/ai-product-description-generator-comparison/)
- [Amazon listing quality QA](/posts/2026-02-18-amazon-listing-quality-qa/)
- [Amazon title + bullets optimizer workflow](/posts/2026-02-27-amazon-title-bullets-optimizer/)
