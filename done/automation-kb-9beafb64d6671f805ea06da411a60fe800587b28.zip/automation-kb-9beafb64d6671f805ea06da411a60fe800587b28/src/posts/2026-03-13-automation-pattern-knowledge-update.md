---
title: "Automation pattern: knowledge base update"
description: "Updating knowledge base articles automatically."
layout: "post"
tags: [automation, knowledge]
---

## Workflow

1. detect documentation gap
2. collect information
3. generate draft
4. publish update
