---
title: 2026-02-20-safe-iteration-loops-plan-apply-verify
description: ""
date: 2026-02-20
tags: []
primaryTag: workflow
summary: "Short: 2026-02-20-safe-iteration-loops-plan-apply-verify"
---


# Safe iteration loop





1) PLAN (dry-run)


2) APPLY (one atomic commit)


3) VERIFY (smoke)





If any step fails: stop, diagnose, then rerun.





