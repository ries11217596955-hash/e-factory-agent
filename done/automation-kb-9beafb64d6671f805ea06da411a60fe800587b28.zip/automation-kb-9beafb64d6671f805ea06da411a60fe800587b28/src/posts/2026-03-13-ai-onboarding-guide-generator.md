---
title: "AI onboarding guide generator"
description: "Generating onboarding instructions."
layout: "post"
tags: [automation, documentation]
---

## Workflow
1. collect notes
2. generate guide
3. review clarity
4. publish
