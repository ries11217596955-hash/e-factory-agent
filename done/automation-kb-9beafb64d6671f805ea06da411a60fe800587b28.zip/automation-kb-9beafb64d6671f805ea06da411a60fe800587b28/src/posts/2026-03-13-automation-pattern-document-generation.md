---
title: "Automation pattern: document generation"
description: "Automatically generating documents from structured data."
layout: "post"
tags: [automation, documents]
---

## Workflow

1. capture structured inputs
2. apply document template
3. generate output file
4. deliver document
