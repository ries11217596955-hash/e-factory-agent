---
title: eleventy-frontmatter-hygiene
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: eleventy-frontmatter-hygiene"
---


## Common failure patterns


- YAML colon errors (unquoted values like `title: A: B`)


- Mixed template syntaxes (e.g., Liquid filters inside Nunjucks)


- Invalid dates or inconsistent date fields


- Tags as a string instead of an array





## Safe patterns


### Quote risky strings


Use quotes when a value contains `:` or leading `{`/`[` characters.





### Tags are arrays


```yaml


tags: ["tools","deployment","cloudflare"]


```





### Keep a consistent date contract


- `date`: publish date


- `updated`: last meaningful update





## Quick verification


1. Build locally (or in CI) and confirm no frontmatter parse errors.


2. Ensure the page appears in the expected collection (posts/news/tools).


3. Confirm tags render and link to `/tags/<tag>/`.





## Notes


If a page silently disappears, check:


- `eleventyExcludeFromCollections`


- `permalink: false`


- frontmatter parsing failures (they can short-circuit file processing)





