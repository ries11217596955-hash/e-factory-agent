---
title: tag-drift-triage
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: tag-drift-triage"
---


## Symptom


- /tags/ contains near-duplicates (plural/singular, spelling variants, casing).


- Topic clouds look noisy.


- New content keeps introducing new tag variants.





## Triage checklist


1. **Export top offenders**  


   Open `/tags/` and note:


   - duplicates (`workflow`/`workflows`)


   - casing (`AI`/`ai`)


   - near-synonyms (`automation`/`automations`)


2. **Choose canon**  


   Decide one canonical tag per concept.


3. **Alias the rest**  


   Map variants → canonical via TagMap.


4. **Stop the bleed**  


   For new content:


   - use only canonical tags


   - avoid one-off tags unless they will recur





## Fast verify


- `/tags/` count drops (expected)


- A page that previously linked to an alias now links to canonical tag URLs


- No new tag pages appear for mapped aliases





## Notes


- Do not "fix" drift by deleting content tags first - add aliasing guardrails, then clean gradually if needed.





