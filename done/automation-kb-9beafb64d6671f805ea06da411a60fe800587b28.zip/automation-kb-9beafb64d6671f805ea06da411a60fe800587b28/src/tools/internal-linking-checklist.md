---
title: internal-linking-checklist
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: internal-linking-checklist"
---


## Target


Per new post: add **3-7** internal links that increase discoverability and time-on-site.





## Checklist


1. **Link to the hub**


   - Add 1 link to the most relevant hub page.


2. **Link to 1-2 related posts**


   - Prefer adjacent depth: same topic, different angle.


3. **Link to 1 tool**


   - A checklist, template, or troubleshooting page that supports execution.


4. **Link to 1 "getting started" entry (optional)**


   - Only when the post introduces a new concept for beginners.


5. **Avoid over-linking**


   - If you exceed 7, keep only the most actionable ones.





## Anchor text rules


- Describe the destination (no "click here")


- Keep anchors short (2-6 words)





## Notes


Internal linking is a system: hubs + tags + "related posts" work together.





