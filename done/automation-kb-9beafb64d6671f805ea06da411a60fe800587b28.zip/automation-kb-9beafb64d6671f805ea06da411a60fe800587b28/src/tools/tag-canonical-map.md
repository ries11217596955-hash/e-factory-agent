---
title: tag-canonical-map
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: tag-canonical-map"
---


Use this when tag names start multiplying (plural/singular variants, hyphen vs space, casing).





## What it does


- Defines **canonical tags** and **aliases** in one place (TagMap data file).


- Forces consistent tag URLs and a consistent /tags/ index.





## When to update TagMap


- A new topic becomes a repeat theme (≥3 posts/tools).


- You detect duplicates like `agent` vs `agents`, `workflow` vs `workflows`.


- You want to rename a tag without breaking navigation.





## Minimal procedure


1. Pick the canonical tag (short, lowercase, singular unless a category is truly plural).


2. Add aliases that should collapse into the canonical tag.


3. Rebuild and verify:


   - `/tags/` shows only canonical tags


   - old aliases do not create new tag pages (or they canonicalize/redirect depending on policy)





## Naming rules


- lowercase


- hyphenated (no spaces)


- avoid synonyms unless you intentionally map them





## Notes


- Keep TagMap small and opinionated - it is a quality gate, not a dictionary.





