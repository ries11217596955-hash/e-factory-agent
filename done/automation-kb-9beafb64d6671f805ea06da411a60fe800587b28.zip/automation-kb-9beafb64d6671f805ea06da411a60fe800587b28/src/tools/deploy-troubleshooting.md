---
title: deploy-troubleshooting
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: deploy-troubleshooting"
---


## Symptoms → checks


1) **Build stamp did not change**


- Wrong branch or no commit


- Pages project not connected to repo/branch





2) **Build stamp changed but page looks old**


- Browser cache / edge cache


- Purge by URL for the affected path





3) **Build failed**


- Check build logs


- Fix template syntax errors first (line + column evidence)





## Must-have verification pages


- `/status/`


- `/inventory/`





