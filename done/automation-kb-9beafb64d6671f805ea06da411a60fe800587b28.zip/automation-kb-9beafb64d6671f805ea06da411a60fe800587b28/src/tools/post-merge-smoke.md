---
title: post-merge-smoke
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: post-merge-smoke"
---


Run this after every merge/deploy.





## Smoke checklist


1. **Home loads**


   - `/` renders and key nav links work.


2. **Posts pagination**


   - `/posts/` page 1 loads and the "next" link works.


3. **Tags**


   - `/tags/` loads


   - at least 2 tag pages load (pick high-traffic tags)


4. **Robots + canonical**


   - `robots.txt` reachable


   - a random post page contains a canonical URL


5. **404**


   - `/this-should-not-exist/` returns a 404 page (not a blank response)





## Notes


If any item fails, treat it as a release blocker for the current batch and revert/fix before adding new content.





