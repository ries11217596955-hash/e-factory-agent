---
title: second-tool
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: second-tool"
---


If you think Cloudflare is still serving an old build, open **/status/** and check:





- Batch id


- Chain mode flag


- Generated timestamp


- Links to latest content lists





If the batch shown is not your last uploaded ZIP, the deploy did not use your latest commit.





