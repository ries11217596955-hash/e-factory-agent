module.exports = {
  layout: "layouts/post.njk",
  tags: ["tools"]
};
