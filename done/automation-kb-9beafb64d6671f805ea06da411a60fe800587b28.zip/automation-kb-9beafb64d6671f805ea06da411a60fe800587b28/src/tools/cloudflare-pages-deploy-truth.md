---
title: cloudflare-pages-deploy-truth
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: cloudflare-pages-deploy-truth"
---


## Goal


Avoid the classic confusion: *"I pushed changes but the site looks unchanged."*





## Truth table (common cases)


### Case A - You rebuilt the same commit


- Action used: **Retry build**


- Result: rebuilds the **same** commit hash


- Fix: trigger a deployment that uses the **latest commit** on the production branch (Pages UI "New deployment" or automatic deploy from main)





### Case B - New commit exists but wasn't deployed


- Repo shows new commits, Pages still serves older build


- Fix: start a new deployment for the latest commit





### Case C - Build succeeded but content path is wrong


- Build logs OK, but pages are empty/old


- Fix: confirm build output directory matches the generator output (e.g., Eleventy `_site`)





## Verification points


- Open `/status/` (or your build status page if present)


- Confirm:


  - last build timestamp


  - batch id (if you track batches)


  - the commit/ref used by Pages





## Notes


- Treat "what's live" as **observable truth**; logs are hints, not proof.





