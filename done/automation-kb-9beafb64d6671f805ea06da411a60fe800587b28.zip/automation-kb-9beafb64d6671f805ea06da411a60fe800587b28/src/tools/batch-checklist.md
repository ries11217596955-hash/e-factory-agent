---
title: batch-checklist
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: batch-checklist"
---


## Before you upload


- ZIP is clean (no `_site/`, `node_modules/`, `.git/`, logs).


- Build stamp is bumped (`build.batch`).


- No template-level re-sorting (`| reverse` avoided).





## After deploy


- Open `/status/` → confirm Build shows the new batch.


- Open `/search/` → confirm the page loads.


- Open `/inventory/` → confirm counts increased.





## If "no change"


- GitHub: verify files actually committed.


- Cloudflare: retry deployment / clear build cache.


- Browser: hard refresh or cache purge by URL.





