---
title: first-tool
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: first-tool"
---


Use this checklist before executing any automation job.





1. **Inputs present**: order JSON exists and is readable.


2. **Paths discovered**: no assumed drive letters; repo/workdir detected.


3. **Deliver dir**: deliver_dir exists or is created; write permissions verified.


4. **Non-interactive**: no prompts (Read-Host / pauses) - fail-fast if required.


5. **Evidence**: write REPORT.txt/REPORT.json into deliver_dir with status and counts.





