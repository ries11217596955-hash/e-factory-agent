---
title: intake-checklist
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: intake-checklist"
---


## Purpose


Use this checklist to intake new work without breaking contracts.





## Checklist


- Scope: what pages/collections will change?


- Contracts: tags, entryDate, sorting


- Hygiene: ZIP clean (no _site/node_modules/.git)


- Evidence: batch id + SHA256 + key files touched





