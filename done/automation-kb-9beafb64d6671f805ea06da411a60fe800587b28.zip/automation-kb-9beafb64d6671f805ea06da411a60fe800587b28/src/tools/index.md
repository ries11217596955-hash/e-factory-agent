---
title: "Tools"
description: "Checklists, templates, deploy helpers, and reference assets grouped by action."
layout: "page"
---

## Use tools by action

### Build and deploy
- [Deploy verify](/tools/deploy-verify/)
- [Deploy troubleshooting](/tools/deploy-troubleshooting/)
- [Cloudflare Pages deploy truth](/tools/cloudflare-pages-deploy-truth/)
- [Post-merge smoke](/tools/post-merge-smoke/)

### Content and linking
- [Hub curation checklist](/tools/hub-curation-checklist/)
- [Internal linking checklist](/tools/internal-linking-checklist/)
- [Tag canonical map](/tools/tag-canonical-map/)
- [Tag drift triage](/tools/tag-drift-triage/)

### Content creation
- [Content template - post](/tools/content-template-post/)
- [Content template - news](/tools/content-template-news/)
- [Content template - tool](/tools/content-template-tool/)
- [Eleventy frontmatter hygiene](/tools/eleventy-frontmatter-hygiene/)

## When to use this section

Use Tools when you need:
- a checklist you can apply immediately
- a reusable template
- a deploy or QA helper
- a repeatable operational asset

If you are still choosing a topic, go to [Hubs](/hubs/) first.
If you want a mixed reading archive, go to [Posts](/posts/).
