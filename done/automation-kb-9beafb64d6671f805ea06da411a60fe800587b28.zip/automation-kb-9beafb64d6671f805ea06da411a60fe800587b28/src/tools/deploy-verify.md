---
title: deploy-verify
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: deploy-verify"
---


## Verify


1. Open `/status/` and confirm the batch id.


2. Check the top bar build badge.


3. If mismatch: retry deployment; clear build cache if needed.





