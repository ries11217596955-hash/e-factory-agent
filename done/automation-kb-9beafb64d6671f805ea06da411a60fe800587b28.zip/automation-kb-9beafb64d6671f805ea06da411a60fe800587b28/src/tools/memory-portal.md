---
title: "Memory Portal"
layout: layouts/page.njk
summary: "Search and browse the project's WebOps memory (Strategy, Control Loop, MistakeBank, Guards, Decisions)."
---

This page is a **project memory console**. It searches the repo memory files that are enforced by build guards.

<div class="search-box">
  <label for="mq"><strong>Search memory</strong></label><br/>
  <input id="mq" type="search" placeholder="Type: guard-memory-diff, Eleventy filter, control loop..." style="width:100%;max-width:720px;padding:10px;font-size:16px;">
  <div style="margin-top:8px;font-size:14px;opacity:.8">
    Loaded from <code>/memory.json</code>. Links open the source file on GitHub.
  </div>
</div>

<div style="margin-top:16px">
  Results: <span id="mcount">0</span>
</div>

<div id="mresults" style="margin-top:12px"></div>

<script src="/assets/memory-portal.js/" defer></script>
