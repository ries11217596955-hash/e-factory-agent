---
title: content-template-tool
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: content-template-tool"
---


# Tool template

Copy this file into `/tools/<name>.md` and edit fields.

```yaml
---
layout: base
title: "Tool: <short name>"
summary: "<one-line why this tool exists>"
updated: 2026-02-23
primaryTag: operations
tags: ["tools","<facet1>","<facet2>"]
---


