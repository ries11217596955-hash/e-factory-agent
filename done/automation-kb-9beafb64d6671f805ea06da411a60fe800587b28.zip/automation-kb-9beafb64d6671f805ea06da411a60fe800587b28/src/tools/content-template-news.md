---
title: content-template-news
description: ""
date: 2026-02-24
tags: []
primaryTag: operations
summary: "Short: content-template-news"
---


```yaml


---


layout: article.njk


title: "..."


summary: "..."


description: "..."


tags: ["news", "release"]


date: 2026-02-14


updated: 2026-02-14


---


```





