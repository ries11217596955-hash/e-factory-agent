---
title: "Start Here"
description: "How to use the site: pick a hub, find the right posts, then reuse tools and templates."
layout: "page"
permalink: "/start-here/"
eleventyExcludeFromCollections: true
---

## What this site is for

This knowledge base is built for practical work:
- AI-assisted sales workflows
- marketplace and ecommerce operations
- workflow design and automation patterns
- release, QA, and operations discipline

The best route is **not** to start with the full post archive.
Start with a hub, then move into the right posts and tools.

## Best first routes

### If you want business outcomes
- [AI for Sales](/hubs/ai-for-sales/)
- [AI for Amazon](/hubs/amazon-ai/)
- [AI for Shopify](/hubs/shopify-ai/)

### If you want systems and execution
- [Workflow](/hubs/workflow/)
- [Operations](/hubs/operations/)
- [Integrations](/hubs/integrations/)

## How to use the site

1. Pick the hub that matches your goal.
2. Read the most relevant post or short guide.
3. Reuse a checklist, template, or reference asset from [Tools](/tools/).
4. Use [Search](/search/) if you already know the topic or term.

## What each section means

### Hubs
The main entry points. Use them first.

### Tools
Checklists, templates, deploy helpers, and repeatable assets.

### Posts
The mixed archive of practical guides and articles.

### Updates
Shorter update-style entries and news-like notes.

### Search
Fast access when you already know what you are looking for.

## Recommended next step

- [Browse all hubs](/hubs/)
- [Open tools](/tools/)
- [Search the site](/search/)
