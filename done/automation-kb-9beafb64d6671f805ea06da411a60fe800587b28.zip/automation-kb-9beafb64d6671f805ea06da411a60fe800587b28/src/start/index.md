---
title: Start here
description: "A fast route into the site: choose your goal, then open the best hub, posts, and tools."
layout: page
---

## Start with the business outcome

Do not start with random posts. Start with the result you want.

### 1) I want more leads and meetings
Open:
- [AI for Sales](/hubs/ai-for-sales/)
- [Posts: AI for Sales stream](/posts/)
- [Qualification basics](/hubs/ai-for-sales/qualification/)
- [Follow-up systems](/hubs/ai-for-sales/follow-up/)

### 2) I want cleaner ecommerce operations
Open:
- [AI for Amazon](/hubs/amazon-ai/)
- [AI for Shopify](/hubs/shopify-ai/)
- [Inventory sync](/hubs/shopify-ai/inventory-sync/)
- [Amazon listing optimization](/hubs/amazon-ai/listing-optimization/)

### 3) I want repeatable automation
Open:
- [Automation Workflows](/hubs/workflow/)
- [Operations](/hubs/operations/)
- [Tools](/tools/)

## Fast routes

### Money path
- [AI for Sales](/hubs/ai-for-sales/)
- [Lead generation](/hubs/ai-for-sales/lead-generation/)
- [Outreach](/hubs/ai-for-sales/outreach/)
- [Qualification](/hubs/ai-for-sales/qualification/)
- [Follow-up](/hubs/ai-for-sales/follow-up/)

### Marketplace path
- [AI for Amazon](/hubs/amazon-ai/)
- [Amazon review monitoring](/hubs/amazon-ai/review-monitoring/)
- [AI for Shopify](/hubs/shopify-ai/)
- [Shopify order automation](/hubs/shopify-ai/order-automation/)

### Build path
- [Automation Workflows](/hubs/workflow/)
- [Operations](/hubs/operations/)
- [Updates](/news/)

## What this page is for

This page exists to stop random browsing.  
Pick the closest goal, then go deeper from that cluster.
