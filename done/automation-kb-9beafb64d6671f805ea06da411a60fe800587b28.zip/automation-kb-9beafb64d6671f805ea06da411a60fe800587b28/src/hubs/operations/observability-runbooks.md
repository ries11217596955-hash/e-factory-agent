---
title: observability-runbooks
description: ""
date: 2026-02-24
tags: []
---

{% include "partials/page_head.njk" %}

<section class="section-gap">
  <div class="prose">
    <h2>What you will get</h2>
    <ul>
      <li>What to log (and what not to)</li>
      <li>Alert design that avoids false positives</li>
      <li>Runbooks that speed up recovery</li>
    </ul>

    <h2>Quick path</h2>
    <ol>
      <li>Skim the system map and identify your constraint.</li>
      <li>Pick one workflow and implement it end-to-end.</li>
      <li>Instrument results (time saved, error rate, retries).</li>
    </ol>

    <h2>Related</h2>
    <ul>
      <li><a href="/hubs/operations/">Systems hub</a></li>
      <li><a href="/news/">Updates</a></li>
      <li><a href="/tools/">Tools</a></li>
    </ul>
  </div>
</section>

