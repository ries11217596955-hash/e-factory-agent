---
title: "Agents and workflows"
description: "Compatibility route for older agent/workflow links."
layout: "page"
permalink: "/hubs/agents-workflows/"
eleventyExcludeFromCollections: true
---

## Agents and workflows

This compatibility page maps older links to the active workflow hub.

- [Open workflow hub](/hubs/workflow/)
- [Agent architecture](/hubs/workflow/agent-architecture/)
- [Agent failover patterns](/hubs/workflow/agent-failover-patterns/)
