---
title: "Systems hub"
description: "Compatibility route for older systems links."
layout: "page"
permalink: "/hubs/systems/"
eleventyExcludeFromCollections: true
---

## Systems

This compatibility page maps older systems links to the operations and workflow hubs.

- [Operations hub](/hubs/operations/)
- [Workflow hub](/hubs/workflow/)
