---
title: workflow-orchestration
description: ""
date: 2026-02-24
tags: []
---

# Workflow orchestration

When a "prompt" becomes a workflow, the goal is simple: the same input should produce the same outcome (or the same class of outcomes), with evidence.

## Core building blocks

- **Intake**: normalize inputs (schema, required fields, defaults).
- **Plan**: produce a minimal plan with constraints and stop conditions.
- **Execute**: run steps with clear tool boundaries.
- **Verify**: check outputs against acceptance criteria.
- **Report**: write a short, parseable summary (what changed, what passed/failed, links).

## Reliability patterns

- **Idempotency**: safe re-run without duplicating side effects.
- **Retries with backoff**: only for known transient failures.
- **Evidence-first logs**: record inputs, outputs, and key checkpoints.
- **Rollback strategy**: define what "undo" means for each action.
- **Stop conditions**: when verification fails → stop and escalate.

## Minimal checklist

- [ ] Inputs validated (schema)
- [ ] Output directory deterministic
- [ ] Logs stored outside build artifacts
- [ ] Verification step exists and is strict
- [ ] Known-failures are classified (not "random")


