---
title: "News hub"
description: "Compatibility route for older hub-style news links."
layout: "page"
permalink: "/hubs/news/"
eleventyExcludeFromCollections: true
---

## Updates

Use the main updates page here: [Open Updates](/news/).
