---
title: "AI workflows hub"
description: "Compatibility route for older AI workflows links."
layout: "page"
permalink: "/hubs/ai-workflows/"
eleventyExcludeFromCollections: true
---

## AI workflows

This compatibility page maps older workflow links to the active workflow hub.

- [Open workflow hub](/hubs/workflow/)
- [Workflow QA routine](/posts/2026-02-18-workflow-qa-routine/)
- [Safe iteration loops](/posts/2026-02-20-safe-iteration-loops-plan-apply-verify/)
