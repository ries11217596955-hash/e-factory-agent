---
title: Qualification
description: Scorecards, routing rules, and minimum useful data to decide who to pursue.
layout: page
permalink: /hubs/ai-for-sales/qualification/
---

## What matters here

Qualification stops you from wasting time on weak leads.  
The goal is not perfect scoring. The goal is a **good enough decision**:
- pursue
- nurture
- skip

## Start with these guides

- [ICP scorecard qualification](/posts/2026-02-26-icp-scorecard-qualification/)
- [Lead enrichment: minimum fields](/posts/2026-02-26-lead-enrichment-minimum-fields/)
- [AI lead scoring system for B2B services](/posts/2026-02-26-ai-lead-scoring-system-for-b2b-services/)
- [AI lead scoring for B2B services](/posts/2026-02-27-ai-lead-scoring-for-b2b-services/)
- [Simple CRM pipeline stages](/posts/2026-02-26-simple-crm-pipeline-stages/)

## Minimum decision package

- ICP fit
- problem relevance
- reachable contact path
- next best action

## Related next steps

- [Outreach](/hubs/ai-for-sales/outreach/)
- [Follow-up](/hubs/ai-for-sales/follow-up/)
