---
title: Lead generation
description: Build a reliable stream of prospects using AI-assisted research and repeatable filters.
layout: page
permalink: /hubs/ai-for-sales/lead-generation/
---

## What matters here

Lead generation is not just "more leads."  
It is the ability to produce **usable prospects** that match your ICP and can enter a real workflow.

## Start with these guides

- [AI lead generation systems](/posts/2026-02-26-ai-lead-generation-systems/)
- [Best AI tools for lead generation](/posts/2026-02-25-best-ai-tools-lead-generation/)
- [Free AI tools for lead generation](/posts/2026-02-25-free-ai-tools-lead-generation/)
- [AI tools to find clients automatically](/posts/2026-02-25-ai-tools-to-find-clients-automatically/)
- [AI prospect research workflow](/posts/2026-02-26-ai-prospect-research-workflow/)

## Use this sequence

1. define ICP
2. gather minimum useful facts
3. score for relevance
4. send to qualification or discard

## Related next steps

- [Qualification](/hubs/ai-for-sales/qualification/)
- [Outreach](/hubs/ai-for-sales/outreach/)
