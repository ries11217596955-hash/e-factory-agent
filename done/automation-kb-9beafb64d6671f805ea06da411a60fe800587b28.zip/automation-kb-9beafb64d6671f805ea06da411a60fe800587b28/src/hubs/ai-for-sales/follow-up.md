---
title: Follow-up
description: Sequences, meeting-booking discipline, and CRM hygiene after first contact.
layout: page
permalink: /hubs/ai-for-sales/follow-up/
---

## What matters here

Most sales leakage happens after first contact.  
Follow-up is where pipeline discipline either exists or disappears.

## Start with these guides

- [Follow-up automation framework](/posts/2026-02-26-follow-up-automation-framework/)
- [Follow-up sequence automation framework](/posts/2026-02-27-follow-up-sequence-automation-framework/)
- [Meeting booking checklist](/posts/2026-02-26-meeting-booking-checklist/)
- [CRM enrichment automation playbook](/posts/2026-02-27-crm-enrichment-automation-playbook/)
- [Weekly sales metrics that matter](/posts/2026-02-26-weekly-sales-metrics-that-matter/)
- [Sales outreach metrics that matter](/posts/2026-02-27-sales-outreach-metrics-that-matter/)

## Use this sequence

1. first contact
2. reply/no reply split
3. scheduled follow-up window
4. CRM update
5. meeting-booking or close-lost decision

## Related next steps

- [Outreach](/hubs/ai-for-sales/outreach/)
- [Qualification](/hubs/ai-for-sales/qualification/)
