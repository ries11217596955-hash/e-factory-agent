---
title: "Automation safety"
description: "Compatibility route for safety, QA, and operational guard topics."
layout: "page"
permalink: "/hubs/automation-safety/"
eleventyExcludeFromCollections: true
---

## Automation safety

Use the operations hub for safety guards, QA checks, and release discipline.

- [Open operations hub](/hubs/operations/)
- [Smoke checks after deploy](/posts/2026-02-18-smoke-checks-after-deploy/)
- [Capability locks](/posts/2026-02-20-capability-locks-stop-unsupported-ops-early/)
