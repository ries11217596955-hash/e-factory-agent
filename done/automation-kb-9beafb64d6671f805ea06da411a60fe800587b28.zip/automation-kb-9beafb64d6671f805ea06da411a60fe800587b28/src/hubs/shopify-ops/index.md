---
title: "Shopify ops"
description: "Compatibility route for older Shopify operations links."
layout: "page"
permalink: "/hubs/shopify-ops/"
eleventyExcludeFromCollections: true
---

## Shopify operations

This compatibility page keeps older links alive.

Go to the main page: [AI for Shopify](/hubs/shopify-ai/).
