---
title: "About"
description: "What this site is for and how to navigate it."
layout: "page"
permalink: "/about/"
eleventyExcludeFromCollections: true
---

<div class="pagehead">

# About

<p class="lede">An engineering-first knowledge base for ecommerce automation: problem → when to use → solution options → steps → pitfalls → checklist.</p>

</div>

<section class="card card--soft">

## Purpose

<ul class="card__list">
  <li>capture reusable patterns for ecommerce automation</li>
  <li>keep decisions traceable (why we picked this approach)</li>
  <li>make execution repeatable (runbooks + checklists)</li>
</ul>

<hr class="hr" />

## Structure

<ul class="card__list">
  <li><b>Hubs</b>: topic entry points (navigation by area)</li>
  <li><b>Posts</b>: chronological articles and working notes</li>
  <li><b>Tools</b>: runnable assets and reusable snippets</li>
</ul>

<hr class="hr" />

## Publishing rules (lightweight)

<ul class="card__list">
  <li>short, practical paragraphs</li>
  <li>no marketing language</li>
  <li>examples and checklists preferred</li>
  <li>post updates when a workflow changes</li>
</ul>

</section>

