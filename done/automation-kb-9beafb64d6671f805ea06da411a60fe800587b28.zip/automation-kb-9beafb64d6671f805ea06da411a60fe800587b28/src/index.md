---
title: "Automation Knowledge Base"
description: "Practical guides, tools, and topic hubs for AI-assisted sales, ecommerce, workflow design, and operations."
layout: "base.njk"
---

{% include "partials/hero_home.njk" %}

<section class="section-gap">
  <div class="grid grid--3">
    <section class="card card--soft">
      <h2 class="h2">Choose a path</h2>
      <ul>
        <li><a href="/start-here/">Start Here</a></li>
        <li><a href="/hubs/">Browse all hubs</a></li>
        <li><a href="/tools/">Open tools</a></li>
        <li><a href="/search/">Search the site</a></li>
      </ul>
      <p class="card__meta">Use hubs first. Posts are the archive layer.</p>
    </section>

    <section class="card">
      <h2 class="h2">Business paths</h2>
      <ul>
        <li><a href="/hubs/ai-for-sales/">AI for Sales</a></li>
        <li><a href="/hubs/amazon-ai/">AI for Amazon</a></li>
        <li><a href="/hubs/shopify-ai/">AI for Shopify</a></li>
      </ul>
      <p class="card__meta">Start from the outcome you want, not from a mixed content stream.</p>
    </section>

    <section class="card">
      <h2 class="h2">Build and operate</h2>
      <ul>
        <li><a href="/hubs/workflow/">Workflow</a></li>
        <li><a href="/hubs/operations/">Operations</a></li>
        <li><a href="/hubs/integrations/">Integrations</a></li>
      </ul>
      <p class="card__meta">Use these when you are designing systems, deployment routines, or integration patterns.</p>
    </section>
  </div>
</section>

<section class="section-gap">
  <section class="card card--soft">
    <h2 class="h2">Topic hubs</h2>
    <p class="card__text">Hubs are the main entry points. Each hub groups posts, tools, and practical routes under one topic.</p>
    {% include "partials/hub_grid.njk" %}
  </section>
</section>

{% include "partials/hub_latest_lists.njk" %}

<section class="section-gap">
  <div class="grid grid--3">
    <section class="card">
      <h2 class="h2">Need a guided entry?</h2>
      <p class="card__text">Use the onboarding page if you are new to the site or want a fast explanation of the structure.</p>
      <p><a href="/start-here/">Open Start Here →</a></p>
    </section>

    <section class="card">
      <h2 class="h2">Need a tool?</h2>
      <p class="card__text">Go to the tools catalog for checklists, templates, deploy helpers, and repeatable assets.</p>
      <p><a href="/tools/">Open Tools →</a></p>
    </section>

    <section class="card">
      <h2 class="h2">Need the full archive?</h2>
      <p class="card__text">Posts remain available as the mixed archive view, but they are no longer the recommended first step.</p>
      <p><a href="/posts/">Open Posts →</a></p>
    </section>
  </div>
</section>
