/**
 * Global layout default (safe):
 * - If a template already defines `layout`, keep it.
 * - If output is HTML, use layouts/page.njk.
 * - Otherwise (robots.txt, xml, json, etc.), disable layout.
 */
module.exports = {
  eleventyComputed: {
    layout: (data) => {
      if (data && data.layout) return data.layout;

      const out = (data && data.page && data.page.outputPath) ? String(data.page.outputPath).toLowerCase() : "";
      if (!out) return "layouts/page.njk";

      if (out.endsWith(".html")) return "layouts/page.njk";
      return null;
    }
  }
};
