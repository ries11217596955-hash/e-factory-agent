---
title: index
description: ""
date: 2026-02-24
tags: []
---

<div class="pagehead">

# Support

<p class="lede">Where to report issues, request improvements, and confirm what changed after a batch.</p>

</div>

<section class="card card--soft">

## Best ways to get help

<ul class="card__list">
  <li><strong>Content issues</strong>: typos, unclear steps, missing examples → open a ticket with the page URL and a short "expected vs actual".</li>
  <li><strong>Site bugs</strong>: broken links, 404, broken feeds/search → report with the URL and a screenshot if possible.</li>
  <li><strong>Requests</strong>: propose a new hub/post topic with 1-3 bullets: problem → desired outcome → constraints.</li>
</ul>

</section>

<section class="card">

## What to include in a report (minimum)

<ul class="card__list">
  <li>URL (the exact page)</li>
  <li>What you expected to see</li>
  <li>What happened instead</li>
  <li>Browser/device (optional but helpful)</li>
</ul>

</section>

<section class="card">

## After a new batch: quick verification

<ul class="card__list">
  <li>Confirm Cloudflare Pages deployment shows <strong>Success</strong>.</li>
  <li>Open the changed page(s) and hard refresh once (cache can lie).</li>
  <li>Check CSS loads (if the UI looks unstyled, it's often an asset path/cache issue).</li>
</ul>

</section>

