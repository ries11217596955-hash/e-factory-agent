# MistakeBank (Project Memory)

**Purpose:** prevent повторение ошибок (симптом→фикс→предотвращение).
**Rule:** любой инцидент/поломка закрывается только после записи (или обновления) карточки.

---

## Card format
- **Id:** MB-XXXX
- **Symptom:** что видим (кратко)
- **Root cause (Корневая причина):** почему произошло
- **Fix:** что сделали (конкретно)
- **Prevention / Guard:** что проверять/запретить, чтобы не повторилось
- **Evidence:** ссылка/лог/скрин/коммит

---

## MB-0001 — Eleventy build fails: missing filter / undefined identifier
- **Symptom:** Cloudflare Pages build падает; ошибка Nunjucks filter not found или ReferenceError/undefined identifier в `.eleventy.js`.
- **Root cause (Корневая причина):**
  - фильтр используется в `.njk`/`.md`, но не зарегистрирован в `.eleventy.js`; и/или
  - в `.eleventy.js` обращение к `config.*` без объявленного алиаса (должно быть `eleventyConfig.*` или `const config = eleventyConfig`).
- **Fix:**
  - зарегистрировать filter в `.eleventy.js` (addFilter);
  - убрать/починить undefined identifiers; выровнять имя переменной конфигурации.
- **Prevention / Guard:**
  - `check-config` обязателен перед build/serve (fail-fast);
  - запрет `{% set %}` и логики в `*.md`;
  - сверка реестра фильтров: usage vs addFilter.
- **Evidence:** Cloudflare build log + commit hash/дата.
