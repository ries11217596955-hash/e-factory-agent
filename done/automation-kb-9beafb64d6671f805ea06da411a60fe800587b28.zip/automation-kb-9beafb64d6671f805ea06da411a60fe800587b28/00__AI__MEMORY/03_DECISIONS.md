# Decision Log

Фиксируем решения уровня системы, чтобы не было дрейфа “почему так”.

---

## D-0001 — Repo is Memory SSOT
**Decision:** проектная память (MistakeBank/Guards/Decisions) живёт в репозитории: `00__AI__MEMORY/`.  
**Why:** чат не гарантирует долговременную память; репо даёт историю, откаты и единый источник правды.  
**Scope:** automation-kb (site + webops).  
**Side effects:** любые инциденты закрываются обновлением MistakeBank/Guards.

---

## D-0002 — Close incident only with prevention
**Decision:** инцидент считается закрытым только если добавлен “Prevention / Guard” (или подтверждено что уже есть).  
**Why:** иначе ошибка повторится.  
**Scope:** WebOps/Eleventy + любые будущие подсистемы.
