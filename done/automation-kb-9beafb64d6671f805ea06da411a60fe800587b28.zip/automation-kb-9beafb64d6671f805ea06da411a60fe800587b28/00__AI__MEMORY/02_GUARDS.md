# Guards (Preflight before changes)

**Purpose:** быстрые проверки перед любым коммитом, чтобы не ловить повторные поломки.

---

## G-0001 — ELEVENTY.CONFIG.NO_UNDEFINED_IDENTIFIERS (P0)
**Check:** в `.eleventy.js` нет обращений к `config.` без объявленного алиаса.  
**Expected:** используется `eleventyConfig.*` или есть `const config = eleventyConfig`.

## G-0002 — ELEVENTY.MD.NO_NUNJUCKS_SET (P0)
**Check:** в `src/**/*.md` нет `{% set %}` и другой логики Nunjucks.  
**Expected:** в `.md` — максимум include/минимальные безопасные конструкции (или вообще без них).

## G-0003 — ELEVENTY.FILTER.REGISTRY.REQUIRED (P0)
**Check:** любой `| filterName` в `.njk` должен иметь регистрацию `addFilter('filterName', ...)` в `.eleventy.js`.

## G-0004 — ELEVENTY.PREFLIGHT.CHECK_CONFIG_BEFORE_BUILD (P0)
**Check:** npm scripts `build/serve` запускают `check-config` перед Eleventy render.  
**Expected:** build падает “раньше”, чем начнёт рендерить страницы.

## G-0005 — WEBOPS.UNIFIED_DIFF.COMMIT (P0)
**Check:** связанные правки (конфиг + шаблоны + ассеты) уходят одним атомарным коммитом, без промежуточных состояний.
