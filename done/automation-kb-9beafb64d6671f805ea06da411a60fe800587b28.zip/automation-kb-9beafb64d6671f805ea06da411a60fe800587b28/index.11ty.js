/**
 * Search index generator (JS template) — avoids Nunjucks compilation edge-cases on CI.
 * Outputs: /search/index.json
 */
module.exports = class {
  data() {
    return {
      permalink: "/search/index.json",
      eleventyExcludeFromCollections: true
    };
  }

  render(data) {
    const safeStr = (v) => (v === null || v === undefined) ? "" : String(v);
    const safeArr = (v) => Array.isArray(v) ? v : (v ? [v] : []);
    const entryDate = (item) => {
      const d = (item && item.data && (item.data.entryDate || item.data.date || item.data.updated)) || (item && (item.entryDate || item.date));
      const dt = d ? new Date(d) : null;
      if(!dt || String(dt) === "Invalid Date") return null;
      return dt;
    };
    const iso = (dt) => dt ? dt.toISOString() : "";
    const readable = (dt) => {
      if(!dt) return "";
      const yyyy = dt.getFullYear();
      const mm = String(dt.getMonth()+1).padStart(2,"0");
      const dd = String(dt.getDate()).padStart(2,"0");
      return `${yyyy}-${mm}-${dd}`;
    };

    const items = [];
    const pushFrom = (collection, typeName) => {
      const arr = data.collections && data.collections[collection] ? data.collections[collection] : [];
      for (const item of arr) {
        const dt = entryDate(item);
        items.push({
          type: typeName,
          title: safeStr(item && item.data && item.data.title),
          url: safeStr(item && item.url),
          date: iso(dt),
          dateReadable: readable(dt),
          summary: safeStr(item && item.data && item.data.summary),
          description: safeStr(item && item.data && item.data.description),
          tags: safeArr(item && item.data && item.data.tags).join(" ")
        });
      }
    };

    pushFrom("posts", "Post");
    pushFrom("news", "News");
    pushFrom("tools", "Tool");

    return JSON.stringify(items, null, 2);
  }
};
