# STRATEGY_LOCK.md — SSOT (single source of truth)
# Last update: 2026-02-27 (Bakı)

LOCK_HEADER (print this at every session start / after any SP transfer)
GOAL=Build Traffic Engine
VECTOR=AI Tools + Practical Application
FOCUS=AI for Sales
STRATEGY=SEO-first + Distribution
DONE_LAST=see STATE
NEXT=see NEXT
DRIFT=NO unless explicitly flagged

GOAL (6–12 months)
- Build Traffic Engine (authority + organic growth)
- Monetization is downstream of traffic + trust (not the primary daily target)

VECTOR
- AI Tools + Practical Application

FOCUS (single focus, P0)
- AI for Sales (lead generation, prospecting/outreach, conversion/follow-up)
- Audience: service-based small business / agencies / consultants

POSITIONING (must match site labels)
- Site should read as: "AI for Sales" (not “ecommerce automation KB” as a primary label)
- Any eCommerce wording is secondary context only and must map to Sales outcomes

CONTENT STRATEGY
- SEO-first (cluster model)
- Distribution (amplification): repurpose + share in relevant channels (lightweight)

CONTENT SYSTEM (SEO CLUSTERS)
Primary cluster (C1):
- Lead Generation (core)

Support clusters (C2–C3):
- Prospecting / Outreach (support)
- Conversion / Follow-up (support)

Allowed secondary context (C0, conditional)
- eCommerce / Shopify / Amazon / CRM / Outreach tooling
CONDITION:
- ONLY when the article’s primary outcome is Sales (lead gen / outreach / conversion).
- If it reads like “ecommerce automation as a topic” → DRIFT=YES (STOP).

MONETIZATION MODEL (phased)
Phase 1 (0–3 months):
- Traffic + email capture + affiliate alignment
Phase 2 (3–6 months):
- Affiliate revenue + sponsorship tests + mini digital products
Phase 3 (6–12 months):
- Owned product/system + premium assets

KPI (phase-based, truth-only)
0–90 days:
- 1000+ monthly visitors
- 50+ email subscribers
- 10+ daily organic visits

FORBIDDEN (hard lock, P0)
- No pivot away from AI for Sales while KPI trend is positive
- No returning to templates as primary focus
- No parallel vectors
- No “ecommerce automation” cluster as a standalone theme (unless explicitly reframed into Sales outcome)
- No content batches that break build / taxonomy contracts

DRIFT RULE (P0)
- If a proposal does not serve GOAL under current VECTOR/FOCUS → DRIFT=YES and STOP.
- Otherwise DRIFT=NO.

BATCH GATES (P0)
Before shipping any batch to repo:
1) FRONTMATTER CONTRACT:
   - Every post must have: title, description/summary, date, primaryTag, tags (as required by check-config).
2) TEMPLATE SAFETY:
   - No unescaped Nunjucks braces that can break rendering (use raw blocks when needed).
3) NAV/IA ALIGNMENT:
   - Navigation labels must reflect AI for Sales focus (avoid “ecommerce automation KB” mismatch).
4) INTERNAL LINKING:
   - Every support post must link to its pillar + at least 1 sibling in same cluster.

MEMLOCK PROTOCOL (P0)
- In every session start / after any SP transfer, print LOCK_HEADER.
- Any new cluster proposal must explicitly state: "MappedToSalesOutcome=YES" or it is DRIFT.

STATE (facts only)
DONE_LAST:
- Site build stabilized (green builds after recent content/templating fixes)
- Lead Gen / SalesOps content batches started (Cluster-1 seed posts exist)
- Recurrent failure class identified and handled: missing primaryTag, YAML quoting, Nunjucks braces, missing layouts

NEXT (near-term, sequence)
1) Unify site positioning: labels + nav + hub naming must reflect AI for Sales (primary)
2) Expand Cluster-1 (Lead Gen) with pillar → support linking discipline (internal links as mandatory)
3) Add 1 “conversion asset” landing page for email capture (minimal) + link from relevant posts
4) Only then: allow controlled C0 context posts (eCommerce/Shopify/Amazon) if they serve Sales outcome

OWNER / ASSISTANT ROLES
- Owner: copy/paste + upload outputs (no manual edits by default)
- Assistant: owns technical consequences of issued steps until proven otherwise
