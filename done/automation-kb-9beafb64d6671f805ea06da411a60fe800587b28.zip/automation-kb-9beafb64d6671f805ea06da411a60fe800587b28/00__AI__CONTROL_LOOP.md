2026-03-04 (Baku)
Removed experimental memory.json.njk (Eleventy filter merge error). Restoring stable build.
## 2026-03-04 11:46 (Bakı)


## 2026-03-04 12:05 (Bakı)
- Added Memory Portal + Search: /tools/memory-portal/ (client search over /memory.json).
- load-memory now writes src/_data/repoMemory.json for site build.

- Added Repo Memory Loader: scripts/loadRepoMemory.js (exports scripts/repoMemory.json).
- Added npm script: load-memory.

## 2026-03-04

- Hardened memory guard
- Added guardMemoryDiff.js
- Enabled enforcement: site changes require CONTROL_LOOP update
# 00__AI__CONTROL_LOOP.md

LAST_UPDATE: 2026-03-03 10:52 UTC
STATUS: ACTIVE

---

## 1. STRATEGIC VECTOR

Primary Project: automation-kb

Positioning:
AI for Sales & E-commerce Automation

Monetization Model:
Traffic → Ads + Affiliate

Horizon:
3 months to first measurable traction

Execution Mode:
Hybrid (Depth + Controlled Scale)
Batch-Oriented Execution (Large-scale changes preferred)

---

## 2. CURRENT STATE

Site Status:
- Cloudflare build/deploy: STABLE (passing)
- Content contract: ENFORCED (front-matter + tag allowlist)
- Focus: Sales + E-commerce revenue automation
- Stage: Traffic engine activation (internal linking + structure)

Agent Status:
- In development
- Not production-ready
- Future role: automation support

---

## 3. BATCH HISTORY (MACRO)

### MACRO-BATCH-01_REVENUE_ENGINE_FOUNDATION
- Added CONTROL_LOOP strategic anchor
- Updated homepage positioning
- Added 5 foundational revenue posts (anchors)
Result: Build/Deploy OK

### MACRO-BATCH-02_REVENUE_CLUSTER_EXPANSION (+ hotfixes)
- Added 10 long-tail posts (Sales + E-commerce)
- Fixed content contract fields + tag allowlist
- Restored CONTROL_LOOP history after accidental overwrite
Result: Build/Deploy OK

### MACRO-BATCH-03_LAYOUT_SYSTEM
- Added missing Eleventy layout: src/_includes/post.njk
Result: Build/Deploy OK

### MACRO-BATCH-04_DEEP_REVENUE_UPGRADE
- Upgraded 10 posts from drafts → deep structured guides
Result: Build/Deploy OK

### MACRO-BATCH-05_TRAFFIC_ENGINE_ACTIVATION
- Added table-of-contents blocks
- Added internal linking blocks (cluster reinforcement)
Result: Build/Deploy OK

---

## 4. NEXT MOVE

MACRO-BATCH-06: NAV + DISCOVERY
- Add /posts/ index page (listing)
- Add tag pages /tags/ai-for-sales/ and /tags/ecommerce-automation/
- Add “Related posts” automation (if supported) or stable manual blocks

---

## 5. DRIFT CHECK

Aligned with AI for Sales & E-commerce Automation:
YES

If new content does not support revenue automation → reject.

---

## 6. BATCH RULE

All strategic/structural changes must be executed as macro-batches.
No chaotic edits.
No micro-iterations.

---

## 7. CHRONO LOG

### 2026-03-03 09:18 (Bakı)
- Control Loop update triggered in DOCS chat (start_док). Baseline artifacts present in chat (multiple ZIP toolkits + Control Loop file).
- DOCS lane: awaiting explicit Baseline selection per cycle protocol; no audit/patch executed in this update.
- AGENT lane (PCMODE=ADMIN): still P0-open — prove end-to-end INBOX→submit(prompt_id)→history JSON images→PNG copied→DONE.ok + ComfyUI liveness (8188 LISTEN + HTTP 200).
- SITE lane: vector unchanged (AI for Sales + E-commerce Automation); next move remains MACRO-BATCH-06 (Nav + Discovery).


### 2026-03-03 09:19 (Bakı)
- CONTROL_LOOP synchronized via explicit owner trigger (“обновляем конрлуп?”).
- No structural change to Strategic Vector (AI for Sales + E-commerce Automation remains primary).
- SITE lane: Build stable; preparing for MACRO-BATCH-06 (Navigation + Discovery systemization).
- AGENT lane: P0 still open — full pipeline proof (INBOX→submit→history images→PNG→DONE.ok) and ComfyUI liveness evidence required before production flag.
- DOCS lane: No active release cycle; waiting for explicit MODE declaration if entering start_док.
- Execution posture unchanged: Macro-batch only, no micro edits.

### 2026-03-03 22:39 (Bakı)
- AGENTOPS (PCMODE=ADMIN): Bridge successfully executed with named parameters (Vault alias via junction: H:\VAULT\_INBOX).
- Worker run completed: OK; RUN_REPORT created at H:\STOCKOPS_ADOBE\_logs\autopilot\RUN_REPORT_20260302_223903.txt.
- ComfyUI liveness verified in-session: 8188 LISTEN + HTTP 200 on /.
- Current state: pipeline is **partially proven** (bridge→run→RUN_REPORT).
- P0 still OPEN: capture full E2E proof with artifact evidence (prompt_id → /history JSON contains images → PNG produced → delivered to VAULT _OUTBOX + DONE.ok/_DONE).
- Next step (single): run one real order and record prompt_id + history JSON path + produced PNG path + DONE marker in VAULT.


---

## 2026-03-03 (Bakı) — Site lane update (automation-kb)

### What changed / current state
- Site is building and deploying on Cloudflare Pages (recent deploys show Success).
- Navigation & utility pages are live: `/support/`, `/inventory/`, `/tags/`, `/search/`, `/tools/`, `/news/`, `/hubs/`.
- Noted issue observed: `/posts/` previously returned 404; workstream is to ensure a stable route + predictable listing behavior.
- Current blocker observed in Cloudflare build logs: `checkConfig.js` fails with `ReferenceError: config is not defined` (script runs before Eleventy build).

### Decision / focus
- Keep pushing forward with functional site first (stability + routes + listings), then scale content.
- Fix the build blocker by hardening `scripts/checkConfig.js` to be deterministic and never fail on missing local variables.

### Next steps
- Apply the macro-batch that rewrites `scripts/checkConfig.js` (safe stub config + clearer error output).
- Re-run Cloudflare deploy and confirm build passes.
- If `/posts/` still 404 or listing is empty, continue with posts listing/index pass (without breaking canonical URLs).

---


### 2026-03-03 15:05 (Bakı)

SITE (automation-kb)
- Status: BUILD PASS restored (Cloudflare Pages).
- GuardPack outcome: added fail-fast checks to prevent повторный “tag \"set\" not found” + undefined identifiers in .eleventy.js + missing filter registrations.
- Live crawl (depth=1) findings:
  - P0: /posts/ feed is empty / not reflecting actual src/posts set (inventory shows many posts, but posts index shows no/near-empty listing). Fix: collections must be folder-driven, not tag-driven.
  - P1: /news/ listing duplicates items (same entries repeated in one list) — likely collection duplication; monitor after collection refactor.
  - P2: redirects warnings in CF logs about rules order (perf-only).

Next macro-batch direction:
- Close NAV + DISCOVERY: folder-driven collections + posts/news/tools listings + keep tags/pages stable.

## 7. TRIGGERS (OWNER COMMANDS)

These triggers are executed only when the owner explicitly calls them in chat.

### Trigger: “прочитай конрлуп”

Meaning:
Strategic + operational synchronization cycle.

What it does (in this order):
1) Read this CONTROL_LOOP and re-align with Strategic Vector + Next Move.
2) Update **CHRONO LOG** with current lane status (SITE/AGENT/DOCS as applicable) using Bakı time.
3) If any SITE work is planned next: run the SITE trigger “пройдись по ссылкам сайта” (default protocol) and record key findings (P0/P1/P2) into CHRONO LOG.
4) Produce the **next macro-batch direction** that explicitly accounts for the latest crawl findings (e.g., broken routes, tag pages, canonical drift).

Output contract:
- Assistant returns an updated CONTROL_LOOP file for repo replacement (no background commits).
- Assistant includes a short RUN_SUMMARY (what was checked, key blockers).

---

### Trigger: “пройдись по ссылкам сайта”

Meaning:
Live-site link & discovery audit for SSOT URL.

Default protocol (no parameters):
1) Root scan: homepage + all internal links 1st level + menu/footer.
2) Structural crawl (depth=1): /hubs/ /posts/ /news/ /tools/ /tags/ /inventory/ /search/
3) Checks: HTTP 200/404/redirect, URL-pattern validity, canonical consistency (no jumps to other Pages subdomain).
4) Listing integrity: /posts/ listing, tag pages, orphan posts, broken “View all posts”.
5) Revenue-structure alignment: AI for Sales + E-commerce Automation (no drift).
6) Classify findings: P0 (nav/SEO blocker), P1 (structural), P2 (cosmetic).

Not included by default (requires explicit request):
- Deep crawl (depth>=2)
- External links
- Lighthouse / SEO score / performance metrics
- ## 2026-03-12 — WEBOPS_PASS1_STRUCTURE_REALIGN

Updated site positioning and canonical hub routing.

Changes:
- README updated to AI-for-Sales positioning
- canonical hubs set in src/_data/hubs.js
- navigation cleaned to /hubs/
- hero_home updated
- redirects normalized
- legacy /hub route removed

Purpose:
align site structure with AI-for-Sales knowledge base model.
## 2026-03-12 (Bakı)
- WEBOPS_PASS2_HUB_CLEANUP applied.
- Removed duplicate hub trees that already had canonical equivalents:
  - src/hubs/agents-workflows/* -> canonical: src/hubs/workflow/*
  - src/hubs/ai-workflows/* -> canonical: src/hubs/workflow/*
  - src/hubs/systems/* -> canonical: src/hubs/operations/*
- Reordered redirect aliases in src/_redirects to reduce Cloudflare redirect warnings.
- Purpose: simplify canonical hub map, reduce duplicate hub maintenance, keep /hubs/workflow/ and /hubs/operations/ as the only active targets for those topics.

