// .eleventy.js — Cloudflare Pages + Eleventy v2 (input=src)
module.exports = function (eleventyConfig) {
  const config = eleventyConfig;

  // --- KB components (paired shortcodes) ---
  eleventyConfig.addPairedShortcode("callout", (content, type = "note", title = "") => {
    const t = String(type || "note").toLowerCase();
    const safeType = ["note", "tip", "warn", "danger"].includes(t) ? t : "note";
    const heading = title ? `<div class="callout-title">${title}</div>` : "";
    return `<aside class="callout ${safeType}">${heading}<div class="callout-body">${content}</div></aside>`;
  });

  eleventyConfig.addPairedShortcode("kbcard", (content, title = "") => {
    const heading = title ? `<div class="kb-card-title">${title}</div>` : "";
    return `<section class="kb-card">${heading}<div class="kb-card-body">${content}</div></section>`;
  });

  // --- Passthrough ---
  eleventyConfig.addPassthroughCopy({ "src/assets": "assets" });
  eleventyConfig.addPassthroughCopy({ "src/_redirects": "_redirects" });
  eleventyConfig.addPassthroughCopy({ "src/robots.txt": "robots.txt" });

  // --- Internal helpers ---
  const _stripTrailingSlash = (s) => String(s || "").replace(/\/+$/, "");
  const _ensureLeadingSlash = (p) => {
    const s = String(p || "");
    if (!s) return "/";
    return s.startsWith("/") ? s : `/${s}`;
  };

  const _getBaseUrl = () => {
    const cand =
      process.env.SITE_URL ||
      process.env.CF_PAGES_URL ||
      process.env.DEPLOY_URL ||
      process.env.URL ||
      "";
    return _stripTrailingSlash(cand);
  };

  const _slugify = (v) => {
    const s = String(v || "")
      .trim()
      .toLowerCase()
      .replace(/["']/g, "")
      .replace(/[^a-z0-9\u0400-\u04FF]+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "");
    return s || "tag";
  };

  const _toDate = (value) => {
    if (value instanceof Date) return value;
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? null : d;
  };

  const _stripHtml = (html) =>
    String(html || "")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ")
      .replace(/&amp;/gi, "&")
      .replace(/&lt;/gi, "<")
      .replace(/&gt;/gi, ">")
      .replace(/\s+/g, " ")
      .trim();

  // --- Tag canonicalization ---
  const _tagMap = (() => {
    try {
      return require("./src/_data/tagMap.json") || {};
    } catch (e) {
      return {};
    }
  })();

  const _canonTag = (raw) => {
    if (raw === null || raw === undefined) return "";
    let t = String(raw).trim().toLowerCase();
    if (!t) return "";
    if (t.startsWith("_")) return "";
    t = t.replace(/[_\s]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
    const aliases = (_tagMap && _tagMap.aliases) ? _tagMap.aliases : {};
    const mapped = aliases && Object.prototype.hasOwnProperty.call(aliases, t) ? String(aliases[t] || "") : "";
    const out = mapped ? String(mapped).trim().toLowerCase() : t;
    const blocked = new Set(
      [...(Array.isArray(_tagMap.blocked) ? _tagMap.blocked : []), "posts", "news", "tools", "all"].map((x) =>
        String(x).toLowerCase()
      )
    );
    if (blocked.has(out)) return "";
    return out;
  };

  const _canonTagList = (tags, base) => {
    const arr = Array.isArray(tags) ? tags : tags ? [tags] : [];
    const b = String(base || "").trim().toLowerCase();
    const seen = new Set();
    const out = [];
    for (const t of arr) {
      const c = _canonTag(t);
      if (!c) continue;
      if (b && c === b) continue;
      if (seen.has(c)) continue;
      seen.add(c);
      out.push(c);
    }
    return out;
  };

  const _contentBase = (tags) => {
    const arr = Array.isArray(tags) ? tags : tags ? [tags] : [];
    for (const t of arr) {
      const s = String(t || "").trim().toLowerCase();
      if (s === "posts" || s === "news" || s === "tools") return s;
    }
    return "posts";
  };

  const _entryDate = (item) => {
    if (!item) return null;
    const candidate =
      (item.data && (item.data.updated || item.data.date)) ||
      item.date ||
      item.page && item.page.date ||
      null;
    return _toDate(candidate);
  };

  const _byGlob = (collectionApi, pattern) => {
    const arr = collectionApi.getFilteredByGlob(pattern) || [];
    return arr.sort((a, b) => ((_entryDate(b) || 0) - (_entryDate(a) || 0)));
  };

  // --- Filters ---
  eleventyConfig.addFilter("startsWith", (s, prefix) => {
    if (s === null || s === undefined) return false;
    const a = String(s);
    const b = String(prefix);
    return a.slice(0, b.length) === b;
  });

  eleventyConfig.addFilter("whereEq", (arr, key, value) => {
    if (!Array.isArray(arr)) return [];
    return arr.filter((x) => x && x[key] === value);
  });

  eleventyConfig.addFilter("limit", (arr, n) => {
    if (!Array.isArray(arr)) return [];
    return arr.slice(0, Number(n || 0));
  });

  eleventyConfig.addFilter("take", (arr, n = 5) => {
    if (!Array.isArray(arr)) return [];
    return arr.slice(0, Number(n) || 0);
  });

  eleventyConfig.addFilter("postDate", (dateObj) => {
    const d = _toDate(dateObj);
    return d ? d.toISOString().split("T")[0] : "";
  });

  eleventyConfig.addFilter("dateIso", (dateObj) => {
    const d = _toDate(dateObj);
    return d ? d.toISOString() : "";
  });

  eleventyConfig.addFilter("dateRfc822", (dateObj) => {
    const d = _toDate(dateObj);
    return d ? d.toUTCString() : "";
  });

  eleventyConfig.addFilter("dateReadable", (dateObj) => {
    const d = _toDate(dateObj);
    return d
      ? d.toLocaleDateString("en-US", {
          year: "numeric",
          month: "short",
          day: "2-digit",
        })
      : "";
  });

  eleventyConfig.addFilter("absoluteUrl", (path) => {
    const base = _getBaseUrl();
    const p = _ensureLeadingSlash(path);
    return base ? `${base}${p}` : p;
  });

  eleventyConfig.addFilter("baseHomeUrl", (path) => {
    const p = _ensureLeadingSlash(path || "/");
    return p.endsWith("/") ? p : `${p}/`;
  });

  eleventyConfig.addFilter("contentBase", (tags) => _contentBase(tags));
  eleventyConfig.addFilter("entryDate", (item) => _entryDate(item));

  eleventyConfig.addFilter("stripHtml", (value) => _stripHtml(value));
  eleventyConfig.addFilter("plainText", (value) => _stripHtml(value));

  eleventyConfig.addFilter("snippet", (value, limit = 160) => {
    const text = _stripHtml(value);
    const max = Math.max(0, Number(limit) || 0);
    if (!max || text.length <= max) return text;
    return `${text.slice(0, Math.max(0, max - 1)).trim()}…`;
  });

  eleventyConfig.addFilter("readingTime", (value) => {
    const text = _stripHtml(value);
    const words = text ? text.split(/\s+/).filter(Boolean).length : 0;
    return Math.max(1, Math.ceil(words / 200));
  });

  eleventyConfig.addFilter("breadcrumbs", (url, lastTitle) => {
    const clean = _stripTrailingSlash(url || "/") || "/";
    const parts = clean.split("/").filter(Boolean);
    const crumbs = [{ url: "/", label: "Home" }];
    let acc = "";
    for (let i = 0; i < parts.length; i++) {
      acc += `/${parts[i]}`;
      const isLast = i === parts.length - 1;
      let label = parts[i].replace(/-/g, " ");
      label = label.charAt(0).toUpperCase() + label.slice(1);
      crumbs.push({
        url: `${acc}/`,
        label: isLast && lastTitle ? lastTitle : label,
      });
    }
    return crumbs;
  });

  eleventyConfig.addFilter("editOnGitHubUrl", (inputPath, site) => {
    const repoUrl =
      (site && site.repoUrl) ||
      process.env.REPO_URL ||
      "";
    const repoBranch =
      (site && site.repoBranch) ||
      process.env.REPO_BRANCH ||
      "main";

    if (!repoUrl || !inputPath) return "#";

    const cleanedRepo = repoUrl.replace(/\/+$/, "");
    const normalizedPath = String(inputPath).replace(/^\.?\//, "");
    return `${cleanedRepo}/edit/${repoBranch}/${normalizedPath}`;
  });

  eleventyConfig.addFilter("canonTag", _canonTag);
  eleventyConfig.addFilter("canonTagList", _canonTagList);

  eleventyConfig.addFilter("primaryTag", (tags, base) => {
    const arr = _canonTagList(tags, base);
    return arr.length ? arr[0] : "";
  });

  eleventyConfig.addFilter("tagUrl", (baseOrTag, maybeTag) => {
    const hasBase = maybeTag !== undefined && maybeTag !== null && String(maybeTag).trim() !== "";
    if (hasBase) {
      const base = _contentBase(baseOrTag);
      const tag = _slugify(maybeTag);
      return `/tags/${base}/${tag}/`;
    }
    return `/tags/${_slugify(baseOrTag)}/`;
  });

  eleventyConfig.addFilter("topTags", (items, limit = 15, minCount = 1, exclude = []) => {
    const arr = Array.isArray(items) ? items : [];
    const lim = Math.max(0, Number(limit) || 0) || 15;
    const min = Math.max(1, Number(minCount) || 1);
    const blocked = new Set((Array.isArray(exclude) ? exclude : []).map((x) => String(x || "").toLowerCase()));
    const counts = new Map();
    for (const it of arr) {
      const tags = _canonTagList(it && it.data ? it.data.tags : [], _contentBase(it && it.data ? it.data.tags : []));
      for (const tag of tags) {
        if (!tag || blocked.has(tag)) continue;
        counts.set(tag, (counts.get(tag) || 0) + 1);
      }
    }
    return [...counts.entries()]
      .filter(([, count]) => count >= min)
      .sort((a, b) => (b[1] - a[1]) || a[0].localeCompare(b[0]))
      .slice(0, lim)
      .map(([tag]) => tag);
  });

  eleventyConfig.addFilter("byTag", (items, tag) => {
    if (!Array.isArray(items)) return [];
    const wanted = _canonTag(tag);
    if (!wanted) return [];
    return items.filter((it) => {
      const tags = _canonTagList(it && it.data ? it.data.tags : []);
      return tags.includes(wanted);
    });
  });

  eleventyConfig.addFilter("adjacentInCollection", (items, url) => {
    const arr = Array.isArray(items) ? items : [];
    const u = String(url || "");
    const idx = arr.findIndex((it) => it && it.url === u);
    if (idx < 0) return { prev: null, next: null };
    const prev = idx > 0 ? arr[idx - 1] : null;
    const next = idx < arr.length - 1 ? arr[idx + 1] : null;
    return { prev, next };
  });

  eleventyConfig.addFilter("relatedItems", (items, currentUrl, tags, limit) => {
    const arr = Array.isArray(items) ? items : [];
    const u = String(currentUrl || "");
    const lim = Math.max(0, Number(limit || 0)) || 0;

    const tagList = Array.isArray(tags) ? tags : [];
    const base = tagList.find((t) => t && String(t)[0] !== "_") || "";
    const usable = tagList
      .map((t) => String(t || ""))
      .filter((t) => t && t !== base && t[0] !== "_");

    const scoreOf = (itTags) => {
      if (!Array.isArray(itTags)) return 0;
      let s = 0;
      for (const t of usable) if (itTags.includes(t)) s++;
      return s;
    };

    const pool = arr
      .filter((it) => it && it.url && it.url !== u)
      .map((it) => ({ it, score: scoreOf(it.data && it.data.tags) }))
      .filter((x) => x.score > 0)
      .sort((a, b) => (b.score - a.score) || ((_entryDate(b.it) || 0) - (_entryDate(a.it) || 0)))
      .map((x) => x.it);

    return lim ? pool.slice(0, lim) : pool;
  });

  eleventyConfig.addFilter("relatedByPrimaryTag", (items, primaryTag, currentUrl, limit = 5) => {
    const arr = Array.isArray(items) ? items : [];
    const wanted = _canonTag(primaryTag);
    const u = String(currentUrl || "");
    const lim = Math.max(0, Number(limit) || 0) || 5;
    if (!wanted) return [];
    return arr
      .filter((it) => it && it.url && it.url !== u)
      .filter((it) => {
        const tags = _canonTagList(it && it.data ? it.data.tags : []);
        const primary = tags.length ? tags[0] : "";
        return primary === wanted;
      })
      .sort((a, b) => ((_entryDate(b) || 0) - (_entryDate(a) || 0)))
      .slice(0, lim);
  });

  // --- Collections ---
  eleventyConfig.addCollection("posts", function (collectionApi) {
    return _byGlob(collectionApi, "./src/posts/**/*.md");
  });

  eleventyConfig.addCollection("news", function (collectionApi) {
    return _byGlob(collectionApi, "./src/news/**/*.md");
  });

  eleventyConfig.addCollection("tools", function (collectionApi) {
    return _byGlob(collectionApi, "./src/tools/**/*.md");
  });

  return {
    dir: {
      input: "src",
      output: "_site",
      includes: "_includes",
      data: "_data",
    },
    markdownTemplateEngine: "njk",
    htmlTemplateEngine: "njk",
    dataTemplateEngine: "njk",
  };
};
