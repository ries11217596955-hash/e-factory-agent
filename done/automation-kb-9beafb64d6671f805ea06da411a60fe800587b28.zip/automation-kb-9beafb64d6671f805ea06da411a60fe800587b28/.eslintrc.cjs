module.exports = {
  root: true,
  env: {
    node: true,
    es2022: true,
  },
  extends: [
    'eslint:recommended',
    // Integrate Prettier with ESLint.  This must come last to disable rules that conflict with Prettier.
    'plugin:prettier/recommended',
  ],
  parserOptions: {
    ecmaVersion: 2022,
    sourceType: 'module',
  },
  rules: {
    // Customize any rules here.  For example, require semi‑colons and single quotes.
    semi: ['error', 'always'],
    quotes: ['error', 'single'],
  },
};