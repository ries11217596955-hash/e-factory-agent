# DELETE LIST (root cleanup)

Safe to delete (already merged into /src):
- BATCH-TRAFFIC-04_SALESOPS_CLUSTER_10POSTS_5HUBPATCH (1)/

Note: deletion is recommended to keep repo clean and avoid confusion.
