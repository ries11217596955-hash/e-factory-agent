# Contributing to Automation KB

Thank you for your interest in contributing to the Automation KB project!  This project uses Eleventy for static
site generation, and a simple configuration check is provided to catch syntax errors in `.eleventy.js` before
running a build.  To help maintainers avoid mistakes, please follow these guidelines before submitting changes:

1. **Install dependencies** — Run `npm install` to install Eleventy and any optional development dependencies you
   may choose to use.  The repository does not include ESLint or Prettier by default to avoid build failures on
   the CI server, so if you want to lint or format code locally you must install those packages yourself (e.g.
   `npm install --save-dev eslint prettier eslint-config-prettier`).

2. **Check the configuration** — Run `npm run check-config` to verify that `.eleventy.js` parses correctly.  This
   script will print `Config OK` on success or report a detailed error message.  Fix any errors before continuing.

3. **Build the site** — Run `npm run build` to generate the static site in `_site`.  The build script will run
   `check-config` automatically and then invoke Eleventy.  If the configuration is invalid, the build will abort.

These steps help prevent accidental syntax errors and ensure a smooth build process.  Feel free to use ESLint and
Prettier locally for additional assurance, but remember that they are not required for building the site on the
server.