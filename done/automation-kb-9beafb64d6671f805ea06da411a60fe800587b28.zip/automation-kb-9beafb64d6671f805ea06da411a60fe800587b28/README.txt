MACRO-BATCH-23 (WEBOPS / automation-kb)

Goal: Pass check-config guard ELEVENTY.MD.NO_NUNJUCKS_SET (P0) by removing forbidden Nunjucks '{% set %}' tags from Markdown hub pages.

Changes (full replace):
- src/hubs/amazon-ai/review-monitoring.md
src/hubs/operations/data-pipelines.md
src/hubs/operations/observability-runbooks.md
src/hubs/shopify-ai/inventory-sync.md
src/hubs/shopify-ai/order-automation.md
src/hubs/systems/data-pipelines.md
src/hubs/systems/observability-runbooks.md

Why:
- Cloudflare build failed in check-config with "Found forbidden Nunjucks '{% set %}' in Markdown files" list.

Notes:
- This batch only removes the '{% set %}' tag blocks; it keeps existing includes.
- If any page relied on variables created by set, the template will render those fields empty; this is acceptable for stability and can be refined later with front matter/data.

Applied at: 2026-03-03 15:39 (Bakı)
