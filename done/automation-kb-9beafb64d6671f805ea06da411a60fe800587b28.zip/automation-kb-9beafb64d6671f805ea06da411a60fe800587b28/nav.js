module.exports = {
  main: [
    { label: "Start", href: "/start/" },
    { label: "Tools", href: "/tools/" },
    { label: "News", href: "/news/" },
    { label: "Hubs", href: "/hubs/" },
    { label: "Posts", href: "/posts/" },
    { label: "Tags", href: "/tags/" },
    { label: "Inventory", href: "/inventory/" },
    { label: "About", href: "/about/" }
  ]
};
