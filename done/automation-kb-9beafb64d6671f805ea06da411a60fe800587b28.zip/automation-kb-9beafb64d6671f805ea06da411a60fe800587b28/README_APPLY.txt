BATCH: WEBOPS_PASS2_HUB_CLEANUP

APPLY
1. Extract this archive into the repo root with replacement.
2. Delete every path listed in DELETE_LIST.txt.
3. Append _BATCH/CONTROL_LOOP_APPEND__WEBOPS_PASS2.md to 00__AI__CONTROL_LOOP.md.
4. Run VERIFY commands.

VERIFY
- git status
- git diff --stat
- git diff

PASS CRITERIA
- Duplicate hub trees are removed.
- src/_redirects is updated.
- 00__AI__CONTROL_LOOP.md contains the PASS-2 entry.
- Build passes without MEMORY_DIFF_GUARD failure.
