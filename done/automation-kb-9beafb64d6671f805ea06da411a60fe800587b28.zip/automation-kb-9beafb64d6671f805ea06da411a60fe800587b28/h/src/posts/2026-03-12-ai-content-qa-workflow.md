
---
title: "AI content QA workflow"
description: "A simple workflow for checking AI-generated content for clarity, accuracy, and duplication before publishing."
layout: "post"
tags:
  - "automation"
  - "workflow"
  - "content-qa"
---

## Why QA matters

AI content fails when teams publish first drafts.

## Workflow

1. generate draft
2. check factual consistency
3. remove duplication
4. tighten wording
5. approve or reject

## AI support

- compare versions
- spot repeated phrasing
- summarize change notes

## Related

- /tools/eleventy-frontmatter-hygiene/
- /hubs/operations/
