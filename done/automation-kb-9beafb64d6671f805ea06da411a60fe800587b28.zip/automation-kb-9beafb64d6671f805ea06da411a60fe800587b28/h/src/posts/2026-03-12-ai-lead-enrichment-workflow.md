
---
title: "AI lead enrichment workflow"
description: "Using AI to enrich leads with company context and role signals."
layout: "post"
tags:
- ai-for-sales
- workflow
- enrichment
---

## Lead enrichment

Leads are often missing useful context.

## Workflow

1. collect company name
2. summarize company activity
3. detect role relevance
4. add enrichment fields

## AI support

AI summarizes public information and reduces manual research.
