
---
title: "AI cold email generation"
description: "How AI assists with generating personalized cold outreach."
layout: "post"
tags:
- ai-for-sales
- outreach
---

## Cold email challenge

Generic emails get ignored.

## AI workflow

1. prospect data
2. value hypothesis
3. email draft
4. human review
