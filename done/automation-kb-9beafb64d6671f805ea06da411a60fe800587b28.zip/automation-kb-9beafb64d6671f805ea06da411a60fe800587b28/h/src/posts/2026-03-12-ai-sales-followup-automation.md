
---
title: "AI sales follow-up automation"
description: "Designing simple AI assisted follow-up flows after meetings or demos."
layout: "post"
tags:
- ai-for-sales
- automation
- follow-up
---

## Follow-up bottleneck

Most deals slow down after the first conversation.

## Workflow

1. capture meeting notes
2. summarize intent
3. generate follow-up variants
4. schedule reminder
5. track reply signals

## AI support

AI helps generate structured follow-ups and summarize meeting outcomes.
