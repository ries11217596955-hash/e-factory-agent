
---
title: "AI research notes automation"
description: "Using AI to transform scattered research notes into structured summaries."
layout: "post"
tags:
- automation
- research
- workflow
---

## Research notes problem

Notes quickly become messy and hard to reuse.

## Workflow

1. collect notes
2. detect themes
3. summarize points
4. organize sections

## AI support

AI restructures notes into readable formats.
