
---
title: "AI sales discovery workflow"
description: "A workflow for turning raw company signals into a usable discovery brief before first outreach."
layout: "post"
tags:
  - "ai-for-sales"
  - "prospecting"
  - "workflow"
---

## Discovery before outreach

Discovery is the bridge between raw prospect data and a message angle.

## Workflow

1. collect company context
2. extract likely priorities
3. identify role relevance
4. produce a short discovery brief

## AI support

- summarize company signals
- highlight probable pain points
- reduce research time

## Related

- /posts/2026-03-12-minimum-viable-prospect-research/
- /posts/2026-03-12-outreach-angle-before-personalization/
