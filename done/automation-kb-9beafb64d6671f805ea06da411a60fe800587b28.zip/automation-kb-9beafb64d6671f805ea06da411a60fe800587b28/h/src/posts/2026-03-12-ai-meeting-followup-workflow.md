
---
title: "AI meeting follow-up workflow"
description: "How to turn meeting notes into follow-up actions, CRM updates, and next steps without losing context."
layout: "post"
tags:
  - "ai-for-sales"
  - "follow-up"
  - "workflow"
---

## Meeting follow-up problem

After meetings, teams lose context fast.

## Workflow

1. collect notes or transcript
2. summarize decisions
3. extract next steps
4. draft follow-up
5. update CRM

## Where AI helps

- meeting summaries
- action extraction
- draft follow-up variants

## Related

- /posts/2026-03-12-ai-sales-meeting-summaries/
- /hubs/ai-for-sales/follow-up/
