
---
title: "AI product description generation workflow"
description: "A workflow for generating consistent ecommerce product descriptions."
layout: "post"
tags:
- ai-ecommerce
- workflow
- copywriting
---

## Product descriptions

Descriptions must balance clarity and SEO.

## Workflow

1. collect product specs
2. generate feature list
3. produce description draft
4. review for clarity

## AI support

AI generates consistent drafts based on product attributes.
