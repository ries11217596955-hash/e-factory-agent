
---
title: "AI sales prospect research workflow"
description: "Using AI to research prospects before outreach."
layout: "post"
tags:
- ai-for-sales
- prospecting
---

## Problem

Sales reps spend large amounts of time researching prospects.

## Workflow

1. collect company data
2. summarize signals
3. identify pain points
4. prepare outreach angle

## Result

Better personalization with less manual research.
