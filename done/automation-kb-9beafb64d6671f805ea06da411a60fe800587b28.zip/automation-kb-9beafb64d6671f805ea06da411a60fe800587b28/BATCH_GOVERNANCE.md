# BATCH_GOVERNANCE.md

## What a MACRO‑BATCH is

A MACRO‑BATCH is a ZIP patch‑pack that you upload to GitHub in one shot (Add files via upload).
It must be self‑contained and safe to apply as a single commit.

## Required contents (always)

1) Content/structure change files (the actual repo paths)
2) README.txt (what changed + why + pass criteria)
3) SHA256SUMS.txt (hashes for files in the patch‑pack)

## CONTROL LOOP policy (soft)

`00__AI__CONTROL_LOOP.md` is our strategic diary / continuity file across chats and lanes.

- We update it **only on the owner signal** (e.g., “обновить конрлуп”).
- A MACRO‑BATCH is **still valid** without a CONTROL_LOOP update.
- If we skip CONTROL_LOOP, README.txt must contain a short note: “CONTROL_LOOP: skipped (no owner signal)”.

Reason: you can have 5–7 moves per day; forcing the update on every batch causes friction and increases build churn.

## Deployment discipline

ZIP → one commit → Cloudflare build green → confirm key pages render.

No manual micro‑edits in the repo that bypass the batch trail.
