Macro-Batch patch-pack (directory artifact, no nested zip)
Spec: BATCH_SPEC.json
dry_run: false
Built(UTC): 2026-02-20T05:52:11Z

Files (git status porcelain):
 M tools/macro_batch_apply.mjs
?? artifacts/
