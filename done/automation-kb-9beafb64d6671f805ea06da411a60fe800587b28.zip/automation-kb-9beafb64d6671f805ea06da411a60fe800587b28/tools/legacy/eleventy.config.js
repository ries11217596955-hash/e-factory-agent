// eleventy.config.js — SINGLE SOURCE PROXY
// Contract: Eleventy must use exactly one config source.
// Source of truth is .eleventy.js

module.exports = require("./.eleventy.js");
