#!/usr/bin/env python3
import argparse, hashlib, subprocess, shutil
from pathlib import Path
from datetime import datetime

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _iter_files_under(p: Path):
    # Return all files under directory p (recursive), stable order
    return sorted([x for x in p.rglob("*") if x.is_file()])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", default="BATCH_SPEC.example.json")
    ap.add_argument("--dry-run", default="true")
    args = ap.parse_args()

    spec_path = args.spec
    dry_run = str(args.dry_run).lower()

    artifacts = Path("artifacts")
    outdir = artifacts / "patch-pack"
    outdir.mkdir(parents=True, exist_ok=True)

    # README header
    readme = outdir / "README.txt"
    readme.write_text(
        "\n".join([
            "Macro-Batch patch-pack (directory artifact, no nested zip)",
            f"Spec: {spec_path}",
            f"dry_run: {dry_run}",
            "Built(UTC): " + datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            "",
            "Files (git status porcelain):",
        ]) + "\n",
        encoding="utf-8"
    )

    st = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True)
    readme.write_text(readme.read_text(encoding="utf-8") + (st.stdout or ""), encoding="utf-8")

    # Collect changed/new paths from git status.
    # If a path is a directory, include all files under it recursively.
    paths = []
    seen = set()

    def add_file(rel: str):
        rel = rel.replace("\\", "/")
        if rel.startswith("artifacts/"):
            return
        if rel in seen:
            return
        rp = Path(rel)
        if rp.exists() and rp.is_file():
            seen.add(rel)
            paths.append(rel)

    def add_dir(rel: str):
        rel = rel.replace("\\", "/")
        if rel.startswith("artifacts/"):
            return
        rp = Path(rel)
        if rp.exists() and rp.is_dir():
            for f in _iter_files_under(rp):
                add_file(str(f))

    for line in (st.stdout or "").splitlines():
        if not line.strip():
            continue
        p = line[3:]
        if " -> " in p:
            p = p.split(" -> ", 1)[1]
        p = p.strip()
        pp = Path(p)

        if pp.exists() and pp.is_file():
            add_file(p)
        elif pp.exists() and pp.is_dir():
            add_dir(p)
        else:
            # Path may not exist (deleted file); ignore for patch-pack
            pass

    # Always include spec if exists and is a file
    sp = Path(spec_path)
    if sp.exists() and sp.is_file():
        add_file(spec_path)

    (outdir / "filelist.txt").write_text("\n".join(paths) + ("\n" if paths else ""), encoding="utf-8")

    # Copy files into outdir preserving paths
    copied = []
    for p in paths:
        src = Path(p)
        if not (src.exists() and src.is_file()):
            continue
        dst = outdir / p
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        copied.append(p)

    # SHA256SUMS for copied files
    sums = []
    for p in copied:
        fp = outdir / p
        if fp.exists() and fp.is_file():
            sums.append(f"{sha256_file(fp)}  {p}")
    (outdir / "SHA256SUMS.txt").write_text("\n".join(sums) + ("\n" if sums else ""), encoding="utf-8")

    print(str(outdir))

if __name__ == "__main__":
    main()
