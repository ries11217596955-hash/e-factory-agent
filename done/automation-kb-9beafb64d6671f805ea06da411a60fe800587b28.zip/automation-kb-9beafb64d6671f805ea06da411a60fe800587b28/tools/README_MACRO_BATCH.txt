Macro-Batch Service-Agent v0.2 (Spec → deterministic generator)

What you get
- You author ONLY a spec file (BATCH_SPEC*.json).
- GitHub Actions runs a deterministic generator (no LLM editing files).
- The workflow produces a patch-pack (changed/new files only), plus README.txt and SHA256SUMS.txt.

Supported ops (allowlist)
- createPost
- createHub
- ensureFile
- patchFile (literal string find/replace; fail-fast if 'find' is missing)

Safety / preflight
- Optional: spec.required_ops = ["..."].
  If present, tool verifies each required op is supported before running.

Unknown op.type hard-fails.
