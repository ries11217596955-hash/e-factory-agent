#!/usr/bin/env node
/**
 * Macro-Batch Service-Agent v0.3
 * - Reads a JSON Spec (BATCH_SPEC.json)
 * - Generates/updates/moves/deletes repo files deterministically (no LLM edits)
 *
 * Supported ops:
 *   - createPost
 *   - createHub
 *   - ensureFile
 *   - patchFile   (literal string find/replace; fail-fast if find missing)
 *   - moveFile    (rename/move; fail-fast if source missing)
 *   - deleteFile  (delete; fail-fast if target missing)
 *
 * Optional safety:
 *   - spec.required_ops: string[]  (if present, must be subset of supported ops)
 *
 * Usage:
 *   node tools/macro_batch_apply.mjs --spec BATCH_SPEC.json --dry-run false
 */

import fs from "node:fs";
import path from "node:path";
import process from "node:process";

const SUPPORTED_OPS = ["createPost","createHub","ensureFile","patchFile","moveFile","deleteFile"];

function die(msg, code = 2) {
  console.error("ERROR:", msg);
  process.exit(code);
}

function readJson(p) {
  const raw = fs.readFileSync(p, "utf8");
  return JSON.parse(raw);
}

function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}

function safeRepoPath(repoRoot, relPath) {
  // Disallow absolute paths and path traversal outside repoRoot
  if (!relPath || typeof relPath !== "string") die("path must be a string");
  if (path.isAbsolute(relPath)) die(`absolute paths are not allowed: ${relPath}`);
  const full = path.join(repoRoot, relPath);
  const normRoot = path.resolve(repoRoot) + path.sep;
  const normFull = path.resolve(full);
  if (!normFull.startsWith(normRoot)) die(`path traversal blocked: ${relPath}`);
  return normFull;
}

function writeFileIfChanged(filePath, content) {
  if (fs.existsSync(filePath)) {
    const cur = fs.readFileSync(filePath, "utf8");
    if (cur === content) return { changed: false, path: filePath };
  }
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, content, "utf8");
  return { changed: true, path: filePath };
}

function isoDateToday() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function slugify(s) {
  return String(s)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

function fm(obj) {
  // Simple YAML frontmatter builder for strings/arrays/bools/numbers
  const lines = ["---"];
  for (const [k, v] of Object.entries(obj)) {
    if (Array.isArray(v)) {
      lines.push(`${k}: [${v.map(x => JSON.stringify(x)).join(", ")}]`);
    } else if (typeof v === "string") {
      lines.push(`${k}: ${JSON.stringify(v)}`);
    } else {
      lines.push(`${k}: ${String(v)}`);
    }
  }
  lines.push("---");
  return lines.join("\n");
}

function preflightSpec(spec) {
  if (!spec || typeof spec !== "object") die("Spec must be an object");
  if (spec.spec_version !== "0.1") die("spec_version must be '0.1'");
  if (!spec.batch_type) die("batch_type is required");
  if (!Array.isArray(spec.ops) || spec.ops.length === 0) die("ops must be a non-empty array");

  // Optional capability lock
  if (Array.isArray(spec.required_ops)) {
    for (const rop of spec.required_ops) {
      if (!SUPPORTED_OPS.includes(String(rop))) {
        die(`Spec requires op '${rop}' but tool supports only: ${SUPPORTED_OPS.join(", ")}`);
      }
    }
  }

  for (const op of spec.ops) {
    if (!op || typeof op !== "object") die("Each op must be an object");
    if (!op.type) die("Each op must have type");
    const t = String(op.type);
    if (!SUPPORTED_OPS.includes(t)) die(`Unsupported op.type: ${t}`);
  }
}

function opCreatePost(op, repoRoot) {
  const title = op.title || die("createPost.title is required");
  const slug = op.slug ? slugify(op.slug) : slugify(title);
  const date = op.date || isoDateToday();
  const tags = Array.isArray(op.tags) ? op.tags : ["posts"];
  const summary = op.summary || "";
  const description = op.description || "";
  const layout = op.layout || "layouts/post.njk";
  const featured = Boolean(op.featured);

  const permalink = op.permalink || `/posts/${slug}/`;
  const filename = op.filename || `${date}-${slug}.md`;

  const front = { title, summary, description, date, tags, layout, permalink };
  if (featured) front.featured = true;

  const body = op.body || "";
  const content = `${fm(front)}\n${String(body).trim()}\n`;

  const outPath = safeRepoPath(repoRoot, path.join("src", "posts", filename));
  return writeFileIfChanged(outPath, content);
}

function opCreateHub(op, repoRoot) {
  const title = op.title || die("createHub.title is required");
  const slug = op.slug ? slugify(op.slug) : slugify(title);
  const description = op.description || "";
  const tags = Array.isArray(op.tags) ? op.tags : ["hub", slug];
  const layout = op.layout || "hub";

  const front = {
    title,
    description,
    layout,
    permalink: `/hubs/${slug}/`,
    tags,
    hubTag: op.hubTag || slug
  };

  const body = op.body || `# ${title}\n\n${description}\n`;
  const content = `${fm(front)}\n${String(body).trim()}\n`;

  const outPath = safeRepoPath(repoRoot, path.join("src", "hubs", slug, "index.md"));
  return writeFileIfChanged(outPath, content);
}

function opEnsureFile(op, repoRoot) {
  const rel = op.path || die("ensureFile.path is required");
  const content = (op.content !== undefined) ? String(op.content) : die("ensureFile.content is required");
  const outPath = safeRepoPath(repoRoot, rel);
  return writeFileIfChanged(outPath, content);
}

function opPatchFile(op, repoRoot) {
  const rel = op.path || die("patchFile.path is required");
  const find = (op.find !== undefined) ? String(op.find) : die("patchFile.find is required");
  const replace = (op.replace !== undefined) ? String(op.replace) : die("patchFile.replace is required");
  const p = safeRepoPath(repoRoot, rel);

  if (!fs.existsSync(p)) die(`patchFile target not found: ${rel}`);
  const cur = fs.readFileSync(p, "utf8");
  if (!cur.includes(find)) die(`patchFile.find not found in ${rel}`);
  const next = cur.split(find).join(replace);
  return writeFileIfChanged(p, next);
}

function opMoveFile(op, repoRoot, dryRun) {
  const fromRel = op.from || die("moveFile.from is required");
  const toRel = op.to || die("moveFile.to is required");
  const from = safeRepoPath(repoRoot, fromRel);
  const to = safeRepoPath(repoRoot, toRel);

  if (!fs.existsSync(from)) die(`moveFile source not found: ${fromRel}`);
  if (fs.existsSync(to)) die(`moveFile target already exists: ${toRel}`);

  if (!dryRun) {
    ensureDir(path.dirname(to));
    fs.renameSync(from, to);
  }
  return { changed: true, path: `${fromRel} -> ${toRel}` };
}

function opDeleteFile(op, repoRoot, dryRun) {
  const rel = op.path || die("deleteFile.path is required");
  const p = safeRepoPath(repoRoot, rel);
  if (!fs.existsSync(p)) die(`deleteFile target not found: ${rel}`);

  if (!dryRun) fs.unlinkSync(p);
  return { changed: true, path: rel };
}

function main() {
  const argv = process.argv.slice(2);
  const specIdx = argv.indexOf("--spec");
  const dryIdx = argv.indexOf("--dry-run");
  if (specIdx === -1 || !argv[specIdx + 1]) die("Missing --spec <file>");
  const specPath = argv[specIdx + 1];
  const dryRun = (dryIdx !== -1 && argv[dryIdx + 1]) ? String(argv[dryIdx + 1]).toLowerCase() === "true" : true;

  const repoRoot = process.cwd();
  const specAbs = safeRepoPath(repoRoot, specPath);
  if (!fs.existsSync(specAbs)) die(`Spec file not found: ${specPath}`);

  const spec = readJson(specAbs);
  preflightSpec(spec);

  let planned = 0;
  let written = 0;
  let changed = 0;

  for (const op of spec.ops) {
    planned += 1;
    const t = String(op.type);

    let res = null;
    if (t === "createPost") res = opCreatePost(op, repoRoot);
    else if (t === "createHub") res = opCreateHub(op, repoRoot);
    else if (t === "ensureFile") res = opEnsureFile(op, repoRoot);
    else if (t === "patchFile") res = opPatchFile(op, repoRoot);
    else if (t === "moveFile") res = opMoveFile(op, repoRoot, dryRun);
    else if (t === "deleteFile") res = opDeleteFile(op, repoRoot, dryRun);
    else die(`Unsupported op.type: ${t}`);

    // For move/delete we count as changed (planned structural change)
    written += 1;
    if (res && res.changed) changed += 1;

    const rel = res?.path || "(unknown)";
    if (res && res.changed) console.log(`CHANGED: ${rel}`);
    else console.log(`SKIP: ${rel}`);
  }

  console.log("MACRO_BATCH_OK");
  console.log("tool_version=0.3");
  console.log("supported_ops=" + SUPPORTED_OPS.join(","));
  console.log("batch_type=" + String(spec.batch_type));
  console.log("dry_run=" + String(dryRun));
  console.log("planned_ops=" + String(planned));
  console.log("files_written=" + String(written));
  console.log("files_changed=" + String(changed));
}

main();
