# MACRO-BATCH-25 — Surface Posts + Home latest block

## Goal
Make content visible in the UI (no more hidden posts) while staying inside current Eleventy guardrails (no `{% set %}` inside Markdown).

## Changes
1) `src/posts/index.njk`
- Create a simple, deterministic `/posts/` page (no pagination logic) that lists `collections.posts` (already sorted newest-first in `.eleventy.js`).

2) `src/index.md`
- Add a safe Nunjucks include for the existing latest-block partial: `partials/hub_latest_lists.njk`.
- This shows “Latest posts / tools / news” on the home page without using `{% set %}` in Markdown.

3) `src/news/index.njk`
- Adjust empty-state copy to remove the old “tag news” wording (news is folder-derived).

## Expected result
- `/posts/` no longer 404.
- Home page shows latest lists.
