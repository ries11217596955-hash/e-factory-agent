/**
 * checkMemory.js
 * Hard fail if repo memory SSOT files are missing/empty.
 * Runs in local build + Cloudflare Pages builds (via npm scripts).
 */
const fs = require('fs');
const path = require('path');

const required = [
  'STRATEGY_BOARD.md',
  '00__AI__CONTROL_LOOP.md',
  path.join('00__AI__MEMORY','01_MISTAKEBANK.md'),
  path.join('00__AI__MEMORY','02_GUARDS.md'),
  path.join('00__AI__MEMORY','03_DECISIONS.md'),
  path.join('00__AI__MEMORY','README.md'),
];

function fileSizeSafe(p) {
  try { return fs.statSync(p).size; } catch { return -1; }
}

const missing = [];
const tiny = [];

for (const rel of required) {
  const p = path.resolve(process.cwd(), rel);
  const sz = fileSizeSafe(p);
  if (sz < 0) missing.push(rel);
  else if (sz < 40) tiny.push(`${rel} (${sz} bytes)`);
}

if (missing.length || tiny.length) {
  console.error('[MEMORY_GUARD] FAIL');
  if (missing.length) console.error('Missing:', missing.join(', '));
  if (tiny.length) console.error('Too small/empty:', tiny.join(', '));
  console.error('Fix: restore required memory files under 00__AI__MEMORY and root.');
  process.exit(2);
}

console.log('[MEMORY_GUARD] OK: required memory files present.');
