/**
 * guardMemoryDiff.js
 * Guard: if "code/content" changes happen, require CONTROL_LOOP update in same commit.
 *
 * Rule:
 * - If any trigger paths changed (HEAD~1..HEAD):
 *     src/**, .eleventy.js, scripts/**, package.json, package-lock.json
 *   then 00__AI__CONTROL_LOOP.md must also be changed.
 *
 * Notes:
 * - Cloudflare Pages / CI clones may be shallow. We try to fetch depth=2 and retry.
 */

const { execSync } = require('child_process');

const SKIP = process.env.SKIP_MEMORY_DIFF_GUARD;
if (SKIP === '1' || (typeof SKIP === 'string' && SKIP.toLowerCase() === 'true')) {
  console.log('[MEMORY_DIFF_GUARD] SKIP: SKIP_MEMORY_DIFF_GUARD=1 (bypass)');
  process.exit(0);
}

function run(cmd) {
  return execSync(cmd, { stdio: ['ignore', 'pipe', 'pipe'] }).toString('utf8').trim();
}

function tryGetChangedFiles() {
  const out = run('git diff --name-only HEAD~1 HEAD');
  return out ? out.split('\n').map(s => s.trim()).filter(Boolean) : [];
}

function tryFetchDepth2AndRetry(err) {
  // Cloudflare Pages provides CF_PAGES_BRANCH and CF_PAGES_COMMIT_SHA.
  const branch = process.env.CF_PAGES_BRANCH || process.env.GITHUB_REF_NAME || 'main';
  try {
    console.log(`[MEMORY_DIFF_GUARD] INFO: shallow diff failed, trying fetch-depth=2 for branch "${branch}"...`);
    // Ensure origin exists; ignore errors if already present.
    try { run('git remote -v'); } catch (_) {}
    // Fetch just enough history for HEAD~1.
    run(`git fetch --no-tags --depth=2 origin ${branch}`);
    return tryGetChangedFiles();
  } catch (e2) {
    console.log('[MEMORY_DIFF_GUARD] SKIP: cannot compute git diff (need fetch-depth >= 2).');
    console.log('[MEMORY_DIFF_GUARD] NOTE: ensure CI checkout uses fetch-depth: 2 (GitHub Actions) or Pages clone includes history.');
    process.exit(0);
  }
}

let changed = [];
try {
  changed = tryGetChangedFiles();
} catch (e) {
  changed = tryFetchDepth2AndRetry(e);
}

const triggers = changed.some(f =>
  f === '.eleventy.js' ||
  f === 'package.json' ||
  f === 'package-lock.json' ||
  f.startsWith('src/') ||
  f.startsWith('scripts/')
);

if (!triggers) {
  console.log('[MEMORY_DIFF_GUARD] OK: no trigger-path changes detected.');
  process.exit(0);
}

const controlChanged = changed.some(f => f === '00__AI__CONTROL_LOOP.md');

if (!controlChanged) {
  console.log('[MEMORY_DIFF_GUARD] FAIL: trigger-path changes detected, but 00__AI__CONTROL_LOOP.md was NOT updated.');
  console.log('[MEMORY_DIFF_GUARD] Changed files:');
  changed.forEach(f => console.log(' - ' + f));
  console.log('');
  console.log('[MEMORY_DIFF_GUARD] Required action: add a short entry to 00__AI__CONTROL_LOOP.md describing this change.');
  process.exit(2);
}

console.log('[MEMORY_DIFF_GUARD] OK: trigger-path changes detected AND CONTROL_LOOP updated.');
process.exit(0);
