const fs = require("fs");
const path = require("path");

const ROOT = process.cwd();

// Files that define project memory for WebOps lane
const FILES = [
  "STRATEGY_BOARD.md",
  "00__AI__CONTROL_LOOP.md",
  "00__AI__MEMORY/01_MISTAKEBANK.md",
  "00__AI__MEMORY/02_GUARDS.md",
  "00__AI__MEMORY/03_DECISIONS.md",
];

const readSafe = (rel) => {
  const p = path.join(ROOT, rel);
  if (!fs.existsSync(p)) return null;
  return fs.readFileSync(p, "utf8");
};

const memory = [];
for (const file of FILES) {
  const content = readSafe(file);
  if (content == null) {
    console.warn(`[MEMORY_LOADER] missing: ${file}`);
    continue;
  }
  memory.push({ file, content });
}

const out = {
  generated_at: new Date().toISOString(),
  files_loaded: memory.length,
  memory,
};

// 1) For site build (Eleventy data)
const dataOut = path.join(ROOT, "src", "_data", "repoMemory.json");
fs.writeFileSync(dataOut, JSON.stringify(out, null, 2));

// 2) For debugging (kept outside the site tree)
const debugOut = path.join(ROOT, "scripts", "repoMemory.json");
fs.writeFileSync(debugOut, JSON.stringify(out, null, 2));

console.log(`[MEMORY_LOADER] loaded ${memory.length} files`);
console.log(`[MEMORY_LOADER] wrote: ${path.relative(ROOT, dataOut)}`);
console.log(`[MEMORY_LOADER] wrote: ${path.relative(ROOT, debugOut)}`);
