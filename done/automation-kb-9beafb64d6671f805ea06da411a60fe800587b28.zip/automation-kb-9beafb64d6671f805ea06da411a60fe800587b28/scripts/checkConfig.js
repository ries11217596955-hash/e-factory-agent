/*
  scripts/checkConfig.js
  Purpose: Fail-fast sanity checks for CI (Cloudflare Pages) WITHOUT requiring a full Eleventy runtime.
  This file must NEVER throw due to undefined local variables.
*/

const fs = require("fs");
const path = require("path");

function exists(p) {
  try {
    return fs.existsSync(p);
  } catch {
    return false;
  }
}

function makeStubConfig() {
  const stub = {};
  const noop = () => stub;

  // Eleventy config API (subset). We keep it broad to avoid breakage when .eleventy.js grows.
  const fns = [
    "addFilter",
    "addNunjucksFilter",
    "addLiquidFilter",
    "addShortcode",
    "addPairedShortcode",
    "addAsyncShortcode",
    "addCollection",
    "addTransform",
    "addPassthroughCopy",
    "addGlobalData",
    "addPlugin",
    "addWatchTarget",
    "setDataDeepMerge",
    "setLiquidOptions",
    "setNunjucksEnvironmentOptions",
    "setBrowserSyncConfig",
    "setServerOptions",
    "addLayoutAlias",
    "setLibrary",
    "amendLibrary",
    "addExtension",
    "addTemplateFormats",
  ];

  for (const k of fns) stub[k] = noop;

  // Minimal shape used sometimes by plugins.
  stub.javascriptFunctions = {};

  return stub;
}

function main() {
  const repoRoot = path.resolve(__dirname, "..");
  const eleventyConfigPath = path.join(repoRoot, ".eleventy.js");

  if (!exists(eleventyConfigPath)) {
    throw new Error("Missing .eleventy.js at repo root");
  }

  // Require config (must not crash the process due to our script)
  // If the config itself throws, we surface it with a stack.
  const eleventyConfigFn = require(eleventyConfigPath);

  if (typeof eleventyConfigFn !== "function") {
    throw new Error(".eleventy.js must export a function(eleventyConfig)");
  }

  // Call with a stub to ensure the file loads and registers without using real Eleventy.
  const stub = makeStubConfig();
  const cfg = eleventyConfigFn(stub);

  // Optional: validate returned directory/output keys if present.
  if (cfg && typeof cfg === "object") {
    if (cfg.dir && typeof cfg.dir === "object") {
      if (cfg.dir.output && typeof cfg.dir.output !== "string") {
        throw new Error(".eleventy.js: cfg.dir.output must be a string if provided");
      }
      if (cfg.dir.input && typeof cfg.dir.input !== "string") {
        throw new Error(".eleventy.js: cfg.dir.input must be a string if provided");
      }
    }
  }


  // --- GuardPack: Eleventy stability (fail-fast) ---
  // 1) .eleventy.js must not rely on an undefined `config` identifier.
  //    (Allowed: const config = eleventyConfig; then config.*)
  const eleventyJs = fs.readFileSync(eleventyConfigPath, "utf-8");
  if (/\bconfig\./.test(eleventyJs) && !/\bconst\s+config\s*=\s*eleventyConfig\b/.test(eleventyJs)) {
    throw new Error(".eleventy.js uses `config.*` but no alias `const config = eleventyConfig` was found");
  }

  // 2) Markdown must NOT contain Nunjucks logic tags like `{% set %}` (Eleventy may parse MD with a different engine).
  //    Enforce: no `{% set` anywhere in src/**/*.md.
  const srcRoot = path.join(repoRoot, "src");
  function walk(dir, out) {
    const items = fs.readdirSync(dir, { withFileTypes: true });
    for (const it of items) {
      const p = path.join(dir, it.name);
      if (it.isDirectory()) walk(p, out);
      else out.push(p);
    }
    return out;
  }
  const mdFiles = walk(srcRoot, []).filter((p) => p.toLowerCase().endsWith(".md"));
  const badMd = [];
  for (const f of mdFiles) {
    const t = fs.readFileSync(f, "utf-8");
    if (/\{%\s*set\b/.test(t)) badMd.push(path.relative(repoRoot, f));
  }
  if (badMd.length) {
    throw new Error("Found forbidden Nunjucks `{% set %}` in Markdown files:\n- " + badMd.join("\n- "));
  }

  // 3) Filter registry: if templates use known filters (postDate/dateReadable), they must be registered in .eleventy.js.
  function usesFilter(name) {
    const rx = new RegExp("\\|\\s*" + name + "\\b");
    // scan src/**/*.njk
    const njkFiles = walk(srcRoot, []).filter((p) => p.toLowerCase().endsWith(".njk"));
    for (const f of njkFiles) {
      const t = fs.readFileSync(f, "utf-8");
      if (rx.test(t)) return true;
    }
    return false;
  }
  function hasFilterRegistration(name) {
    const rx = new RegExp("add(Filter|NunjucksFilter|LiquidFilter)\\(\\s*['\\\"]" + name + "['\\\"]");
    return rx.test(eleventyJs);
  }
  const mustHave = ["postDate", "dateReadable"];
  for (const fName of mustHave) {
    if (usesFilter(fName) && !hasFilterRegistration(fName)) {
      throw new Error("Template uses filter `" + fName + "` but it is not registered in .eleventy.js");
    }
  }


  console.log("check-config: OK");
}

try {
  main();
} catch (err) {
  const msg = err && err.stack ? err.stack : String(err);
  console.error("check-config: FAIL\n" + msg);
  process.exit(2);
}
