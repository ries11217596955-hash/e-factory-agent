/**
 * Build output validation tests.
 * Run: node test/build-output.test.js
 * Expects _site/ to exist (run `npm run build` first).
 */
const fs = require("fs");
const path = require("path");

const SITE = path.join(__dirname, "..", "_site");
let passed = 0;
let failed = 0;

function assert(condition, label) {
  if (condition) {
    console.log(`  ✅ ${label}`);
    passed++;
  } else {
    console.error(`  ❌ ${label}`);
    failed++;
  }
}

function read(rel) {
  return fs.readFileSync(path.join(SITE, rel), "utf8");
}

function exists(rel) {
  return fs.existsSync(path.join(SITE, rel));
}

// --- RSS feeds ---
console.log("RSS feeds:");
{
  const postsXml = read("feeds/posts.xml");
  const newsXml = read("feeds/news.xml");

  assert(postsXml.includes("<item>"), "posts.xml contains <item> entries");
  assert(newsXml.includes("<item>"), "news.xml contains <item> entries");

  // Dates must be RFC 822 (e.g., "Sat, 14 Feb 2026 00:00:00 GMT")
  const rfc822Re = /\w{3}, \d{2} \w{3} \d{4} \d{2}:\d{2}:\d{2} GMT/;
  assert(rfc822Re.test(postsXml), "posts.xml has valid RFC 822 dates");
  assert(rfc822Re.test(newsXml), "news.xml has valid RFC 822 dates");

  // Should have multiple items
  const postItems = (postsXml.match(/<item>/g) || []).length;
  const newsItems = (newsXml.match(/<item>/g) || []).length;
  assert(postItems >= 3, `posts.xml has ${postItems} items (>= 3)`);
  assert(newsItems >= 3, `news.xml has ${newsItems} items (>= 3)`);
}

// --- Topic cloud ---
console.log("Topic cloud:");
{
  const postsIndex = read("posts/index.html");
  assert(postsIndex.includes("tag-row"), "posts index renders topic cloud (tag-row)");
  assert(postsIndex.includes('class="pill"'), "posts index has tag pills");
}

// --- No duplicate article navigation ---
console.log("Article navigation (no duplicates):");
{
  const article = read("posts/first-article/index.html");
  const navrowCount = (article.match(/class=".*navrow/g) || []).length;
  const articleNavCount = (article.match(/class="card section-gap article-nav"/g) || []).length;

  // Should have at most one of each nav type
  assert(navrowCount === 0, `no legacy navrow blocks (found ${navrowCount})`);
  assert(articleNavCount <= 1, `at most 1 article-nav block (found ${articleNavCount})`);

  // Related section should appear at most once
  const relatedCount = (article.match(/<h2>Related<\/h2>/g) || []).length;
  assert(relatedCount <= 1, `at most 1 Related heading (found ${relatedCount})`);
}

// --- Sitemap ---
console.log("Sitemap:");
{
  const sitemap = read("sitemap.xml");
  // Homepage entry should have a non-empty lastmod
  const homeLoc = `<loc>https://automation-kb.pages.dev/</loc>`;
  assert(sitemap.includes(homeLoc), "sitemap has homepage entry");

  // No empty lastmod tags
  assert(!sitemap.includes("<lastmod></lastmod>"), "no empty <lastmod> tags");
}

// --- Footer ---
console.log("Footer:");
{
  const page = read("posts/first-article/index.html");
  assert(!page.includes("pages · Built"), 'no phantom "pages" in footer');
  assert(page.includes("Built with Eleventy"), "footer has Eleventy credit");
}

// --- Summary ---
console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
