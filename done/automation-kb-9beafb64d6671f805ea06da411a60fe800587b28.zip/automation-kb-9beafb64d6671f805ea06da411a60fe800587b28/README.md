# automation-kb
AI for Sales knowledge base with practical workflows, outreach systems, lead-generation patterns, and automation notes that help turn AI into repeatable revenue work.
