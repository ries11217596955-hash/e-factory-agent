BATCH: macro amazon-ai content cluster
DATE: 2026-04-02
SCOPE: src/** only
MODE: DEVELOPMENT

INCLUDED
- 5 hub files (3 updates + 2 new cornerstones)
- 10 new posts in src/posts/
- no deletes
- no repo-root/config/layout changes outside src/hubs and src/posts

APPLY
1) Upload this ZIP to GH_BATCH inbox.
2) Run the normal batch apply flow.
3) Let the agent commit only included paths.

VERIFY ROUTES
- /hubs/amazon-ai/
- /hubs/amazon-ai/listing-optimization/
- /hubs/amazon-ai/review-monitoring/
- /hubs/amazon-ai/keyword-research/
- /hubs/amazon-ai/pricing-signals/
- /posts/2026-04-02-amazon-keyword-clustering-workflow/
- /posts/2026-04-02-amazon-negative-review-clustering/
- /posts/2026-04-02-amazon-pricing-change-alert-workflow/

EXPECTED EFFECT
- denser amazon-ai hub
- stronger internal linking cluster
- 10 new practical pages for traffic growth
- better base for future monetization pages inside amazon/ecommerce lane
