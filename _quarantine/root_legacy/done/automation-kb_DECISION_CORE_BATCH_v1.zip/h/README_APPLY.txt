DECISION CORE BATCH v1

FILES INCLUDED
- src/_includes/base.njk
- src/_data/hubs.js
- src/_data/site.json
- src/_data/seo.json
- src/index.md
- src/hubs/index.njk
- src/search/index.njk
- src/site-map/index.njk

OBJECTIVE
- Fix blank root and blank site-map rendering caused by base layout not outputting direct page content.
- Strengthen home as router.
- Strengthen hubs as structured decision layer.
- Strengthen search as guided lookup.
- Unify hub card data model and site identity.

VERIFY
1) / -> must show hero + 3-card decision layer + hub cards
2) /site-map/ -> must show structured cards, not blank page
3) /hubs/ -> must show full hub router
4) /search/ -> must show suggested queries + search box
5) Hub cards on home/hubs must be clickable and non-empty
