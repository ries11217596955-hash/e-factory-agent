module.exports = [
  {
    key: "ai-for-sales",
    href: "/hubs/ai-for-sales/",
    title: "AI for Sales",
    subtitle: "Lead generation, outreach, qualification, and follow-up systems.",
    description: "Using AI to automate lead generation, outreach, qualification, and sales execution."
  },
  {
    key: "amazon-ai",
    href: "/hubs/amazon-ai/",
    title: "AI for Amazon",
    subtitle: "Listings, keyword research, reviews, and marketplace conversion work.",
    description: "AI tools and workflows for Amazon listing optimization, pricing signals, and review monitoring."
  },
  {
    key: "shopify-ai",
    href: "/hubs/shopify-ai/",
    title: "AI for Shopify",
    subtitle: "Store operations, product content, and ecommerce automation.",
    description: "Automation and AI workflows for Shopify stores and ecommerce operations."
  },
  {
    key: "workflow",
    href: "/hubs/workflow/",
    title: "Workflow Systems",
    subtitle: "Execution patterns, orchestration, QA loops, and repeatable delivery.",
    description: "Designing scalable AI workflows, orchestration patterns, and automation pipelines."
  },
  {
    key: "operations",
    href: "/hubs/operations/",
    title: "Operations",
    subtitle: "Monitoring, stability, release truth, and live-site discipline.",
    description: "Deployment, monitoring, validation, and operational practices for running AI systems."
  },
  {
    key: "integrations",
    href: "/hubs/integrations/",
    title: "Integrations",
    subtitle: "APIs, webhooks, connectors, and cross-system automation paths.",
    description: "Connecting AI tools with APIs, webhooks, data systems, and external platforms."
  }
];
