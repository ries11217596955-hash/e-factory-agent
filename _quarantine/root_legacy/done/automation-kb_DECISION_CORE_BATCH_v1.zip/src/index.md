---
title: "AI Ecommerce Automation Knowledge Base"
description: "Start from a business goal, then move into the right hub, tools, and practical guides."
layout: "base.njk"
---

{% include "partials/hero_home.njk" %}

<section class="section-gap">
  <div class="grid grid--3">
    <section class="card card--soft">
      <h2 class="h2">Choose your goal</h2>
      <ul>
        <li><a href="/hubs/ai-for-sales/">Get more leads and meetings</a></li>
        <li><a href="/hubs/amazon-ai/">Improve marketplace and ecommerce execution</a></li>
        <li><a href="/hubs/workflow/">Build repeatable automation systems</a></li>
      </ul>
      <p class="card__meta">Do not start from random posts. Start from the outcome you want.</p>
    </section>

    <section class="card">
      <h2 class="h2">Main routes</h2>
      <ul>
        <li><a href="/start/">Start with guided entry</a></li>
        <li><a href="/hubs/">Browse all hubs</a></li>
        <li><a href="/tools/">Open tools and checklists</a></li>
        <li><a href="/search/">Search by topic or term</a></li>
      </ul>
      <p class="card__meta">Use Hubs first. Posts are the archive layer, not the primary decision layer.</p>
    </section>

    <section class="card">
      <h2 class="h2">What this site is</h2>
      <ul>
        <li>Sales workflow guidance</li>
        <li>Ecommerce operations knowledge</li>
        <li>Automation system patterns</li>
        <li>Reusable tools for execution and QA</li>
      </ul>
      <p class="card__meta">The goal is practical movement from problem → route → execution asset.</p>
    </section>
  </div>
</section>

<section class="section-gap">
  <section class="card card--soft">
    <h2 class="h2">Explore hubs</h2>
    <p class="card__text">Hubs are the main structured entry points. Each hub groups the most relevant pages under one practical theme.</p>
    {% include "partials/hub_grid.njk" %}
  </section>
</section>

{% include "partials/hub_latest_lists.njk" %}

<section class="section-gap">
  <div class="grid grid--3">
    <section class="card">
      <h2 class="h2">Guided entry</h2>
      <p class="card__text">New here? Start with the route planner instead of the full archive.</p>
      <p><a href="/start/">Open Start →</a></p>
    </section>

    <section class="card">
      <h2 class="h2">Operational assets</h2>
      <p class="card__text">Use Tools for deploy checks, templates, hygiene checks, and repeatable assets.</p>
      <p><a href="/tools/">Open Tools →</a></p>
    </section>

    <section class="card">
      <h2 class="h2">Mixed archive</h2>
      <p class="card__text">Posts remain available for deep reading, but they are no longer the best first step.</p>
      <p><a href="/posts/">Open Posts →</a></p>
    </section>
  </div>
</section>
