automation-kb keyword cluster batch
Scope: src/** only

APPLY
1) Put ZIP into GH_BATCH inbox
2) Run GH_BATCH
3) Check PASS / commit_created / PUSH_OK
