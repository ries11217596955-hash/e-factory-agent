# GH Batch Test Page

If you see this page, agent APPLY works.
