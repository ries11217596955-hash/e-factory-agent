SITE_AUDITOR_AGENT v3.0.1

Runtime profile:
- one run -> one ZIP report
- GitHub API ZIP fetch (git not required)
- target-aware audit baseline + hotfix cleanup
- desktop shortcut included

See README_RUN.txt for install/start steps.
