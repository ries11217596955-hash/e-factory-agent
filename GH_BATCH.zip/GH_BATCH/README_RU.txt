WEBOPS GH_BATCH v5

Состав
- RUN_BATCH.ps1

Что добавлено в v5
- secure token cache для GitHub PAT (без повторного ввода каждый запуск)
- env token support: GH_BATCH_PAT или GITHUB_PAT
- ForgetToken режим
- Preflight validation ZIP
- path traversal / duplicate / junk guard
- WEBOPS path policy guard
- batch size and file count guard
- change preview (ADD / UPDATE / SKIP_SAME)
- deploy report в logs

Как положить на ПК
Desktop\GH_BATCH\
  RUN_BATCH.ps1
  inbox\
  done\
  logs\

Как использовать
1. Положить ZIP в inbox
2. Запустить RUN_BATCH.ps1
3. При первом запуске ввести GitHub PAT
4. Скрипт сохранит токен в user-scoped secure store
5. Дальше PAT повторно не спрашивается

Как удалить сохранённый токен
powershell -ExecutionPolicy Bypass -File .\RUN_BATCH.ps1 -ForgetToken

Как сделать dry preview без коммита
powershell -ExecutionPolicy Bypass -File .\RUN_BATCH.ps1 -WhatIfOnly

Безопасность хранения токена
- используется Export-Clixml от SecureString
- токен читается только тем же Windows user на этом же ПК
- это не enterprise vault, но для локального PC-only режима практичный вариант

Замечание
- path policy сейчас допускает только типовые WEBOPS зоны: src/, assets/, public/, static/, docs/, data/, .github/ и несколько корневых файлов
- если в repo нужны другие корни, allowlist можно расширить


UPDATE v5.1
- Исправлен дефект одиночного ZIP в inbox (принудительное приведение списка ZIP к массиву через @(...)).
- Добавлен явный лог: Working directory, Inbox path, ZIP count detected, Selected ZIP.
- Ярлык рекомендуется запускать через -NoExit для видимой диагностики.
