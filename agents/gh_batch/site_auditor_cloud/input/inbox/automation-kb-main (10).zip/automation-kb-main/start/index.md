---
title: Start Here
layout: base.njk
permalink: /start/
---

# Start with the outcome you want

Do not browse randomly. Choose your goal and follow a clear path.

---

## Choose your goal

### Get more leads and meetings
- /hubs/ai-for-sales/lead-generation/
- /hubs/ai-for-sales/outreach/
- /hubs/ai-for-sales/follow-up/

### Improve ecommerce performance
- /hubs/amazon-ai/listing-optimization/
- /hubs/amazon-ai/keyword-research/
- /hubs/amazon-ai/pricing-signals/
- /hubs/shopify-ai/store-optimization/

### Build automation systems
- /hubs/workflow/
- /hubs/operations/
- /hubs/integrations/
- /tools/

---

## Quick start

Open one path and follow it fully. Do not mix multiple directions at once.

---

## Tools you can use

Use tools when you need execution, not just theory.

- AI copy tools (for outreach, listings, product pages)
- Automation tools (for workflows and operations)
- CRM / outreach tools (for pipeline and follow-up)

---

## Typical paths

### Sales system
Lead generation → Outreach → Follow-up

### Ecommerce system
Keyword research → Listing optimization → Pricing signals

### System building
Workflow → Operations → Integrations

---

## Next step

- /hubs/
- /tools/
