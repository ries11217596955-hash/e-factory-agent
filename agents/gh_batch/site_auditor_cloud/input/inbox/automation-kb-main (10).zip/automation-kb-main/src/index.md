---
layout: base.njk
title: Home
---

# AI Ecommerce Automation Knowledge Base

## Choose your goal

- Get more leads → /start/
- Improve ecommerce operations → /hubs/
- Build automation systems → /tools/

## Start here
→ /start/

## Explore hubs
→ /hubs/

## Use tools
→ /tools/
