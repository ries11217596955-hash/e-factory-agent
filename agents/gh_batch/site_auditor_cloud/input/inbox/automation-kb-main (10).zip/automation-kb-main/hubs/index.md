---
title: Automation Knowledge Hubs
layout: base.njk
permalink: /hubs/
---

# Automation Knowledge Hubs

Start from a clear path. Each hub groups practical workflows, tools, and routes under one topic.

## Business paths

- [AI for Sales](/hubs/ai-for-sales/) — lead generation, outreach, qualification, and follow-up.
- [AI for Amazon](/hubs/amazon-ai/) — listings, keyword research, pricing signals, reviews, and conversion fixes.
- [AI for Shopify](/hubs/shopify-ai/) — store operations, conversion, and ecommerce automation.

## Build and operate

- [Workflow Systems](/hubs/workflow/) — execution patterns, safe iteration, and repeatable flows.
- [Operations](/hubs/operations/) — monitoring, stability, and release-safe system work.
- [Integrations](/hubs/integrations/) — Shopify, Amazon, CRM, and external tool connections.

## How to use hubs

Start from your outcome, not from random posts.

- Want more leads → go to AI for Sales
- Want better ecommerce performance → go to Amazon or Shopify hubs
- Want repeatable systems → go to Workflows and Operations

Each hub should give you:
- a starting point
- a simple path
- links to exact guides
