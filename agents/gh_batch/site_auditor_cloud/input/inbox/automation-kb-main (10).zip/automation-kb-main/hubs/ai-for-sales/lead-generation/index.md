---
title: AI Lead Generation
layout: hub.njk
permalink: /hubs/ai-for-sales/lead-generation/
---

## Build a repeatable lead flow instead of random outreach

### What this solves
- Lead flow depends on manual effort
- Pipeline starts inconsistently
- Prospecting quality is uneven

### Start from your problem

**No steady lead volume**
- Define ICP and source rules
- Build one simple prospecting routine

**Leads are weak quality**
- Add qualification filters
- Score before outreach

**Outreach feels chaotic**
- Connect lead collection to message and follow-up steps

### Simple workflow

1. Define ICP
2. Collect leads
3. Filter and qualify
4. Route into outreach
5. Track replies and meetings

### Expected result
- Cleaner pipeline input
- Better outreach readiness
- More stable lead generation

### Next
- /hubs/ai-for-sales/outreach/
- /hubs/ai-for-sales/follow-up/
- /hubs/ai-for-sales/
