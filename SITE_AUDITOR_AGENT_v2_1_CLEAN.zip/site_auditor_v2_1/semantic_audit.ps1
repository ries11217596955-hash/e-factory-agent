function Invoke-SemanticAudit {
    param($Inventory)

    $issues = @()

    foreach ($p in $Inventory) {
        if (-not $p.title) {
            $issues += [PSCustomObject]@{
                type = 'TITLE_MISSING'
                severity = 'P1'
                file = $p.file
                route = $p.route
            }
        }

        if (-not $p.description) {
            $issues += [PSCustomObject]@{
                type = 'META_DESC_MISSING'
                severity = 'P2'
                file = $p.file
                route = $p.route
            }
        }

        if (-not $p.permalink) {
            $issues += [PSCustomObject]@{
                type = 'PERMALINK_MISSING'
                severity = 'P3'
                file = $p.file
                route = $p.route
            }
        }
    }

    return $issues
}
