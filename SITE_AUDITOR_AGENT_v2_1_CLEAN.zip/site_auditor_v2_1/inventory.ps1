function Normalize-FrontMatterValue {
    param([string]$Value)

    if ($null -eq $Value) { return $null }

    $clean = $Value.Trim()
    $chars = [char[]]@("'", '"', ' ', "`t")
    $clean = $clean.Trim($chars)

    if ([string]::IsNullOrWhiteSpace($clean)) { return $null }
    return $clean
}

function Convert-RepoPathToRoute {
    param(
        [string]$RepoPath,
        [string]$FilePath,
        [string]$BaseUrl
    )

    $relative = $FilePath.Substring($RepoPath.Length).TrimStart("\", "/")
    $normalized = $relative -replace '\\','/'

    if ($normalized -match '^src/') {
        $normalized = $normalized.Substring(4)
    }

    $route = $normalized
    $route = $route -replace '/index\.(md|html|njk)$','/'
    $route = $route -replace '\.(md|html|njk)$','/'
    $route = $route -replace '/+','/'
    if (-not $route.StartsWith('/')) { $route = '/' + $route }

    $fullUrl = $BaseUrl.TrimEnd('/') + $route

    return [PSCustomObject]@{
        relative_path = $normalized
        route         = $route
        full_url      = $fullUrl
    }
}

function Build-SiteInventory {
    param(
        [string]$RepoPath,
        [string]$BaseUrl
    )

    $files = Get-ChildItem -LiteralPath $RepoPath -Recurse -File | Where-Object {
        $_.Extension -in '.md','.html','.njk'
    }

    $inventory = @()

    foreach ($f in $files) {
        $content = Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8

        $title = $null
        $description = $null
        $permalink = $null
        $links = @()

        if ($content -match '(?im)^title\s*:\s*(.+)$') {
            $title = Normalize-FrontMatterValue -Value $Matches[1]
        }
        if ($content -match '(?im)^description\s*:\s*(.+)$') {
            $description = Normalize-FrontMatterValue -Value $Matches[1]
        }
        if ($content -match '(?im)^permalink\s*:\s*(.+)$') {
            $permalink = Normalize-FrontMatterValue -Value $Matches[1]
        }

        $routeInfo = Convert-RepoPathToRoute -RepoPath $RepoPath -FilePath $f.FullName -BaseUrl $BaseUrl
        if ($permalink) {
            $route = if ($permalink.StartsWith('/')) { $permalink } else { '/' + $permalink }
            $fullUrl = $BaseUrl.TrimEnd('/') + $route
        } else {
            $route = $routeInfo.route
            $fullUrl = $routeInfo.full_url
        }

        $regexes = @(
            'href\s*=\s*"([^"]+)"',
            "href\s*=\s*'([^']+)'",
            '\[[^\]]+\]\(([^\)]+)\)'
        )
        foreach ($pattern in $regexes) {
            foreach ($m in [regex]::Matches($content, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
                if ($m.Groups.Count -gt 1) {
                    $val = $m.Groups[1].Value.Trim()
                    if ($val) { $links += $val }
                }
            }
        }
        $links = $links | Select-Object -Unique

        $inventory += [PSCustomObject]@{
            file         = $routeInfo.relative_path
            source_path  = $f.FullName
            title        = $title
            description  = $description
            permalink    = $permalink
            route        = $route
            full_url     = $fullUrl
            links        = @($links)
        }
    }

    return $inventory
}
