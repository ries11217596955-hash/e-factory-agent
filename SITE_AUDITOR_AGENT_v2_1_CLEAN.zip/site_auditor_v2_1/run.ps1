$AgentRoot = $PSScriptRoot

$RunLog = Join-Path $AgentRoot "RUN_INTERNAL_LOG.txt"
$ErrLog = Join-Path $AgentRoot "RUN_INTERNAL_ERROR.txt"

Remove-Item $RunLog -ErrorAction SilentlyContinue
Remove-Item $ErrLog -ErrorAction SilentlyContinue

"=== START $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ===" |
Out-File $RunLog -Encoding utf8

try {
    . "$AgentRoot\agent.ps1"
    Invoke-SiteAudit *>> $RunLog

    "=== SUCCESS $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ===" |
    Out-File $RunLog -Append -Encoding utf8
}
catch {
    $_ | Format-List * -Force |
    Out-File $ErrLog -Encoding utf8

    "=== FAILED $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ===" |
    Out-File $RunLog -Append -Encoding utf8

    Write-Host ""
    Write-Host "FAILED. Open:"
    Write-Host $ErrLog
}
