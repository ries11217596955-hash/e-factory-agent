function Resolve-InventoryLinkRoute {
    param(
        [string]$Link,
        [string]$CurrentRoute
    )

    if ([string]::IsNullOrWhiteSpace($Link)) { return $null }
    if ($Link -match '^(http|https|mailto|tel):') { return $null }
    if ($Link.StartsWith('#')) { return $CurrentRoute }

    $linkOnly = $Link.Split('#')[0].Split('?')[0]
    if ([string]::IsNullOrWhiteSpace($linkOnly)) { return $CurrentRoute }

    if ($linkOnly.StartsWith('/')) {
        $route = $linkOnly
    }
    else {
        $base = $CurrentRoute
        if (-not $base.EndsWith('/')) { $base = $base + '/' }
        $route = $base + $linkOnly
    }

    $route = $route -replace '/+','/'
    $parts = New-Object System.Collections.Generic.List[string]
    foreach ($part in ($route -split '/')) {
        if ($part -eq '' -or $part -eq '.') { continue }
        if ($part -eq '..') {
            if ($parts.Count -gt 0) { $parts.RemoveAt($parts.Count - 1) }
            continue
        }
        $parts.Add($part)
    }
    return '/' + (($parts -join '/').TrimEnd('/')) + '/'
}

function Invoke-LinksAudit {
    param($Inventory)

    $routeMap = @{}
    foreach ($item in $Inventory) {
        $routeMap[$item.route] = $item
    }

    $incoming = @{}
    foreach ($item in $Inventory) {
        if (-not $incoming.ContainsKey($item.route)) {
            $incoming[$item.route] = 0
        }
    }

    $broken = @()

    foreach ($item in $Inventory) {
        foreach ($lnk in @($item.links)) {
            $targetRoute = Resolve-InventoryLinkRoute -Link $lnk -CurrentRoute $item.route
            if (-not $targetRoute) { continue }

            if ($routeMap.ContainsKey($targetRoute)) {
                $incoming[$targetRoute] = [int]$incoming[$targetRoute] + 1
            }
            else {
                $broken += [PSCustomObject]@{
                    source_file  = $item.file
                    source_route = $item.route
                    bad_link     = $lnk
                    target_route = $targetRoute
                    severity     = 'P1'
                }
            }
        }
    }

    $orphans = @()
    foreach ($item in $Inventory) {
        if ($item.route -eq '/') { continue }
        if ([int]$incoming[$item.route] -eq 0) {
            $orphans += [PSCustomObject]@{
                file     = $item.file
                route    = $item.route
                severity = 'P2'
            }
        }
    }

    return [PSCustomObject]@{
        BrokenLinks = $broken
        Orphans     = $orphans
    }
}
