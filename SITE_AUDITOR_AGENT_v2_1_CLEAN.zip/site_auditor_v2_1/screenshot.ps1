function Get-AvailableBrowserPath {
    $candidates = @(
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles(x86)\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "$env:ProgramFiles(x86)\Google\Chrome\Application\chrome.exe"
    )

    foreach ($path in $candidates) {
        if (Test-Path -LiteralPath $path) {
            return $path
        }
    }

    return $null
}

function Invoke-ScreenshotCapture {
    param(
        $Inventory,
        [string]$BaseUrl,
        [string]$WorkPath,
        [int]$MaxScreenshots
    )

    if (-not $MaxScreenshots -or $MaxScreenshots -lt 1) {
        $MaxScreenshots = 5
    }

    $browser = Get-AvailableBrowserPath
    if (-not $browser) {
        return @([PSCustomObject]@{
            status = 'SKIPPED'
            reason = 'BROWSER_NOT_FOUND'
        })
    }

    $shotDir = Join-Path $WorkPath 'screens'
    if (Test-Path -LiteralPath $shotDir) {
        Remove-Item -LiteralPath $shotDir -Recurse -Force
    }
    New-Item -ItemType Directory -Path $shotDir -Force | Out-Null

    $targets = @($Inventory | Select-Object -First $MaxScreenshots)
    $results = @()

    foreach ($item in $targets) {
        $safeName = (($item.route -replace '[\\/:*?"<>|]','_').Trim('_'))
        if ([string]::IsNullOrWhiteSpace($safeName)) { $safeName = 'home' }
        $outFile = Join-Path $shotDir ($safeName + '.png')

        try {
            & $browser --headless --disable-gpu --hide-scrollbars --window-size=1440,2200 --screenshot=$outFile $item.full_url | Out-Null
            $ok = Test-Path -LiteralPath $outFile
            $results += [PSCustomObject]@{
                route      = $item.route
                full_url   = $item.full_url
                local_path = $(if($ok){$outFile}else{$null})
                status     = $(if($ok){'OK'}else{'FAILED'})
            }
        }
        catch {
            $results += [PSCustomObject]@{
                route      = $item.route
                full_url   = $item.full_url
                local_path = $null
                status     = 'FAILED'
                reason     = $_.Exception.Message
            }
        }
    }

    return $results
}
