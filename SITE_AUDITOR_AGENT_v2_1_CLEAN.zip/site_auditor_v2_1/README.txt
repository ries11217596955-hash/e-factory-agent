SITE_AUDITOR_AGENT v2.1

Install:
1. Put your GitHub token into .state\github_token.txt
2. Run .\run.ps1
3. Get ZIP report from outbox\

This build uses GitHub API ZIP download. Git is not required.
