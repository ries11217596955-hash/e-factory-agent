function Get-AgentRoot {
    $root = $PSScriptRoot
    if (-not $root) {
        $root = Split-Path -Parent $MyInvocation.MyCommand.Path
    }
    return $root
}

function Get-AgentConfig {
    param([string]$ConfigPath)

    if (!(Test-Path -LiteralPath $ConfigPath)) {
        throw "CONFIG_NOT_FOUND: $ConfigPath"
    }

    $raw = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8
    if ([string]::IsNullOrWhiteSpace($raw)) {
        throw "CONFIG_EMPTY: $ConfigPath"
    }

    try {
        return ($raw | ConvertFrom-Json)
    }
    catch {
        throw "CONFIG_JSON_INVALID: $ConfigPath"
    }
}

function Get-GitHubToken {
    param([string]$TokenPath)

    if (!(Test-Path -LiteralPath $TokenPath)) {
        throw "TOKEN_FILE_NOT_FOUND: $TokenPath"
    }

    $token = (Get-Content -LiteralPath $TokenPath -Raw -Encoding UTF8).Trim()

    if ([string]::IsNullOrWhiteSpace($token)) {
        throw "TOKEN_EMPTY"
    }

    return $token
}

function Remove-DirectorySafe {
    param([string]$Path)

    if (Test-Path -LiteralPath $Path) {
        Remove-Item -LiteralPath $Path -Recurse -Force
    }
}

function Expand-RepoZipToTarget {
    param(
        [string]$ZipPath,
        [string]$ExtractRoot,
        [string]$TargetPath
    )

    Remove-DirectorySafe -Path $ExtractRoot
    Remove-DirectorySafe -Path $TargetPath

    Expand-Archive -LiteralPath $ZipPath -DestinationPath $ExtractRoot -Force

    $topDir = Get-ChildItem -LiteralPath $ExtractRoot -Directory | Select-Object -First 1
    if (-not $topDir) {
        throw "ZIP_TOP_DIR_NOT_FOUND"
    }

    New-Item -ItemType Directory -Force -Path $TargetPath | Out-Null

    Get-ChildItem -LiteralPath $topDir.FullName -Force | ForEach-Object {
        Move-Item -LiteralPath $_.FullName -Destination $TargetPath -Force
    }
}

function Download-RepoZipViaApi {
    param(
        [string]$RepoOwner,
        [string]$RepoName,
        [string]$Branch,
        [string]$Token,
        [string]$WorkPath,
        [string]$TargetPath
    )

    $zipUrl = "https://api.github.com/repos/$RepoOwner/$RepoName/zipball/$Branch"
    $zipPath = Join-Path $WorkPath "repo.zip"
    $extractPath = Join-Path $WorkPath "repo_extract"

    if (Test-Path -LiteralPath $zipPath) {
        Remove-Item -LiteralPath $zipPath -Force
    }

    $headers = @{
        Authorization = "Bearer $Token"
        Accept        = "application/vnd.github+json"
        "User-Agent"  = "SITE_AUDITOR_AGENT"
    }

    try {
        Invoke-WebRequest -Uri $zipUrl -Headers $headers -OutFile $zipPath -UseBasicParsing
    }
    catch {
        throw "GITHUB_ZIP_DOWNLOAD_FAILED: $zipUrl :: $($_.Exception.Message)"
    }

    if (!(Test-Path -LiteralPath $zipPath)) {
        throw "ZIP_NOT_DOWNLOADED"
    }

    Expand-RepoZipToTarget -ZipPath $zipPath -ExtractRoot $extractPath -TargetPath $TargetPath
}

function Write-SummaryFiles {
    param(
        [string]$ReportDir,
        [object]$Inventory,
        [object]$SemanticIssues,
        [object]$LinkIssues,
        [object]$Orphans,
        [object]$Screenshots
    )

    $summary = [PSCustomObject]@{
        inventory_count = @($Inventory).Count
        semantic_issues = @($SemanticIssues).Count
        broken_links    = @($LinkIssues).Count
        orphan_pages    = @($Orphans).Count
        screenshots     = @($Screenshots).Count
        generated_at    = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    }

    $summary | ConvertTo-Json -Depth 10 |
        Out-File -LiteralPath (Join-Path $ReportDir "summary.json") -Encoding utf8

    $lines = @()
    $lines += "SITE AUDIT SUMMARY"
    $lines += ""
    $lines += "Inventory count : $(@($Inventory).Count)"
    $lines += "Semantic issues : $(@($SemanticIssues).Count)"
    $lines += "Broken links    : $(@($LinkIssues).Count)"
    $lines += "Orphan pages    : $(@($Orphans).Count)"
    $lines += "Screenshots     : $(@($Screenshots).Count)"
    $lines += ""
    $lines += "Top semantic issues:"
    $lines += @($SemanticIssues | Select-Object -First 20)

    $lines | Out-File -LiteralPath (Join-Path $ReportDir "SUMMARY.txt") -Encoding utf8
}

function Invoke-SiteAudit {
    $AgentRoot = Get-AgentRoot

    $ConfigPath = Join-Path $AgentRoot "agent.config.json"
    $TokenPath  = Join-Path $AgentRoot ".state\github_token.txt"
    $WorkPath   = Join-Path $AgentRoot "work"
    $OutboxPath = Join-Path $AgentRoot "outbox"

    New-Item -ItemType Directory -Force -Path $WorkPath | Out-Null
    New-Item -ItemType Directory -Force -Path $OutboxPath | Out-Null

    Write-Host "[PHASE] Loading config"
    $cfg = Get-AgentConfig -ConfigPath $ConfigPath

    Write-Host "[PHASE] Resolving token"
    $token = Get-GitHubToken -TokenPath $TokenPath

    Write-Host "[PHASE] Loading modules"
    . "$AgentRoot\inventory.ps1"
    . "$AgentRoot\semantic_audit.ps1"
    . "$AgentRoot\links_audit.ps1"
    . "$AgentRoot\screenshot.ps1"

    $repoOwner = $cfg.repo_owner
    $repoName  = $cfg.repo_name
    $branch    = $cfg.branch
    if ([string]::IsNullOrWhiteSpace($branch)) { $branch = "main" }

    $baseUrl = $cfg.base_url
    if ([string]::IsNullOrWhiteSpace($baseUrl)) {
        $baseUrl = "https://automation-kb.pages.dev"
    }

    Write-Host "[PHASE] Fetching repository"
    $RepoPath = Join-Path $WorkPath "repo"
    Download-RepoZipViaApi `
        -RepoOwner $repoOwner `
        -RepoName  $repoName `
        -Branch    $branch `
        -Token     $token `
        -WorkPath  $WorkPath `
        -TargetPath $RepoPath

    Write-Host "[PHASE] Building inventory"
    $Inventory = Build-SiteInventory -RepoPath $RepoPath -BaseUrl $baseUrl

    Write-Host "[PHASE] Semantic audit"
    $SemanticIssues = Invoke-SemanticAudit -Inventory $Inventory

    Write-Host "[PHASE] Broken links audit"
    $LinkAudit = Invoke-LinksAudit -Inventory $Inventory
    $LinkIssues = $LinkAudit.BrokenLinks
    $Orphans = $LinkAudit.Orphans

    Write-Host "[PHASE] Screenshots"
    $Screenshots = Invoke-ScreenshotCapture -Inventory $Inventory -BaseUrl $baseUrl -WorkPath $WorkPath -MaxScreenshots $cfg.max_screenshots

    Write-Host "[PHASE] Packaging report"
    $ts = Get-Date -Format "yyyyMMdd_HHmmss"
    $reportDir = Join-Path $WorkPath "report_$ts"
    Remove-DirectorySafe -Path $reportDir
    New-Item -ItemType Directory -Path $reportDir -Force | Out-Null

    $Inventory | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "inventory.json") -Encoding utf8
    $SemanticIssues | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "semantic_issues.json") -Encoding utf8
    $LinkIssues | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "broken_links.json") -Encoding utf8
    $Orphans | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "orphans.json") -Encoding utf8
    $Screenshots | ConvertTo-Json -Depth 10 | Out-File -LiteralPath (Join-Path $reportDir "screenshots.json") -Encoding utf8

    if (@($Screenshots).Count -gt 0) {
        $shotsDir = Join-Path $reportDir "screenshots"
        New-Item -ItemType Directory -Path $shotsDir -Force | Out-Null
        foreach ($shot in $Screenshots) {
            if ($shot.local_path -and (Test-Path -LiteralPath $shot.local_path)) {
                Copy-Item -LiteralPath $shot.local_path -Destination (Join-Path $shotsDir ([IO.Path]::GetFileName($shot.local_path))) -Force
            }
        }
    }

    Write-SummaryFiles -ReportDir $reportDir -Inventory $Inventory -SemanticIssues $SemanticIssues -LinkIssues $LinkIssues -Orphans $Orphans -Screenshots $Screenshots

    $zip = Join-Path $OutboxPath "SITE_AUDIT_PACK_$ts.zip"
    if (Test-Path -LiteralPath $zip) {
        Remove-Item -LiteralPath $zip -Force
    }
    Compress-Archive -Path (Join-Path $reportDir "*") -DestinationPath $zip -Force

    Write-Host ""
    Write-Host "REPORT:"
    Write-Host $zip
}
