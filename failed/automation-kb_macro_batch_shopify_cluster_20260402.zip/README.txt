MACRO BATCH: Shopify cluster expansion
Scope: src/** only

APPLY
- Upload this ZIP into GH_BATCH inbox/new
- Let GH_BATCH process it
- This batch adds Shopify cluster content + hub expansion

VERIFY
- /hubs/shopify-ai/
- /hubs/shopify-ai/conversion-recovery/
- /hubs/shopify-ai/support-ops/
- /posts/2026-04-02-shopify-abandoned-cart-recovery-map/
- /posts/2026-04-02-shopify-return-request-triage/

FILES
- 1 updated hub index
- 2 new hub pages
- 10 new posts
