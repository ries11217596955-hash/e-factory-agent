FOUNDATION FIX BATCH v2
Scope: src/** only

Fixes:
- removes visible build stamp from hero and footer
- removes user-facing Edit on GitHub links
- normalizes post layout aliases to single article shell
- fixes hub grid empty descriptions
- upgrades /hubs/ from plain list to real entry page
