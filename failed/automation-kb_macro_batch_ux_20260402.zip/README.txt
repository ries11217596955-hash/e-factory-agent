automation-kb UX batch
Scope: src/** only

APPLY
1) Put this ZIP into GH_BATCH inbox
2) Run GH_BATCH
3) Check PASS / commit_created / PUSH_OK

FILES
- src/index.md
- src/hubs/index.njk
- src/hubs/amazon-ai/index.njk
- src/hubs/shopify-ai/index.njk
- src/hubs/ecommerce-ai/index.md
- src/hubs/ai-tools/index.md

VERIFY
- /
- /hubs/
- /hubs/amazon-ai/
- /hubs/shopify-ai/
- /hubs/ecommerce-ai/
- /hubs/ai-tools/
