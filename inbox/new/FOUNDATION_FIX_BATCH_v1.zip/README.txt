FOUNDATION FIX BATCH v1
Scope: src/** only

Fixes:
- removes visible build stamp from footer
- removes user-facing Edit on GitHub links
- fixes duplicate layout issue for layout: post
- fixes hub grid empty descriptions
- upgrades /hubs/ from plain list to real entry page
