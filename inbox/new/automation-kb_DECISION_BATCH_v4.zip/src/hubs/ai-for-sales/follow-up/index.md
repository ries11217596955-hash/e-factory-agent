---
title: AI Follow-Up
layout: hub.njk
permalink: /hubs/ai-for-sales/follow-up/
---

## Turn first contact into a repeatable follow-up system

### What this solves
- Leads disappear after first touch
- Follow-up timing is inconsistent
- CRM updates happen too late
- Good prospects are lost because the sequence breaks

### Start from your problem

**Prospects go cold too fast**
- Define a follow-up window before sending
- Separate no-reply from soft-interest cases

**Pipeline tracking is weak**
- Update CRM after each step
- Use one decision after every reply: continue, book, or close-lost

**Meetings do not convert from outreach**
- Recheck message angle and qualification quality
- Fix the sequence, not only the copy

### Simple workflow

1. Send first contact
2. Split reply vs no-reply
3. Schedule the next follow-up touch
4. Update CRM after each outcome
5. Route into meeting-booking or close-lost decision

### Use these guides

- Follow-up automation framework
- Follow-up sequence automation framework
- Meeting booking checklist
- CRM enrichment automation playbook
- Weekly sales metrics that matter
- Sales outreach metrics that matter

### Expected result
- Less leakage after first contact
- Cleaner pipeline discipline
- More consistent meeting progression

### Next
- /hubs/ai-for-sales/outreach/
- /hubs/ai-for-sales/lead-generation/
- /hubs/ai-for-sales/
