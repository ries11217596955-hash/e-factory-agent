---
title: AI Outreach
layout: hub.njk
permalink: /hubs/ai-for-sales/outreach/
---

## Build outreach that gets replies instead of random sends

### What this solves
- Outreach volume exists, but replies stay weak
- Messages sound generic or irrelevant
- Prospecting and messaging are disconnected
- Follow-up starts too late or with the wrong angle

### Start from your problem

**Low reply rate**
- Tighten relevance before personalization
- Use one clear message angle, not multiple offers

**Leads look good but meetings do not happen**
- Check qualification before send
- Align outreach with the real pain or buying trigger

**Outreach feels chaotic**
- Connect lead generation, outreach, and follow-up into one path
- Use one workflow instead of scattered actions

### Simple workflow

1. Define the ICP and lead source
2. Filter and qualify before outreach
3. Write one clear angle
4. Send with clean deliverability
5. Monitor replies and route into follow-up

### Use these guides

- AI cold email personalization at scale
- AI cold email with guardrails
- LinkedIn outreach script - 3 messages
- AI LinkedIn prospecting system
- Cold email deliverability basics
- Anti-spam compliance for outreach automation

### Expected result
- Clearer outreach logic
- Better reply quality
- Stronger handoff into meetings or follow-up

### Next
- /hubs/ai-for-sales/lead-generation/
- /hubs/ai-for-sales/follow-up/
- /hubs/ai-for-sales/
