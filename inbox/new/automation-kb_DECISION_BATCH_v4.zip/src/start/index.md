---
title: Start Here
layout: base.njk
permalink: /start/
---

# Start with the business outcome

Do not start from random posts. Start with the result you want, then move into one clear route.

## 1) I want more leads and meetings

Open:

- [AI for Sales](/hubs/ai-for-sales/)
- [Lead generation](/hubs/ai-for-sales/lead-generation/)
- [Outreach](/hubs/ai-for-sales/outreach/)
- [Follow-up](/hubs/ai-for-sales/follow-up/)

This path is for:
- pipeline building
- outbound systems
- better meeting flow

## 2) I want cleaner ecommerce operations

Open:

- [AI for Amazon](/hubs/amazon-ai/)
- [Amazon listing optimization](/hubs/amazon-ai/listing-optimization/)
- [Amazon pricing signals](/hubs/amazon-ai/pricing-signals/)
- [AI for Shopify](/hubs/shopify-ai/)
- [Shopify store optimization](/hubs/shopify-ai/store-optimization/)

This path is for:
- listing and store performance
- conversion fixes
- marketplace and store workflows

## 3) I want repeatable automation systems

Open:

- [Automation Workflows](/hubs/workflow/)
- [Operations](/hubs/operations/)
- [Integrations](/hubs/integrations/)
- [Tools](/tools/)

This path is for:
- execution patterns
- QA and release safety
- tool and system routing

## Fast routes

### Money path
- [AI for Sales](/hubs/ai-for-sales/)
- [Lead generation](/hubs/ai-for-sales/lead-generation/)
- [Outreach](/hubs/ai-for-sales/outreach/)
- [Follow-up](/hubs/ai-for-sales/follow-up/)

### Marketplace path
- [AI for Amazon](/hubs/amazon-ai/)
- [Amazon listing optimization](/hubs/amazon-ai/listing-optimization/)
- [Amazon keyword research](/hubs/amazon-ai/keyword-research/)
- [Amazon pricing signals](/hubs/amazon-ai/pricing-signals/)

### Systems path
- [Workflow Systems](/hubs/workflow/)
- [Operations](/hubs/operations/)
- [Integrations](/hubs/integrations/)
- [Tools](/tools/)
