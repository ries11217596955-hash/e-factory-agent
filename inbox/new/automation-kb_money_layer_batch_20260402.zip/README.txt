MONEY LAYER BATCH (light, non-intrusive)
Adds recommended tools blocks and gentle hub tool links.
